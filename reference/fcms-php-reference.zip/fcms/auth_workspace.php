<?php
require_once __DIR__ . '/client_lifecycle.php';

function fcms_require_workspace($con, $admin)
{
    $actor = fcms_client_actor($con);
    $role = (int)$_SESSION['role_id'];
    if (!in_array($role, array(1, 2), true)) {
        http_response_code(403);
        exit('Your account does not have an assigned workspace. Please contact the administrator.');
    }
    header('Cache-Control: private, no-store');
    if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    if ($admin !== null && (($role === 1) !== $admin)) {
        header('Location: ' . ($role === 1 ? 'admin.php' : 'user_dashboard.php'), true, 303);
        exit;
    }
    return $actor;
}

function fcms_login($con, $input)
{
    $email = $input['email'] ?? '';
    $password = $input['password'] ?? '';
    if (!is_string($email) || !is_string($password) ||
        strlen($email) > 100 || strlen($password) > 4096 ||
        !filter_var(trim($email), FILTER_VALIDATE_EMAIL) || $password === '') {
        return 'Wrong password or email.';
    }
    $stmt = $con->prepare('SELECT id, email, password, role_id, status_id FROM users WHERE email=? LIMIT 2');
    $email = trim($email);
    $stmt->bind_param('s', $email); $stmt->execute();
    $result = $stmt->get_result();
    $account = $result->num_rows === 1 ? $result->fetch_assoc() : null;
    $stmt->close();
    $stored = $account['password'] ?? '';
    $matches = password_verify($password, $stored);
    // Retain legacy plaintext migration, but never authenticate a hash as a password.
    $legacy = !$matches && $account && password_get_info($stored)['algoName'] === 'unknown' &&
        hash_equals($stored, $password);
    if (!$matches && !$legacy) return 'Wrong password or email.';
    if ((int)$account['status_id'] !== 1) return 'Your account is inactive. Please contact the administrator.';
    if (!in_array((int)$account['role_id'], array(1, 2), true)) {
        return 'Your account does not have an assigned workspace. Please contact the administrator.';
    }
    if ($legacy || password_needs_rehash($stored, PASSWORD_DEFAULT)) {
        $newHash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $con->prepare('UPDATE users SET password=? WHERE id=?');
        $stmt->bind_param('si', $newHash, $account['id']); $stmt->execute(); $stmt->close();
    }
    session_regenerate_id(true);
    $_SESSION = array('id' => (int)$account['id'], 'email' => $account['email'], 'role_id' => (int)$account['role_id']);
    return null;
}
