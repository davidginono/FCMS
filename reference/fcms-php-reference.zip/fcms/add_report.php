<?php
require_once __DIR__ . '/auth_workspace.php';
fcms_client_session();
require __DIR__ . '/connect.php';
$workspaceActor = fcms_require_workspace($con, null);
?>

<!DOCTYPE html>
<html lang="en"> 
<head>
    <title>FCPS | Report</title>
    

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="description" content="Portal - Bootstrap 5 Admin Dashboard Template For Developers">
    <meta name="author" content="Xiaoying Riley at 3rd Wave Media">    
  
    

    <script defer src="assets/plugins/fontawesome/js/all.min.js"></script>
    

    <link id="theme-style" rel="stylesheet" href="assets/css/portal.css?v=20260712-7">

</head> 

<body class="app">   	
    <?php require __DIR__ . ((int)$_SESSION['role_id'] === 1 ? '/admin_navigation.php' : '/user_navigation.php'); ?>
    
    <div class="app-wrapper" >
	    
	    <div class="app-content pt-3 p-md-3 p-lg-4" style="margin-top:10px";>
		    <div class="container-xl">
			    
			    <div class="row g-3 mb-4 align-items-center justify-content-between">
				    <div class="col-auto">
			            <!-- <h1 class="app-page-title mb-0">Add User </Details></h1> -->
				    </div>
				    <div class="col-auto">
					     <div class="page-utilities">
						    <div class="row g-2 justify-content-start justify-content-md-end align-items-center">
							    <div class="col-auto">
								    <form class="table-search-form row gx-1 align-items-center">
					                  
					                    
					                </form>
									
					                
							    </div>
							  
							  
						    </div>
					    </div>
				    </div>
			    </div>

                              <?php

require_once("connect.php");

if (isset($_POST['add'])) {
    $saccos = $_POST['saccos_id'];
    $group_id = $_POST['group_id']; // 'single' or 'group'
    $explanation = $_POST['explanation'];
    $date = $_POST['date'];
    $enddate = $_POST['end_date'];
    $activities = $_POST['activities'];
    $report_status_id = $_POST['report_status'];

    if (!empty($activities)) {
        $users = [];

        if ($group_id === "group" && isset($_POST['user_ids'])) {
            $users = $_POST['user_ids']; // array of selected users
        } elseif ($group_id === "single" && isset($_POST['user_id'])) {
            $users[] = $_POST['user_id'];
        }

        $allInserted = true;
        $group_ref = ($group_id === "group") ? uniqid('group_') : null;

        foreach ($users as $userid) {
            $sql = "INSERT INTO staff_report (group_id, user_id, saccos_id, end_date, date, activities, report_status, explanation, group_ref) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $con->prepare($sql);
            $stmt->bind_param("sisssssss", $group_id, $userid, $saccos, $enddate, $date, $activities, $report_status_id, $explanation, $group_ref);

            if (!$stmt->execute()) {
                $allInserted = false;
                echo '<div class="alert alert-danger">Error inserting for user ID: ' . $userid . ' - ' . $stmt->error . '</div>';
            }
        }

        if ($allInserted) {
            echo "<script>window.location.href='" . ((int)$_SESSION['role_id'] === 1 ? 'staff_report.php' : 'user_staff_report.php') . "';</script>";
        }
    } else {
        echo '<div class="alert alert-danger">Please fill all fields</div>';
    }
}
?>

<div class="container mt-0">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-blue text-white">
                    <div class="card-header-title text-center" style="color:black;">Add Report</div>
                </div>
                <form name="createForm" id="createForm" action="" method="post">
                    <div class="card-body">

                        <div class="form-group">
                            <label>Select Work Type</label>
                            <select class="form-control" name="group_id" id="groupSelect" onchange="toggleUserSelection(this)">
                                <option value="single">Single</option>
                                <option value="group">Group</option>
                            </select>
                        </div>

                        <!-- Single user selector -->
                        <div class="form-group" id="singleUser">
                            <label>Select Staff Name</label>
                            <select class="form-control" name="user_id">
                                <?php
                                $query = "SELECT * FROM users WHERE role_id='2'";
                                $result1 = mysqli_query($con, $query);
                                while ($rows = mysqli_fetch_assoc($result1)) {
                                    echo "<option value='{$rows['id']}'>{$rows['fname']}</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <!-- Group user selector -->
                        <div class="form-group" id="groupUsers" style="display:none;">
                            <label>Select Staff Members</label>
                            <?php
                            $result1 = mysqli_query($con, $query);
                            while ($rows = mysqli_fetch_assoc($result1)) {
                                echo "<div><input type='checkbox' name='user_ids[]' value='{$rows['id']}'> {$rows['fname']}</div>";
                            }
                            ?>
                        </div>

                        <div class="form-group">
                            <label>Select Client Name</label>
                            <select class="form-control" name="saccos_id">
                                <?php
                                $query = "SELECT * FROM saccos WHERE fyear_id=(SELECT id FROM financial_year ORDER BY fyear DESC LIMIT 1)";
                                $result1 = mysqli_query($con, $query);
                                while ($rows = mysqli_fetch_assoc($result1)) {
                                    echo "<option value='{$rows['id']}'>{$rows['Saccos_Name']}</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <?php
// Set timezone to Tanzania
date_default_timezone_set('Africa/Dar_es_Salaam');

// Get current datetime in proper format for datetime-local input
$currentDateTime = date('Y-m-d\TH:i');
?>

<div class="form-group">
    <label for="start_datetime">Start Date & Time</label>
    <input class="form-control" name="date" type="datetime-local" id="start_datetime" value="<?php echo $currentDateTime; ?>" required>
</div>

<div class="form-group">
    <label for="end_datetime">End Date & Time</label>
    <input class="form-control" name="end_date" type="datetime-local" id="end_datetime" value="<?php echo $currentDateTime; ?>" required>
</div>




                        <div class="form-group">
                            <label>Activities</label>
                            <input class="form-control" name="activities" type="text" required>
                        </div>

                        <div class="form-group">
                            <label>Select Status</label>
                            <select class="form-control" name="report_status" onchange="toggleExplanationField(this)">
                                <option value="DONE">DONE</option>
                                <option value="INCOMPLETE">INCOMPLETE</option>
                                <option value="PENDING">PENDING</option>
                            </select>
                        </div>

                        <div class="form-group" id="explanationField" style="display: none;">
                            <label>Explanations</label>
                            <textarea class="form-control" name="explanation" rows="4"></textarea>
                        </div>
                        <br>
                        <button type="submit" name="add" class="btn btn-success">Add</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function toggleUserSelection(select) {
    if (select.value === "group") {
        document.getElementById("groupUsers").style.display = "block";
        document.getElementById("singleUser").style.display = "none";
    } else {
        document.getElementById("groupUsers").style.display = "none";
        document.getElementById("singleUser").style.display = "block";
    }
}

function toggleExplanationField(selectElement) {
    var explanationField = document.getElementById("explanationField");
    if (selectElement.value === "PENDING" || selectElement.value === "INCOMPLETE") {
        explanationField.style.display = "block";
    } else {
        explanationField.style.display = "none";
    }
}
</script>
				
			
	    </div>
	    
	    
	   
	    
    </div>							
 
       
    <script src="assets/plugins/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>  
    

    <script src="assets/js/app.js?v=20261116-1"></script> 
	<script>
    // Set the inactivity timeout duration in milliseconds (e.g., 15 minutes)
const inactivityTimeout =5 * 60 * 1000; // 15 minutes in milliseconds

let logoutTimer;

// Reset the timer on user activity
function resetLogoutTimer() {
    clearTimeout(logoutTimer);
    logoutTimer = setTimeout(logoutUser, inactivityTimeout);
}

// Logout the user when the timeout is reached
function logoutUser() {
    // Perform logout actions here (e.g., clear session data, redirect to logout page)
    window.location.href='logout.php';
    // You can replace the alert with actual logout code.
}

// Initialize the timer when the page loads or after user activity
window.onload = resetLogoutTimer;
document.onmousemove = resetLogoutTimer; // You can add more events like keypress, etc. for user activity

// Optionally, you can also handle clicks on specific elements to reset the timer
// For example, if you have a button that keeps the user logged in
const keepLoggedInButton = document.getElementById('keep-logged-in-button');
if (keepLoggedInButton) keepLoggedInButton.addEventListener('click', resetLogoutTimer);
</script>

</body>
</html> 

