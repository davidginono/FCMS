<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
// Start the session and set custom session directory
$sessionDirectory = '/home/sites/37b/1/15b6335fc9/fcms/sessions';
ini_set('session.save_path', $sessionDirectory);
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    // If not logged in, redirect to the login page
echo "<script>window.location.href='index.php';</script>";
    exit();
}

require('connect.php');
?>

<!DOCTYPE html>
<html lang="en"> 
<head>
    <link rel="stylesheet" href="assets/css/print-preview.css?v=20261103-1">
    <script defer src="assets/js/print-preview.js?v=20261103-1"></script>
    <title>FCMS | EXPENSES </title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="description" content="Portal - Bootstrap 5 Admin Dashboard Template For Developers">
    <meta name="author" content="Tean Tech">    
   
    
    <!-- FontAwesome JS-->
    <script defer src="assets/plugins/fontawesome/js/all.min.js"></script>
    
    <!-- App CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/portal.css?v=20260712-7">
    <style>
        .expense-actions,
        .expense-filter-form {
            display: flex;
            flex-wrap: wrap;
            column-gap: 8px;
            row-gap: 10px;
            align-items: flex-end;
        }
        .expense-filter-form {
            width: 100%;
            margin-top: 12px;
        }
        .expense-filter-form > .form-control,
        .expense-filter-form > .form-select {
            width: auto;
            flex: 1 1 140px;
            min-width: 130px;
            max-width: 180px;
        }
        .expense-filter-form .filter-date {
            width: 100%;
            height: auto;
            flex: none;
        }
        .expense-filter-form .filter-action {
            flex: 0 0 auto;
            height: 44px;
        }
        .expense-filter-select {
            position: relative;
            display: flex;
            flex-direction: column;
            gap: 3px;
            flex: 1 1 180px;
            min-width: 160px;
            max-width: 270px;
        }
        .expense-filter-field {
            display: flex;
            flex-direction: column;
            gap: 3px;
            flex: 1 1 145px;
            min-width: 135px;
            max-width: 175px;
        }
        .expense-filter-buttons {
            display: flex;
            gap: 8px;
            align-items: flex-end;
            flex: 0 0 auto;
        }
        .expense-filter-label {
            font-size: 12px;
            font-weight: 600;
            color: #5d6778;
            line-height: 1;
        }
        .expense-filter-button {
            width: 100%;
            text-align: left;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .expense-filter-menu {
            display: none;
            position: absolute;
            top: calc(100% + 4px);
            left: 0;
            right: 0;
            max-height: 260px;
            overflow-y: auto;
            z-index: 20;
            background: #fff;
            border: 1px solid #dfe3ea;
            border-radius: 6px;
            box-shadow: 0 12px 28px rgba(15, 23, 42, 0.16);
        }
        .expense-filter-select.is-open .expense-filter-menu {
            display: block;
        }
        .expense-filter-option {
            width: 100%;
            border: 0;
            background: transparent;
            text-align: left;
            padding: 8px 12px;
        }
        .expense-filter-option:hover,
        .expense-filter-option.is-selected {
            background: #eaf2ff;
        }
        @media (min-width: 1200px) {
            .expense-filter-form {
                flex-wrap: nowrap;
            }
        }
    </style>

    <link rel="stylesheet" href="assets/css/table-actions.css?v=20261105-1">
    <script defer src="assets/js/table-actions.js?v=20261105-1"></script>
</head> 

<body class="app">   	
    <header class="app-header fixed-top">	   	            
        <div class="app-header-inner">  
	        <div class="container-fluid py-2">
		        <div class="app-header-content"> 
		            <div class="row justify-content-between align-items-center">
			        
				    <div class="col-auto">
					    <a id="sidepanel-toggler" class="sidepanel-toggler d-inline-block d-xl-none" href="#">
						    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" role="img"><title>Menu</title><path stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2" d="M4 7h22M4 15h22M4 23h22"></path></svg>
					    </a>
				    </div><!--//col-->
		            <div class="search-mobile-trigger d-sm-none col">
			            <i class="search-mobile-trigger-icon fa-solid fa-magnifying-glass"></i>
			        </div><!--//col-->
		            <div class="app-search-box col">
		              
		            </div><!--//app-search-box-->
		            
		            <div class="app-utilities col-auto">
			            <div class="app-utility-item app-notifications-dropdown dropdown">    
				            <a class="dropdown-toggle no-toggle-arrow" id="notifications-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false" title="Notifications">
					            <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					            
					            
					        </a><!--//dropdown-toggle-->
					        
					        			        
				        </div><!--//app-utility-item-->
			          
			            
						<div class="app-utility-item app-user-dropdown dropdown">
				            <a class="dropdown-toggle" id="user-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"><span class="navbar-profile-icon"><i class="fa-solid fa-user"></i></span></a><ul class="dropdown-menu" aria-labelledby="user-dropdown-toggle">
								<li><a class="dropdown-item" href="account.php">Account</a></li>
								<li><a class="dropdown-item" href="change_password.php">Change Password</a></li>
								<li><a class="dropdown-item" href="change_profile.php">Change Profile Picture</a></li>
								<li><hr class="dropdown-divider"></li>
								<li><a class="dropdown-item" href="logout.php">Log Out</a></li>
							</ul>
			            </div><!--//app-user-dropdown--> 
		            </div><!--//app-utilities-->
		        </div><!--//row-->
	            </div><!--//app-header-content-->
	        </div><!--//container-fluid-->
        </div><!--//app-header-inner-->
        
        
             <div id="app-sidepanel" class="app-sidepanel"> 
	        <div id="sidepanel-drop" class="sidepanel-drop"></div>
	        <div class="sidepanel-inner d-flex flex-column">
		        <a href="#" id="sidepanel-close" class="sidepanel-close d-xl-none">&times;</a>
		        <div class="app-branding">
		            <a class="app-logo" href="admin.php"><img class="logo-icon me-2" src="assets/images/app-logo.png" alt="logo"><span class="logo-text">FCMS</span></a>
	
		        </div><!--//app-branding-->  
		        
			    <nav id="app-nav-main" class="app-nav app-nav-main flex-grow-1">
				    <ul class="app-menu list-unstyled accordion" id="menu-accordion">
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link active" href="admin.php">
						        <span class="nav-icon">
						        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-house-door" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
		  <path fill-rule="evenodd" d="M7.646 1.146a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 .146.354v7a.5.5 0 0 1-.5.5H9.5a.5.5 0 0 1-.5-.5v-4H7v4a.5.5 0 0 1-.5.5H2a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .146-.354l6-6zM2.5 7.707V14H6v-4a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4h3.5V7.707L8 2.207l-5.5 5.5z"/>
		  <path fill-rule="evenodd" d="M13 2.5V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
		</svg>
						         </span>
		                         <span class="nav-link-text">Dashboard</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="admin2.php">
						        <span class="nav-icon">
						        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-speedometer2" viewBox="0 0 16 16">
  <path d="M8 4a.5.5 0 0 1 .5.5V6a.5.5 0 0 1-1 0V4.5A.5.5 0 0 1 8 4M3.732 5.732a.5.5 0 0 1 .707 0l.915.914a.5.5 0 1 1-.708.708l-.914-.915a.5.5 0 0 1 0-.707M2 10a.5.5 0 0 1 .5-.5h1.586a.5.5 0 0 1 0 1H2.5A.5.5 0 0 1 2 10m9.5 0a.5.5 0 0 1 .5-.5h1.5a.5.5 0 0 1 0 1H12a.5.5 0 0 1-.5-.5m.754-4.246a.39.39 0 0 0-.527-.02L7.547 9.31a.91.91 0 1 0 1.302 1.258l3.434-4.297a.39.39 0 0 0-.029-.518z"/>
  <path fill-rule="evenodd" d="M0 10a8 8 0 1 1 15.547 2.661c-.442 1.253-1.845 1.602-2.932 1.25C11.309 13.488 9.475 13 8 13c-1.474 0-3.31.488-4.615.911-1.087.352-2.49.003-2.932-1.25A8 8 0 0 1 0 10m8-7a7 7 0 0 0-6.603 9.329c.203.575.923.876 1.68.63C4.397 12.533 6.358 12 8 12s3.604.532 4.923.96c.757.245 1.477-.056 1.68-.631A7 7 0 0 0 8 3"/>
</svg>
						         </span>
		                         <span class="nav-link-text">Amcos Dashboard</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="admin3.php">
						        <span class="nav-icon">
						        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-speedometer2" viewBox="0 0 16 16">
  <path d="M8 4a.5.5 0 0 1 .5.5V6a.5.5 0 0 1-1 0V4.5A.5.5 0 0 1 8 4M3.732 5.732a.5.5 0 0 1 .707 0l.915.914a.5.5 0 1 1-.708.708l-.914-.915a.5.5 0 0 1 0-.707M2 10a.5.5 0 0 1 .5-.5h1.586a.5.5 0 0 1 0 1H2.5A.5.5 0 0 1 2 10m9.5 0a.5.5 0 0 1 .5-.5h1.5a.5.5 0 0 1 0 1H12a.5.5 0 0 1-.5-.5m.754-4.246a.39.39 0 0 0-.527-.02L7.547 9.31a.91.91 0 1 0 1.302 1.258l3.434-4.297a.39.39 0 0 0-.029-.518z"/>
  <path fill-rule="evenodd" d="M0 10a8 8 0 1 1 15.547 2.661c-.442 1.253-1.845 1.602-2.932 1.25C11.309 13.488 9.475 13 8 13c-1.474 0-3.31.488-4.615.911-1.087.352-2.49.003-2.932-1.25A8 8 0 0 1 0 10m8-7a7 7 0 0 0-6.603 9.329c.203.575.923.876 1.68.63C4.397 12.533 6.358 12 8 12s3.604.532 4.923.96c.757.245 1.477-.056 1.68-.631A7 7 0 0 0 8 3"/>
</svg>
						         </span>
		                         <span class="nav-link-text">Union Dashboard</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
	

						<li class="nav-item has-submenu">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-2" aria-expanded="false" aria-controls="submenu-2">
						        <span class="nav-icon">
								<i class="fas fa-fw fa-building"></i>
						        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
						        
						         </span>
		                         <span class="nav-link-text">Clients</span>
		                         <span class="submenu-arrow">
		                             <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
	</svg>
	                             </span><!--//submenu-arrow-->
					        </a><!--//nav-link-->
					        <div id="submenu-2" class="collapse submenu submenu-2" data-bs-parent="#menu-accordion">
						        <ul class="submenu-list list-unstyled">
								    <?php require __DIR__ . '/admin_client_menu.php'; ?>

						        </ul>
					        </div>
					    </li><!--//nav-item-->

			<div>

			
			</div>
						
					
					
					    <li class="nav-item has-submenu">

					      
					        <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-1" aria-expanded="false" aria-controls="submenu-1">
						        <span class="nav-icon">
						        <i class="fas fa-fw fa-users"></i>
						         </span>
		                         <span class="nav-link-text">Users</span>
		                         <span class="submenu-arrow">
		                             <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
	</svg>
	                             </span>
					        </a>
					        <div id="submenu-1" class="collapse submenu submenu-1" data-bs-parent="#menu-accordion">
						        <ul class="submenu-list list-unstyled">
								    <li class="submenu-item"><a class="submenu-link" href="add_user.php"> Add New Users</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="users.php">All Users</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="active_users.php">Active Users</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="inactive_users.php">Inactive Users</a></li>
					
						        </ul>
					        </div>
					    </li>


					
						

						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="all_task.php">
						        <span class="nav-icon">
								<i class="fas fa-fw fa-tasks"></i>
						         </span>
		                         <span class="nav-link-text">Tasks</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					     <li class="nav-item has-submenu">

					      
					        <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-3" aria-expanded="false" aria-controls="submenu-3">
						        <span class="nav-icon">
						        <i class="fas fa-fw fa-file"></i>
						         </span>
		                         <span class="nav-link-text">Reports</span>
		                         <span class="submenu-arrow">
		                             <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
	</svg>
	                             </span>
					        </a>
					        <div id="submenu-3" class="collapse submenu submenu-3" data-bs-parent="#menu-accordion">
						        <ul class="submenu-list list-unstyled">

								    <li class="submenu-item"><a class="submenu-link" href="report.php"> Saccos Report</a></li>
                                    <li class="submenu-item"><a class="submenu-link" href="union_report.php"> Union Report</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="microfinance_report.php">Microfinance Report</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="other_report.php">Other Client Report</a></li>
							        						            <li class="submenu-item"><a class="submenu-link" href="staff_report.php"> Staff Report</a></li>
							             <li class="submenu-item"><a class="submenu-link" href="income_statement.php">Income Statement</a></li>
					
						        </ul>
					        </div>
					    </li>
					

						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="leaves.php">
						        <span class="nav-icon">
								<i class="fas fa-fw fa-file-pdf"></i>
						         </span>
		                         <span class="nav-link-text">Staff Leaves</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->

						
					    
					    						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="expenses.php">
						        <span class="nav-icon">
						            <i class="fa-solid fa-sack-xmark"></i>
	
						         </span>
		                         <span class="nav-link-text">Expenses</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="income.php">
						        <span class="nav-icon">
				<i class="fa-solid fa-sack-dollar"></i>
						         </span>
		                         <span class="nav-link-text">Other Income</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="petty_cash.php">
						        <span class="nav-icon">
				<i class="fa-solid fa-sack-dollar"></i>
						         </span>
		                         <span class="nav-link-text">Petty Cash</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					     
   <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="cloud_backup.php">
						        <span class="nav-icon">
				<i class="fa-solid fa-sack-dollar"></i>
						         </span>
		                         <span class="nav-link-text">Cloud Backup</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
<li class="nav-item">
    <!-- Font Awesome icon -->
    <a class="nav-link" href="backup.php">
        <span class="nav-icon">
            <i class="fas fa-hdd"></i> <!-- Hard drive icon -->
        </span>
        <span class="nav-link-text">System Backup</span>
    </a>
</li>





						
    
					
						
					 

					   
					    
					    
										    
				    </ul><!--//app-menu-->

					
			    </nav><!--//app-nav-->
			    <div class="app-sidepanel-footer">
				    <div class="sidepanel-company">
					    <img class="sidepanel-company-logo" src="assets/images/app-logo.png" alt="Computer Recources ltd">
					    <span class="sidepanel-company-text">Computer Recources ltd</span>
				    </div>
			    </div><!--//app-sidepanel-footer-->
		       
	        </div><!--//sidepanel-inner-->
	    </div><!--//app-sidepanel-->

    </header><!--//app-header-->
    
    <div class="app-wrapper" >
	    
	    <div class="app-content pt-3 p-md-3 p-lg-4" style="margin-top:10px";>
		    <div class="container-xl">
			    
			    <div class="row g-3 mb-4 align-items-center justify-content-between">
				    <div class="col-auto">
			            <h1 class="app-page-title mb-0">OFFICE EXPENSES</h1>
				    </div>
				    <div class="col-auto">
					     <div class="page-utilities">
						    <div class="row g-2 justify-content-start justify-content-md-end align-items-center">
							    <div class="col-auto">

																    <form class="table-search-form row gx-1 align-items-center" method="POST" action="search_expenses.php">
					                    <div class="col-auto">
					                        <input type="text" id="search-orders" name="search" class="form-control search-orders" placeholder="Search" required>
					                    </div>
					                    <div class="col-auto">
					                        <button type="submit" class="btn app-btn-secondary">Search</button>
					                    </div>
					                </form>
					                
							    </div><!--//col-->
							  
							
						    </div><!--//row-->
					    </div><!--//table-utilities-->
				    </div><!--//col-auto-->

					

			    </div><!--//row-->

<?php
require("connect.php");
$selected_category = isset($_GET['category']) ? $_GET['category'] : '';
$selected_staff = isset($_GET['user_id']) ? $_GET['user_id'] : '';
$selected_year = isset($_GET['fyear']) ? $_GET['fyear'] : '';
$selected_start_date = isset($_GET['startDate']) ? $_GET['startDate'] : '';
$selected_end_date = isset($_GET['endDate']) ? $_GET['endDate'] : '';
?>
				  <div class="expense-actions">
				      <a href="add_expenses.php" class="btn btn-info btn-icon-split"></span><span class="text"> &nbsp;Add Expenses</span></a>
				          <form action="print_filter_dates.php" method="post" target="_blank">
				              <input type="hidden" name="category" value="<?php echo htmlspecialchars($selected_category); ?>">
				              <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($selected_staff); ?>">
				              <input type="hidden" name="fyear" value="<?php echo htmlspecialchars($selected_year); ?>">
				              <input type="hidden" name="startDate" value="<?php echo htmlspecialchars($selected_start_date !== '' ? $selected_start_date : '1900-01-01'); ?>">
				              <input type="hidden" name="endDate" value="<?php echo htmlspecialchars($selected_end_date !== '' ? $selected_end_date : date('Y-m-d')); ?>">
				              <button type="submit" class="btn btn-success btn-icon-split"><span class="text"><i class="fas fa-fw fa-print"></i>&nbsp;Report</span></button>
				          </form>
				  </div>
				  <form action="expenses.php" method="get" class="expense-filter-form">
				      <div class="expense-filter-select" data-filter-select>
				          <label class="expense-filter-label" for="expenseCategoryButton">Category</label>
				          <input type="hidden" name="category" value="<?php echo htmlspecialchars($selected_category); ?>" data-filter-value>
				          <button type="button" class="form-select expense-filter-button" id="expenseCategoryButton" data-filter-button>
				              <span><?php echo $selected_category !== '' ? htmlspecialchars($selected_category) : 'All Categories'; ?></span>
				          </button>
				          <div class="expense-filter-menu">
				              <button type="button" class="expense-filter-option <?php echo $selected_category === '' ? 'is-selected' : ''; ?>" data-value="">All Categories</button>
				              <?php
				              $category_result = mysqli_query($con, "SELECT DISTINCT TRIM(category) AS category FROM expenses WHERE TRIM(category) <> '' AND LOWER(TRIM(category)) <> 'category' ORDER BY category ASC");
				              while ($category_row = mysqli_fetch_assoc($category_result)) {
				                  $selected = ($selected_category === $category_row['category']) ? 'is-selected' : '';
				                  echo '<button type="button" class="expense-filter-option ' . $selected . '" data-value="' . htmlspecialchars($category_row['category']) . '">' . htmlspecialchars($category_row['category']) . '</button>';
				              }
				              ?>
				          </div>
				      </div>
				      <div class="expense-filter-select" data-filter-select>
				          <label class="expense-filter-label" for="expenseStaffButton">Staff</label>
				          <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($selected_staff); ?>" data-filter-value>
				          <button type="button" class="form-select expense-filter-button" id="expenseStaffButton" data-filter-button>
				              <span>All Staff</span>
				          </button>
				          <div class="expense-filter-menu">
				              <button type="button" class="expense-filter-option <?php echo $selected_staff === '' ? 'is-selected' : ''; ?>" data-value="">All Staff</button>
				              <?php
				              $staff_result = mysqli_query($con, "SELECT DISTINCT users.id, users.fname FROM expenses INNER JOIN users ON expenses.user_id=users.id WHERE TRIM(users.fname) <> '' ORDER BY users.fname ASC");
				              while ($staff_row = mysqli_fetch_assoc($staff_result)) {
				                  $selected = ($selected_staff == $staff_row['id']) ? 'is-selected' : '';
				                  $label = htmlspecialchars($staff_row['fname']);
				                  echo '<button type="button" class="expense-filter-option ' . $selected . '" data-value="' . htmlspecialchars($staff_row['id']) . '">' . $label . '</button>';
				              }
				              ?>
				          </div>
				      </div>
				      <div class="expense-filter-select">
				          <label class="expense-filter-label" for="expenseYear">Year</label>
				          <select class="form-select" id="expenseYear" name="fyear">
				              <option value="">All Years</option>
				              <?php
				              $year_result = mysqli_query($con, "SELECT DISTINCT fyear FROM expenses WHERE fyear <> '' ORDER BY fyear DESC");
				              while ($year_row = mysqli_fetch_assoc($year_result)) {
				                  $selected = ($selected_year == $year_row['fyear']) ? 'selected' : '';
				                  echo '<option value="' . htmlspecialchars($year_row['fyear']) . '" ' . $selected . '>' . htmlspecialchars($year_row['fyear']) . '</option>';
				              }
				              ?>
				          </select>
				      </div>
				      <div class="expense-filter-field">
				          <label class="expense-filter-label" for="expenseStartDate">From</label>
				          <input type="date" class="form-control filter-date" id="expenseStartDate" name="startDate" value="<?php echo htmlspecialchars($selected_start_date); ?>">
				      </div>
				      <div class="expense-filter-field">
				          <label class="expense-filter-label" for="expenseEndDate">To</label>
				          <input type="date" class="form-control filter-date" id="expenseEndDate" name="endDate" value="<?php echo htmlspecialchars($selected_end_date); ?>">
				      </div>
				      <div class="expense-filter-buttons">
				          <button type="submit" class="btn btn-success btn-icon-split filter-action"><span class="text"><i class="fas fa-fw fa-filter"></i>&nbsp;Filter</span></button>
				          <a href="expenses.php" class="btn btn-secondary filter-action">Reset</a>
				      </div>
				  </form>
				  <br><br>

	
				<?php

$where = array();
if ($selected_category !== '') {
    $where[] = "category='" . mysqli_real_escape_string($con, $selected_category) . "'";
}
if ($selected_staff !== '' && is_numeric($selected_staff)) {
    $where[] = "expenses.user_id=" . (int)$selected_staff;
}
if ($selected_year !== '' && is_numeric($selected_year)) {
    $where[] = "fyear='" . mysqli_real_escape_string($con, $selected_year) . "'";
}
if ($selected_start_date !== '') {
    $where[] = "date_created>='" . mysqli_real_escape_string($con, $selected_start_date) . "'";
}
if ($selected_end_date !== '') {
    $where[] = "date_created<='" . mysqli_real_escape_string($con, $selected_end_date) . "'";
}

$query = "SELECT expenses.id, date_created,description,ename,amount,fyear,category,payee,fname
FROM expenses 
INNER JOIN 
users ON expenses.user_id=users.id 
INNER JOIN expenses_status ON expenses.status_app_id=expenses_status.id
" . (count($where) ? "WHERE " . implode(" AND ", $where) : "") . "
ORDER BY date_created DESC";

$result1 = mysqli_query($con, $query);

$total_amount = 0; // Initialize a variable to store the total amount

?>

<div class="card-body">

<?php
$total_amount = 0; // Initialize total amount

// Loop to calculate total amount
while ($row = mysqli_fetch_assoc($result1)) {
    $total_amount += $row['amount'];
}

// Reset the result pointer to the beginning
mysqli_data_seek($result1, 0);
?>

<!-- Display the total amount at the top -->
<div style="text-align: left; margin-bottom: 10px;">
    <strong style="text-align:left;" >Total Expenses:</strong> <span style="font-size: 20px;font-weight:bold;color:black;"><?php echo number_format($total_amount); ?></span>
</div>

    <div class="table-responsive long-list-table">
<table class="table table-bordered" id="dataTable" data-batch-table width="100%" cellspacing="0" style="text-align:center;">
    <tr style="text-align:center;">
        <th>No</th>
        <th>Recorded by</th>
        <th>Date</th>
        <th>Category</th>

        <th>Description</th>
        <th>Amount</th>
        <th>Year</th>
        <th>Status</th>
        <th>Action</th>
    </tr>

    <?php
    $no = 1;
    while ($row = mysqli_fetch_assoc($result1)) {
        ?>
        <tr>
            <td><?php echo $no++ ?></td>
            <td style="text-align:left;"><?php echo $row['fname'] ?></td>
            <td style="text-align:left;"><?php echo $row['date_created'] ?></td>
            <td style="text-align:left;"><?php echo $row['category'] ?></td>

            <td style="text-align:left;"><?php echo $row['description'] ?></td>
            <td style="text-align:left;"><?php echo number_format($row['amount']) ?></td>
            <td style="text-align:left;"><?php echo $row['fyear'] ?></td>
            <td style="text-align:left;"><?php echo $row['ename']?></td>
            <td>
                <a href="update_expenses.php?id=<?php echo $row['id'] ?>" class="btn btn-info btn-icon-split">
                    <span class="icon"></span>
                    <span class="text">Update</span>
                </a>
                <a href="delete_expenses.php?id=<?php echo $row['id'] ?>" class="btn btn-danger btn-icon-split">
                    <span class="icon"></span>
                    <span class="text">Delete</span>
                </a>
            </td>
        </tr>
    <?php } ?>
</table>

    </div>
</div>
					
			    
			    <!-- <nav id="orders-table-tab" class="orders-table-tab app-nav-tabs nav shadow-sm flex-column flex-sm-row mb-4">
				    <a class="flex-sm-fill text-sm-center nav-link active" id="orders-all-tab" data-bs-toggle="tab" href="#orders-all" role="tab" aria-controls="orders-all" aria-selected="true">All</a>
				    <a class="flex-sm-fill text-sm-center nav-link"  id="orders-paid-tab" data-bs-toggle="tab" href="#orders-paid" role="tab" aria-controls="orders-paid" aria-selected="false">Active</a>
				    <a class="flex-sm-fill text-sm-center nav-link" id="orders-pending-tab" data-bs-toggle="tab" href="#orders-pending" role="tab" aria-controls="orders-pending" aria-selected="false">Pending</a>
				    <a class="flex-sm-fill text-sm-center nav-link" id="orders-cancelled-tab" data-bs-toggle="tab" href="#orders-cancelled" role="tab" aria-controls="orders-cancelled" aria-selected="false">Cancelled</a>
				</nav> -->
			    
		    </div><!--//container-fluid-->
	    </div><!--//app-content-->
	    
	   
	    
    </div><!--//app-wrapper-->    					

 
    <!-- Javascript -->          
    <script src="assets/plugins/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>  
    
    
    <!-- Page Specific JS -->
    <script src="assets/js/app.js?v=20260712-7"></script> 
	<script>
document.querySelectorAll('[data-filter-select]').forEach(function(select) {
    const button = select.querySelector('[data-filter-button]');
    const label = button.querySelector('span');
    const input = select.querySelector('[data-filter-value]');
    const options = select.querySelectorAll('.expense-filter-option');
    const selectedOption = Array.from(options).find(function(option) {
        return option.dataset.value === input.value;
    });

    if (selectedOption) {
        label.textContent = selectedOption.textContent;
    }

    button.addEventListener('click', function() {
        document.querySelectorAll('[data-filter-select].is-open').forEach(function(openSelect) {
            if (openSelect !== select) {
                openSelect.classList.remove('is-open');
            }
        });
        select.classList.toggle('is-open');
    });

    options.forEach(function(option) {
        option.addEventListener('click', function() {
            input.value = option.dataset.value;
            label.textContent = option.textContent;
            options.forEach(function(item) {
                item.classList.remove('is-selected');
            });
            option.classList.add('is-selected');
            select.classList.remove('is-open');
        });
    });
});

document.addEventListener('click', function(event) {
    if (!event.target.closest('[data-filter-select]')) {
        document.querySelectorAll('[data-filter-select].is-open').forEach(function(select) {
            select.classList.remove('is-open');
        });
    }
});

    // Set the inactivity timeout duration in milliseconds (e.g., 15 minutes)
const inactivityTimeout =5 * 60 * 1000; // 15 minutes in milliseconds

let logoutTimer;

// Reset the timer on user activity
function resetLogoutTimer() {
    clearTimeout(logoutTimer);
    logoutTimer = setTimeout(logoutUser, inactivityTimeout);
}

// Logout the user when the timeout is reached
function logoutUser() {
    // Perform logout actions here (e.g., clear session data, redirect to logout page)
    window.location.href='logout.php';
    // You can replace the alert with actual logout code.
}

// Initialize the timer when the page loads or after user activity
window.onload = resetLogoutTimer;
document.onmousemove = resetLogoutTimer; // You can add more events like keypress, etc. for user activity

// Optionally, you can also handle clicks on specific elements to reset the timer
// For example, if you have a button that keeps the user logged in
const keepLoggedInButton = document.getElementById('keep-logged-in-button');
keepLoggedInButton.addEventListener('click', resetLogoutTimer);
</script>

</body>
</html> 


