<?php // Clients submenu shared by the standard and legacy admin sidebars. ?>
<li class="submenu-item"><a class="submenu-link" href="saccos.php">SACCOS</a></li>
<li class="submenu-item"><a class="submenu-link" href="amcos.php">AMCOS</a></li>
<li class="submenu-item"><a class="submenu-link" href="union.php">UNION</a></li>
<li class="submenu-item"><a class="submenu-link" href="prospects.php">Prospective clients</a></li>
<li class="submenu-item"><a class="submenu-link" href="invoices.php">Invoices</a></li>
<li class="submenu-item"><a class="submenu-link" href="microfinance.php">MICROFINANCE</a></li>
<li class="submenu-item"><a class="submenu-link" href="other_client.php">OTHERS</a></li>
