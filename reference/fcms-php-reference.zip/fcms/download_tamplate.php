<?php
require("connect.php");
require_once __DIR__ . '/client_lifecycle.php';
fcms_client_actor($con);

if(isset($_POST["fyear_id"]) && !empty($_POST["fyear_id"])) {
    $selected_year = intval($_POST["fyear_id"]);

    // SQL query with prepared statement to get records based on the selected year
    $sql = "SELECT saccos.id,saccos_name, Entry_Date,expire_date,Region,pfile,Annual_fee, Amount,tax,com,Programmer_cost,Sys_install_fee, Training_fee, Android_fee, Sys_reinstall_fee,bulk_sms,hosting_fee,Name,fyear
            FROM saccos
            INNER JOIN saccos_status ON saccos.saccos_status_id = saccos_status.sid
            INNER JOIN financial_year ON saccos.fyear_id=financial_year.id AND saccos.status = 'ACTIVE'
            WHERE fyear_id = ? ORDER BY saccos_name ASC";

    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $selected_year);
    $stmt->execute();
    $result = $stmt->get_result();

    if($result->num_rows > 0) {
        // Create a CSV file
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="saccos_data.csv');

        $output = fopen('php://output', 'w');

        // Write header row
        $header = array('id', 'Saccos_Name', 'Entry_Date', 'expire_date', 'Region','pfile', 'Annual_fee','Amount','tax','com','Programmer_cost','Sys_install_fee','Training_fee','Android_fee', 'Sys_reinstall_fee','bulk_sms','hosting_fee','saccos_status_id','fyear_id');
        fputcsv($output, $header);

        // Write data rows
        while ($row = $result->fetch_assoc()) {
            fputcsv($output, $row);
        }

        fclose($output);
        exit;
    } else {
        echo "No records found for the selected year.";
    }
} else {
    echo "Error: fyear_id is not set or empty.";
}
?>
