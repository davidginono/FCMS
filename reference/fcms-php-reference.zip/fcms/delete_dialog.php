<?php
$clientDeleteType = 'SACCOS';
require __DIR__ . '/client_delete.php';
