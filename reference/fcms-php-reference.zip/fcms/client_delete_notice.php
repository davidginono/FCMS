<?php
if (session_status() === PHP_SESSION_ACTIVE && isset($_SESSION['client_delete_notice'])) {
    $clientDeleteNotice = $_SESSION['client_delete_notice'];
    unset($_SESSION['client_delete_notice']);
    echo '<div class="alert alert-success" role="status">' .
        htmlspecialchars((string)$clientDeleteNotice, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</div>';
}
