<?php
$clientDeleteType = 'OTHER';
require __DIR__ . '/client_delete.php';
