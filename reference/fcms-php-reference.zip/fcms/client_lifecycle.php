<?php
// Shared only by client activity/prospect workflows and client-related exports.
function fcms_client_escape($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function fcms_client_session()
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        $legacyPath = '/home/sites/37b/1/15b6335fc9/fcms/sessions';
        if (is_dir($legacyPath)) {
            session_save_path($legacyPath);
        }
        session_start();
    }
}

function fcms_client_actor($con, $adminOnly = false)
{
    fcms_client_session();
    $email = $_SESSION['email'] ?? '';
    if (!is_string($email) || $email === '') {
        http_response_code(401);
        exit('Please sign in to FCMS.');
    }
    $stmt = $con->prepare('SELECT id, role_id FROM users WHERE email = ? AND status_id = 1 LIMIT 1');
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $actor = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$actor || ($adminOnly && (int)$actor['role_id'] !== 1)) {
        http_response_code(403);
        exit('You do not have permission to perform this action.');
    }
    // Refresh cached identity so role changes apply to existing sessions.
    $_SESSION['id'] = (int)$actor['id'];
    $_SESSION['role_id'] = (int)$actor['role_id'];
    return (int)$actor['id'];
}

function fcms_client_csrf()
{
    fcms_client_session();
    if (empty($_SESSION['client_csrf'])) {
        $_SESSION['client_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['client_csrf'];
}

function fcms_client_verify_csrf()
{
    $token = $_POST['csrf'] ?? null;
    if (!is_string($token) || !hash_equals(fcms_client_csrf(), $token)) {
        http_response_code(403);
        exit('Your form expired. Reload the page and try again.');
    }
}

function fcms_client_table($type)
{
    $tables = array('SACCOS' => 'saccos', 'AMCOS' => 'amcos', 'UNION' => 'union', 'MICROFINANCE' => 'microfinance');
    if (!is_string($type) || !isset($tables[$type])) {
        throw new InvalidArgumentException('Invalid client type.');
    }
    return $tables[$type];
}

function fcms_client_audit($con, $actor, $action, $type, $id, $before = '', $after = '')
{
    $stmt = $con->prepare('INSERT INTO client_lifecycle_audit (actor_id, action, client_type, record_id, before_value, after_value) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->bind_param('ississ', $actor, $action, $type, $id, $before, $after);
    $stmt->execute();
    $stmt->close();
}

function fcms_client_validate_status($status)
{
    if (!is_string($status) || !in_array($status, array('ACTIVE', 'INACTIVE'), true)) {
        throw new InvalidArgumentException('Choose a valid Client status.');
    }
    return $status;
}

function fcms_prospect_validate($input)
{
    return fcms_document_validate($input, array('SACCOS', 'AMCOS', 'UNION'));
}

function fcms_document_validate($input, $types)
{
    $items = fcms_prospect_calculate_items($input['items'] ?? null);
    // Neither the browser's total nor its summary is authoritative.
    $input['invoice_details'] = implode("\n", array_column($items['items'], 'description'));
    $input['invoice_amount'] = $items['total'];
    $limits = array('client_type' => 20, 'client_name' => 150, 'region' => 100, 'contact_name' => 150,
        'phone' => 40, 'email' => 190, 'invoice_number' => 60, 'invoice_date' => 10,
        'valid_until' => 10, 'currency' => 3, 'invoice_details' => 50000,
        'invoice_amount' => 20, 'invoice_terms' => 2000);
    $data = array();
    foreach ($limits as $field => $limit) {
        $value = $input[$field] ?? '';
        if (!is_string($value) || mb_strlen(trim($value), 'UTF-8') > $limit) {
            throw new InvalidArgumentException('A field is too long or has an invalid value.');
        }
        $controlPattern = in_array($field, array('invoice_details','invoice_terms'), true) ? '/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/' : '/[\x00-\x1f\x7f]/';
        if (preg_match($controlPattern, $value)) {
            throw new InvalidArgumentException('A field contains unsupported control characters.');
        }
        $data[$field] = trim($value);
    }
    if (!in_array($data['client_type'], $types, true)) {
        throw new InvalidArgumentException('Invalid client type.');
    }
    foreach (array('client_name', 'invoice_number', 'invoice_details') as $required) {
        if ($data[$required] === '') {
            throw new InvalidArgumentException('Client name, document number and invoice details are required.');
        }
    }
    foreach (array('invoice_date', 'valid_until') as $field) {
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $data[$field]);
        if (!$date || $date->format('Y-m-d') !== $data[$field] || $data[$field] < '1900-01-01') {
            throw new InvalidArgumentException('Enter valid invoice and validity dates.');
        }
    }
    if ($data['valid_until'] < $data['invoice_date']) {
        throw new InvalidArgumentException('Valid until cannot be earlier than the invoice date.');
    }
    if (!in_array($data['currency'], array('TZS', 'USD', 'KES', 'EUR', 'GBP'), true)) {
        throw new InvalidArgumentException('Select a supported currency.');
    }
    if (!preg_match('/^(0|[1-9][0-9]{0,11})(\.[0-9]{1,2})?$/D', $data['invoice_amount'])) {
        throw new InvalidArgumentException('Enter a non-negative amount with up to 12 whole digits and 2 decimal places.');
    }
    // Keep decimal money as strings from validation through the database binding.
    $parts = explode('.', $data['invoice_amount']);
    $data['invoice_amount'] = $parts[0] . '.' . str_pad($parts[1] ?? '', 2, '0');
    if ($data['email'] !== '' && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
        throw new InvalidArgumentException('Enter a valid email address.');
    }
    $data['invoice_items'] = json_encode($items['items'], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    foreach (array('billing_address'=>250, 'billing_city'=>150, 'billing_tin'=>60) as $field=>$limit) {
        $value = $input[$field] ?? '';
        if (!is_string($value) || mb_strlen(trim($value), 'UTF-8') > $limit || preg_match('/[\x00-\x1f\x7f]/', $value)) {
            throw new InvalidArgumentException('Enter valid customer address and TIN details.');
        }
        $data[$field] = trim($value);
    }
    $data['payment_method'] = $input['payment_method'] ?? 'Bank Transfer';
    if (!is_string($data['payment_method']) || !in_array($data['payment_method'], array('Cash','Cheque','Bank Transfer'), true)) {
        throw new InvalidArgumentException('Choose Cash, Cheque or Bank Transfer.');
    }
    return $data;
}

function fcms_prospect_calculate_items($items)
{
    if (!is_array($items) || count($items) < 1 || count($items) > 50) {
        throw new InvalidArgumentException('Add between 1 and 50 invoice items.');
    }
    $clean = array();
    $totalCents = 0;
    $descriptionBytes = 0;
    foreach ($items as $item) {
        if (!is_array($item) || !isset($item['description'], $item['amount']) ||
            !is_string($item['description']) || !is_string($item['amount'])) {
            throw new InvalidArgumentException('Each invoice item needs a description and an amount.');
        }
        $description = trim($item['description']);
        $amount = trim($item['amount']);
        $descriptionBytes += strlen($description) + 1;
        if ($description === '' || mb_strlen($description, 'UTF-8') > 4000 || $descriptionBytes > 50000 || preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/', $description)) {
            throw new InvalidArgumentException('Enter item descriptions up to 4,000 characters each and 50,000 bytes in total.');
        }
        if (!preg_match('/^(0|[1-9][0-9]{0,11})(\.[0-9]{1,2})?$/D', $amount)) {
            throw new InvalidArgumentException('Item amounts must be non-negative, with up to 12 whole digits and 2 decimal places.');
        }
        $parts = explode('.', $amount);
        $amount = $parts[0] . '.' . str_pad($parts[1] ?? '', 2, '0');
        // Amounts and their sum fit in a 64-bit integer; no floating-point rounding.
        $totalCents += (int)str_replace('.', '', $amount);
        if ($totalCents > 99999999999999) {
            throw new InvalidArgumentException('The invoice total cannot exceed 999,999,999,999.99.');
        }
        $clean[] = array('description' => $description, 'amount' => $amount);
    }
    return array('items' => $clean, 'total' => intdiv($totalCents, 100) . '.' . str_pad((string)($totalCents % 100), 2, '0', STR_PAD_LEFT));
}
