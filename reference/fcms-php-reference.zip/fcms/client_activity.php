<?php
require_once __DIR__ . '/client_lifecycle.php';
fcms_client_session();
require __DIR__ . '/connect.php';
fcms_client_actor($con, true);

// Cached lists must not be able to change status outside the client form.
http_response_code(410);
exit('Use the client Edit form to change Client status.');
