<?php
$clientDeleteType = 'UNION';
require __DIR__ . '/client_delete.php';
