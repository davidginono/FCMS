-- Apply once after the existing client lifecycle/proforma migrations.
ALTER TABLE prospective_clients
    ADD COLUMN billing_address VARCHAR(250) NOT NULL DEFAULT '',
    ADD COLUMN billing_city VARCHAR(150) NOT NULL DEFAULT '',
    ADD COLUMN billing_tin VARCHAR(60) NOT NULL DEFAULT '',
    ADD COLUMN payment_method VARCHAR(20) NOT NULL DEFAULT 'Bank Transfer';

CREATE TABLE sales_invoices (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    client_type VARCHAR(20) NOT NULL,
    client_name VARCHAR(150) NOT NULL,
    region VARCHAR(100) NOT NULL DEFAULT '',
    contact_name VARCHAR(150) NOT NULL DEFAULT '',
    phone VARCHAR(40) NOT NULL DEFAULT '',
    email VARCHAR(190) NOT NULL DEFAULT '',
    invoice_number VARCHAR(60) NOT NULL,
    invoice_date DATE NOT NULL,
    valid_until DATE NOT NULL,
    currency CHAR(3) NOT NULL DEFAULT 'TZS',
    invoice_details TEXT NOT NULL,
    invoice_amount DECIMAL(14,2) UNSIGNED NOT NULL,
    invoice_terms TEXT NOT NULL,
    invoice_items LONGTEXT NOT NULL,
    billing_address VARCHAR(250) NOT NULL DEFAULT '',
    billing_city VARCHAR(150) NOT NULL DEFAULT '',
    billing_tin VARCHAR(60) NOT NULL DEFAULT '',
    payment_method VARCHAR(20) NOT NULL DEFAULT 'Bank Transfer',
    version INT UNSIGNED NOT NULL DEFAULT 0,
    created_by INT NOT NULL,
    updated_by INT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_sales_invoice_number (invoice_number),
    KEY ix_sales_invoice_date (invoice_date, id),
    CONSTRAINT chk_sales_invoice_type CHECK (client_type IN ('SACCOS','AMCOS','UNION','MICROFINANCE','OTHER')),
    CONSTRAINT chk_sales_invoice_dates CHECK (valid_until >= invoice_date),
    CONSTRAINT chk_sales_invoice_items CHECK (JSON_VALID(invoice_items)),
    CONSTRAINT chk_sales_invoice_payment CHECK (payment_method IN ('Cash','Cheque','Bank Transfer'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE sales_invoice_audit (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT UNSIGNED NOT NULL,
    actor_id INT NOT NULL,
    action VARCHAR(20) NOT NULL,
    before_document LONGTEXT NULL,
    after_document LONGTEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY ix_invoice_audit_record (invoice_id, id),
    CONSTRAINT fk_sales_invoice_audit FOREIGN KEY (invoice_id) REFERENCES sales_invoices(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
