-- Apply once after 2026_11_03_client_lifecycle.sql; back up prospective_clients first.
ALTER TABLE prospective_clients ADD COLUMN invoice_items JSON NULL;

-- Preserve each existing quote exactly as one line item, without changing its total.
UPDATE prospective_clients
SET invoice_items = JSON_ARRAY(JSON_OBJECT('description', invoice_details, 'amount', CAST(invoice_amount AS CHAR)))
WHERE invoice_items IS NULL;

ALTER TABLE prospective_clients MODIFY COLUMN invoice_items JSON NOT NULL,
    ADD CONSTRAINT chk_prospect_invoice_items CHECK (JSON_TYPE(invoice_items) = 'ARRAY' AND JSON_LENGTH(invoice_items) BETWEEN 1 AND 50);
