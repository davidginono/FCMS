-- Run ONLY after reconciliation and the updated forms/exports have been verified.
-- Original flags and status values remain in client_status_reconciliation.
ALTER TABLE saccos DROP CONSTRAINT chk_saccos_client_active, DROP COLUMN client_active;
ALTER TABLE amcos DROP CONSTRAINT chk_amcos_client_active, DROP COLUMN client_active;
ALTER TABLE `union` DROP CONSTRAINT chk_union_client_active, DROP COLUMN client_active;
