# Client activity and prospects

PHP/XAMPP FCMS only; no Spring Boot files are changed.

## Deployment

Back up the `saccos`, `amcos` and `union` tables. Run
`2026_11_03_client_lifecycle.sql` once against the application database before
deploying the changed PHP files. The local XAMPP database has already been migrated.
MySQL/MariaDB schema changes auto-commit; do not run this migration a second time.
For another server, use its own database configuration and backup, not local credentials.

For itemized proformas, back up `prospective_clients` and apply
`2026_11_03_prospect_invoice_items.sql` once after the original migration. Existing
quotes are retained as one line with the original description and exact amount.
Deploy the updated PHP, versioned stylesheet and `assets/js/prospect-invoice.js` together.

The operational field is now `status` in SACCOS, AMCOS, unions and Microfinance,
with canonical values `ACTIVE` / `INACTIVE`. Payment status remains separately in
`saccos_status_id` or (for Microfinance) `micro_status_id`; archive/filter flags are
separate. Client status is per register record and year, not a name-based update across years.
Inactive records remain editable; no financial history is deleted. Client-related
PDFs, CSVs, staff/task reports, and income-statement client calculations filter active
records before computing totals. Unrelated expenses/income ledgers are unchanged.

Admins can mark Client status in the last column of all four client registers and their
search results. Changing the dropdown automatically posts the protected form; there
is no separate Save button. JavaScript is required for automatic submission. Admin
add/edit forms share a prepared, transactional save handler and preserve the current
client/payment selections. Stale client-status submissions are rejected. Existing
financial field sets are retained. Staff forms show read-only Client status and do
not gain admin status-change permissions.
Admins can open **Clients > Prospective clients**, create/edit a prospect of any of
the three types, record one current proforma with up to 50 described amount rows,
and print/save its PDF. This is a quotation, not a receipt or tax invoice. Prospect
records do not count as clients or as financial transactions. Conversion to a client,
multiple invoice versions and invoicing tax rules are not
introduced by this change.

All writes require an active admin and a session-bound CSRF token. Activity updates
use a row lock and stale-value check; prospect updates use a version check. Successful
writes redirect and append an audit record. Invoice numbers are unique; new money
values are validated decimal strings and stored as DECIMAL(14,2), never floats.
The browser previews the item total with integer cents; the server independently
validates and adds every amount, ignoring submitted totals. Items are stored as a
bounded JSON snapshot in the same versioned record and transaction as the total.
The PDF prints item descriptions, amounts and the reconciled total, with page breaks
for long text. Proforma text uses standard FPDF Windows-1252 fonts with UTF-8 transliteration.

## Operational-status consolidation

Back up all four client tables and `client_lifecycle_audit`. In a coordinated deployment:

1. Apply `2026_11_03_unify_client_status.sql` once. This reuses SACCOS `status` and
   adds its equivalent to AMCOS/unions. Original statuses, activity flags, payment
   statuses and decisions are retained in `client_status_reconciliation`.
2. Apply `2026_11_03_microfinance_client_status.sql` once. Existing Microfinance
   records default to active; payment statuses do not change.
3. Deploy the PHP and versioned `client-activity.js`. Verify dropdowns, all eight
   admin forms and exports. Compare counts and non-status fields against the backup.
4. Only after verification, apply `2026_11_03_retire_client_active.sql` once. It drops
   the old flags from the original three tables. Their original values remain in
   the snapshot and backup. No client or financial records are deleted.

Any old `client_active=0` or recognized legacy `DOMANT` / `DORMANT` / `INACTIVE`
resolves to inactive. Blank/null SACCOS status follows the old flag. Other nonempty
values resolve to inactive and are marked `unrecognized_review`, never discarded:

```
SELECT client_type, record_id, original_status, resolved_status
FROM client_status_reconciliation WHERE reason = 'unrecognized_review';
```

The local reconciliation found 10 dormant and 2 unrecognized SACCOS statuses. The
latter retain their original values for review. Before/after hashes of every
non-status field matched across all 2,362 local clients, including payment and
financial fields. The application is tested with legacy columns physically absent.

## Verification

PDF exports share `ReportTableHeaders` in `fpdf_report_helpers.php`. Headings wrap
at spaces, header rows grow to the tallest heading, and overly wide tables are
scaled to the printable width together with their data columns. CSV files retain
plain headings because CSV has no cell-formatting metadata. Run
`C:\xampp\php\php.exe tests/pdf_headers_test.php` for layout invariants. The
disposable integration suite also renders 32 PDF report routes with synthetic data.

Lint changed PHP files with `C:\xampp\php\php.exe -l <file>`.
`tests/client_lifecycle_test.php` creates and drops its own randomly named database
on a **disposable loopback MariaDB instance**, refusing port 3306. It does not create
test clients in the application database. Configure `FCMS_TEST_MYSQL_PORT`, then run:

```
C:\xampp\php\php.exe tests/client_lifecycle_test.php
```

Optional browser checks: set `FCMS_TEST_NODE` to Node.js and `NODE_PATH` to a directory
containing Playwright. The tests then check layouts at 320, 375, 768, 1024, 1440 and
1920 pixels and submit status changes in all four disposable registers. Screenshots
and copied code remain in the printed temporary fixture directory; test databases,
servers and synthetic session files are cleaned up. Apache denies access to `tests/`.

## Rollback

Retain the canonical status and prospective/audit/reconciliation tables. Older PHP
that depends on `client_active` requires a forward compatibility migration deriving
flags from the current canonical status before rollback. Never overwrite newer
client edits with the original snapshot. Do not drop prospect/audit
tables or restore an old database backup over newer financial records. A hosted
deployment needs its own migration and verification; editing XAMPP does not publish it.
