-- Schema-only reference; all dumped rows and credentials omitted.

CREATE TABLE `financial_year` (
  `id` int(11) NOT NULL,
  `fyear` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `saccos` (
  `id` int(11) NOT NULL,
  `Saccos_Name` varchar(100) NOT NULL,
  `Entry_Date` date NOT NULL,
  `expire_date` date NOT NULL,
  `Region` varchar(100) NOT NULL,
  `pfile` varchar(100) NOT NULL,
  `Annual_fee` varchar(100) NOT NULL,
  `Amount` varchar(100) NOT NULL,
  `Sys_install_fee` varchar(100) NOT NULL,
  `Training_fee` varchar(100) NOT NULL,
  `Android_fee` varchar(100) NOT NULL,
  `Sys_reinstall_fee` varchar(100) NOT NULL,
  `saccos_status_id` int(11) NOT NULL DEFAULT 1,
  `fyear_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `saccos_status` (
  `sid` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `status` (
  `id` int(11) NOT NULL,
  `status_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `saccos_id` int(11) NOT NULL,
  `task_type_id` int(11) NOT NULL,
  `task_status_id` int(11) DEFAULT 4,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `activities` varchar(100) NOT NULL,
  `Allowance` varchar(100) NOT NULL,
  `Amount` varchar(100) NOT NULL,
  `Comments` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `task_status` (
  `id` int(11) NOT NULL,
  `status_names` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `types` (
  `id` int(11) NOT NULL,
  `tnames` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `status_id` int(11) NOT NULL DEFAULT 1,
  `role_id` int(11) NOT NULL DEFAULT 2,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `financial_year`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`);

ALTER TABLE `saccos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `saccos_status_id` (`saccos_status_id`),
  ADD KEY `fyear_id` (`fyear_id`);

ALTER TABLE `saccos_status`
  ADD PRIMARY KEY (`sid`);

ALTER TABLE `status`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `task_type_id` (`task_type_id`),
  ADD KEY `task_status_id` (`task_status_id`),
  ADD KEY `saccos_id` (`saccos_id`);

ALTER TABLE `task_status`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `types`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `status_id` (`status_id`),
  ADD KEY `role_id` (`role_id`);

ALTER TABLE `financial_year`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

ALTER TABLE `roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

ALTER TABLE `saccos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

ALTER TABLE `saccos_status`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

ALTER TABLE `status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

ALTER TABLE `task_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

ALTER TABLE `types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

ALTER TABLE `saccos`
  ADD CONSTRAINT `saccos_ibfk_1` FOREIGN KEY (`saccos_status_id`) REFERENCES `saccos_status` (`sid`),


--
-- Constraints for table `tasks`
--
ALTER TABLE `tasks`
  ADD CONSTRAINT `tasks_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `tasks_ibfk_2` FOREIGN KEY (`task_type_id`) REFERENCES `types` (`id`),
  ADD CONSTRAINT `tasks_ibfk_3` FOREIGN KEY (`task_status_id`) REFERENCES `task_status` (`id`),
  ADD CONSTRAINT `tasks_ibfk_4` FOREIGN KEY (`saccos_id`) REFERENCES `saccos` (`id`);

ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`),
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`);
