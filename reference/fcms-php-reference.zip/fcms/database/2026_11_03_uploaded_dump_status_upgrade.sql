-- Target baseline: fcms_db-35303539ac53 (6).sql supplied on 2026-11-03.
-- Apply once, after backing up the target database. Not for an already-updated DB.
-- The baseline already has operational columns and empty lifecycle tables.
-- No payment-status, money, ledger, SMS, user, leave or report rows are changed.
SET NAMES utf8mb4;

ALTER TABLE client_status_reconciliation
    MODIFY client_type VARCHAR(20) NOT NULL,
    MODIFY original_client_active TINYINT UNSIGNED NULL;

START TRANSACTION;
-- Preserve source values before removing the duplicate flag. Existing snapshots
-- are retained, never replayed over later edits or overwritten by this migration.
INSERT INTO client_status_reconciliation
    (client_type,record_id,original_status,original_client_active,payment_status_id,resolved_status,reason)
SELECT 'SACCOS',c.id,c.status,c.client_active,c.saccos_status_id,
    CASE WHEN c.client_active=0 THEN 'INACTIVE'
         WHEN UPPER(TRIM(COALESCE(c.status,''))) IN ('','ACTIVE') THEN 'ACTIVE' ELSE 'INACTIVE' END,
    CASE WHEN c.client_active=0 THEN 'activity_inactive'
         WHEN UPPER(TRIM(COALESCE(c.status,''))) IN ('DOMANT','DORMANT','INACTIVE') THEN 'legacy_inactive'
         WHEN UPPER(TRIM(COALESCE(c.status,''))) IN ('','ACTIVE') THEN 'active_or_blank' ELSE 'unrecognized_review' END
FROM saccos c WHERE NOT EXISTS (
    SELECT 1 FROM client_status_reconciliation r WHERE BINARY r.client_type=BINARY 'SACCOS' AND r.record_id=c.id);

INSERT INTO client_status_reconciliation
    (client_type,record_id,original_status,original_client_active,payment_status_id,resolved_status,reason)
SELECT 'AMCOS',c.id,c.status,c.client_active,c.saccos_status_id,
    CASE WHEN c.client_active=0 THEN 'INACTIVE'
         WHEN UPPER(TRIM(COALESCE(c.status,''))) IN ('','ACTIVE') THEN 'ACTIVE' ELSE 'INACTIVE' END,
    CASE WHEN c.client_active=0 THEN 'activity_inactive'
         WHEN UPPER(TRIM(COALESCE(c.status,''))) IN ('DOMANT','DORMANT','INACTIVE') THEN 'legacy_inactive'
         WHEN UPPER(TRIM(COALESCE(c.status,''))) IN ('','ACTIVE') THEN 'active_or_blank' ELSE 'unrecognized_review' END
FROM amcos c WHERE NOT EXISTS (
    SELECT 1 FROM client_status_reconciliation r WHERE BINARY r.client_type=BINARY 'AMCOS' AND r.record_id=c.id);

INSERT INTO client_status_reconciliation
    (client_type,record_id,original_status,original_client_active,payment_status_id,resolved_status,reason)
SELECT 'UNION',c.id,c.status,c.client_active,c.saccos_status_id,
    CASE WHEN c.client_active=0 THEN 'INACTIVE'
         WHEN UPPER(TRIM(COALESCE(c.status,''))) IN ('','ACTIVE') THEN 'ACTIVE' ELSE 'INACTIVE' END,
    CASE WHEN c.client_active=0 THEN 'activity_inactive'
         WHEN UPPER(TRIM(COALESCE(c.status,''))) IN ('DOMANT','DORMANT','INACTIVE') THEN 'legacy_inactive'
         WHEN UPPER(TRIM(COALESCE(c.status,''))) IN ('','ACTIVE') THEN 'active_or_blank' ELSE 'unrecognized_review' END
FROM `union` c WHERE NOT EXISTS (
    SELECT 1 FROM client_status_reconciliation r WHERE BINARY r.client_type=BINARY 'UNION' AND r.record_id=c.id);

INSERT INTO client_status_reconciliation
    (client_type,record_id,original_status,original_client_active,payment_status_id,resolved_status,reason)
SELECT 'MICROFINANCE',c.id,c.status,NULL,c.micro_status_id,
    CASE WHEN UPPER(TRIM(COALESCE(c.status,''))) IN ('','ACTIVE') THEN 'ACTIVE' ELSE 'INACTIVE' END,
    CASE WHEN UPPER(TRIM(COALESCE(c.status,''))) IN ('DOMANT','DORMANT','INACTIVE') THEN 'legacy_inactive'
         WHEN UPPER(TRIM(COALESCE(c.status,''))) IN ('','ACTIVE') THEN 'active_or_blank' ELSE 'unrecognized_review' END
FROM microfinance c WHERE NOT EXISTS (
    SELECT 1 FROM client_status_reconciliation r WHERE BINARY r.client_type=BINARY 'MICROFINANCE' AND r.record_id=c.id);

UPDATE saccos SET status=CASE WHEN client_active=0 THEN 'INACTIVE'
    WHEN UPPER(TRIM(COALESCE(status,''))) IN ('','ACTIVE') THEN 'ACTIVE' ELSE 'INACTIVE' END;
UPDATE amcos SET status=CASE WHEN client_active=0 THEN 'INACTIVE'
    WHEN UPPER(TRIM(COALESCE(status,''))) IN ('','ACTIVE') THEN 'ACTIVE' ELSE 'INACTIVE' END;
UPDATE `union` SET status=CASE WHEN client_active=0 THEN 'INACTIVE'
    WHEN UPPER(TRIM(COALESCE(status,''))) IN ('','ACTIVE') THEN 'ACTIVE' ELSE 'INACTIVE' END;
UPDATE microfinance SET status=CASE WHEN UPPER(TRIM(COALESCE(status,''))) IN ('','ACTIVE') THEN 'ACTIVE' ELSE 'INACTIVE' END;
COMMIT;

ALTER TABLE saccos MODIFY status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    ADD CONSTRAINT chk_saccos_operational_status CHECK (status IN ('ACTIVE','INACTIVE')),
    DROP COLUMN client_active;
ALTER TABLE amcos MODIFY status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    ADD CONSTRAINT chk_amcos_operational_status CHECK (status IN ('ACTIVE','INACTIVE')),
    DROP COLUMN client_active;
ALTER TABLE `union` MODIFY status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    ADD CONSTRAINT chk_union_operational_status CHECK (status IN ('ACTIVE','INACTIVE')),
    DROP COLUMN client_active;
ALTER TABLE microfinance MODIFY status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    ADD CONSTRAINT chk_microfinance_operational_status CHECK (status IN ('ACTIVE','INACTIVE'));
