-- Apply once after client_lifecycle.sql. Back up all three client tables first.
-- Payment status (saccos_status_id) and all financial fields are left unchanged.
ALTER TABLE amcos ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE';
ALTER TABLE `union` ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE';

CREATE TABLE client_status_reconciliation (
    client_type VARCHAR(10) NOT NULL,
    record_id INT NOT NULL,
    original_status VARCHAR(100) NULL,
    original_client_active TINYINT UNSIGNED NOT NULL,
    payment_status_id INT NULL,
    resolved_status VARCHAR(20) NOT NULL,
    reason VARCHAR(40) NOT NULL,
    recorded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (client_type, record_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

START TRANSACTION;
INSERT INTO client_status_reconciliation
SELECT 'SACCOS', id, status, client_active, saccos_status_id,
    CASE WHEN client_active = 0 OR UPPER(TRIM(COALESCE(status, ''))) IN ('DOMANT', 'DORMANT', 'INACTIVE') THEN 'INACTIVE'
         WHEN UPPER(TRIM(COALESCE(status, ''))) IN ('', 'ACTIVE') THEN 'ACTIVE' ELSE 'INACTIVE' END,
    CASE WHEN client_active = 0 THEN 'activity_inactive'
         WHEN UPPER(TRIM(COALESCE(status, ''))) IN ('DOMANT', 'DORMANT', 'INACTIVE') THEN 'legacy_inactive'
         WHEN UPPER(TRIM(COALESCE(status, ''))) IN ('', 'ACTIVE') THEN 'active_or_blank'
         ELSE 'unrecognized_review' END, CURRENT_TIMESTAMP
FROM saccos FOR UPDATE;

INSERT INTO client_status_reconciliation
SELECT 'AMCOS', id, NULL, client_active, saccos_status_id,
    IF(client_active = 1, 'ACTIVE', 'INACTIVE'), 'activity_flag', CURRENT_TIMESTAMP
FROM amcos FOR UPDATE;
INSERT INTO client_status_reconciliation
SELECT 'UNION', id, NULL, client_active, saccos_status_id,
    IF(client_active = 1, 'ACTIVE', 'INACTIVE'), 'activity_flag', CURRENT_TIMESTAMP
FROM `union` FOR UPDATE;

UPDATE saccos c JOIN client_status_reconciliation r ON r.client_type='SACCOS' AND r.record_id=c.id SET c.status=r.resolved_status;
UPDATE amcos c JOIN client_status_reconciliation r ON r.client_type='AMCOS' AND r.record_id=c.id SET c.status=r.resolved_status;
UPDATE `union` c JOIN client_status_reconciliation r ON r.client_type='UNION' AND r.record_id=c.id SET c.status=r.resolved_status;
COMMIT;

ALTER TABLE saccos MODIFY COLUMN status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    ADD CONSTRAINT chk_saccos_operational_status CHECK (status IN ('ACTIVE', 'INACTIVE'));
ALTER TABLE amcos ADD CONSTRAINT chk_amcos_operational_status CHECK (status IN ('ACTIVE', 'INACTIVE'));
ALTER TABLE `union` ADD CONSTRAINT chk_union_operational_status CHECK (status IN ('ACTIVE', 'INACTIVE'));
