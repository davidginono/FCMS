-- Bulk SMS income/unit tracking migration
-- Run this once on the target FCMS database.
--
-- What this does:
-- 1. Adds SMS unit movement and running balance columns.
-- 2. Renames transaction categories to match the business meaning.
-- 3. Swaps historical amount columns so client sales become Amount In and
--    provider/SMS stock costs become Amount Out.

ALTER TABLE `bulk_sms`
  ADD COLUMN IF NOT EXISTS `sms_units_in` INT(11) NOT NULL DEFAULT 0 AFTER `amount_out`,
  ADD COLUMN IF NOT EXISTS `sms_units_out` INT(11) NOT NULL DEFAULT 0 AFTER `sms_units_in`,
  ADD COLUMN IF NOT EXISTS `sms_balance_before` INT(11) NOT NULL DEFAULT 0 AFTER `sms_units_out`,
  ADD COLUMN IF NOT EXISTS `sms_balance_after` INT(11) NOT NULL DEFAULT 0 AFTER `sms_balance_before`;

CREATE TABLE IF NOT EXISTS `fcms_schema_migrations` (
  `name` VARCHAR(120) NOT NULL PRIMARY KEY,
  `applied_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

UPDATE `trans_cat`
SET `trans_name` = CASE `id`
  WHEN 1 THEN 'SMS Stock Purchase'
  WHEN 2 THEN 'Client SMS Sale'
  ELSE `trans_name`
END
WHERE `id` IN (1, 2);

-- Historical correction:
-- Old data used amount_in for SMS stock/provider payments and amount_out for
-- client sales. The business meaning now is the reverse.
ALTER TABLE `bulk_sms`
  ADD COLUMN IF NOT EXISTS `_amount_swap_tmp` INT(100) NULL;

UPDATE `bulk_sms`
SET
  `_amount_swap_tmp` = COALESCE(`amount_in`, 0)
WHERE NOT EXISTS (
    SELECT 1 FROM `fcms_schema_migrations`
    WHERE `name` = '2026_06_23_bulk_sms_income_units_migration'
  )
  AND (
    COALESCE(`amount_in`, 0) <> 0
    OR COALESCE(`amount_out`, 0) <> 0
  );

UPDATE `bulk_sms`
SET
  `amount_in` = COALESCE(`amount_out`, 0),
  `amount_out` = COALESCE(`_amount_swap_tmp`, 0)
WHERE NOT EXISTS (
    SELECT 1 FROM `fcms_schema_migrations`
    WHERE `name` = '2026_06_23_bulk_sms_income_units_migration'
  )
  AND (
    COALESCE(`_amount_swap_tmp`, 0) <> 0
    OR COALESCE(`amount_out`, 0) <> 0
  );

ALTER TABLE `bulk_sms`
  DROP COLUMN `_amount_swap_tmp`;

INSERT IGNORE INTO `fcms_schema_migrations` (`name`)
VALUES ('2026_06_23_bulk_sms_income_units_migration');
