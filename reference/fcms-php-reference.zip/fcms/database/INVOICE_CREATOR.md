# Invoice creator and company invoice template

The PHP/XAMPP application exposes **Clients > Invoices** (`invoices.php`) to active
administrators. SACCOS, AMCOS, Union, Microfinance and Other invoices have manually
entered customer details, a unique invoice number, invoice/due dates, currency,
1–50 description/amount items, billing address/city/TIN, payment method and notes.
The existing Prospective clients page remains the proforma creator.

Both print/PDF actions use `invoice_pdf.php`, based on the supplied Excel invoice's
logo, contact block, customer/date boxes, Item/Description/Total Cost/Amount table,
cyan amount column, subtotal/total and payment/office-use areas. Bank and contact
details are transcribed from that template. The supplied transparent company stamp
is copied unchanged to `assets/images/company-stamp.png`. No source workbook macros
are included or run. The original spreadsheet is not modified.

The supplied compact reference is reproduced on a 210 x 249 mm PDF page: rounded
blue customer/date/payment outlines, dotted writing guides, dashed table rules,
continuous cyan amounts, red document number, bold item amounts, payment-method
checkboxes and the blue bottom ribbon. The original grey Office Use Only rectangle
is unchanged; the stamp keeps its horizontal position and size and sits 10 mm higher.
Whole monetary values omit `.00` as in the template; nonzero cents remain visible
and no stored amount is rounded or changed. The retained due/validity date uses a
spare date-box row. Extra terms/notes use separate continuation pages. Long items
continue within the template table and retain every description and amount.

Invoice/Proforma Invoice labels are embedded in gaps in the blue header rule.
All 44 active root PHP print pages load `assets/js/print-preview.js` and its small
stylesheet. The shared handler fetches existing same-origin PDF endpoints with the
original GET/POST filters and opens native browser print preview from an offscreen
PDF frame, retaining the current URL and unsaved form values. It never submits a
physical print automatically. Download-marked PDF links and CSV/Excel actions bypass
printing. Invoice/proforma forms expose separate Print and Download PDF controls.
JavaScript and the browser's PDF viewer must be enabled. If a viewer cannot print,
the same-page notice offers retry and PDF download; it does not silently navigate.

Print checks: `tests/print_preview_test.php` verifies coverage of all print pages.
`tests/print_preview_ui_test.cjs <synthetic-pdf-path>` checks GET/POST filters, submitter
overrides, same-page printing, repeat printing, cancel/error paths, downloads and
notice layout. Set `FCMS_NATIVE_PRINT_TEST=1` for a headed Chromium native-preview
check; it checks that the print dialog opens and closes the browser without sending
a physical print job. Use only synthetic PDFs for this test.

Run `2026_11_03_invoice_creator.sql` once after the client lifecycle migrations and
before publishing the changed PHP files. It adds billing columns to prospects and
creates `sales_invoices` and `sales_invoice_audit`. Existing quote items/totals and
client/payment records are untouched. Creating an invoice does not record receipt
of funds or post income, fees, account balances or ledger entries. No automatic VAT,
tax-authority submission, sending/emailing or payment collection is introduced.

Money is calculated using integer cents and stored as DECIMAL(14,2), never trusted
from the browser total. PDF exports reconcile stored totals against their items.
Unique numbers protect against duplicate submissions; updates reject stale record
versions and atomically record before/after documents and the authenticated actor.
There is no delete endpoint. Pages and exports enforce admin authorization; POSTs
enforce CSRF. Lists are limited to 50 rows per page. Exports are PDF, not executable
copies of the original macro-enabled XLS template.

Verification: run `tests/client_lifecycle_test.php` against a disposable non-3306
MariaDB instance. It includes invoice creation/editing, authorization, CSRF, duplicate
and stale writes, exact/reconciled totals, billing values and embedded stamp/logo
checks. Set `FCMS_TEST_NODE` and `NODE_PATH` for Playwright form tests at 320, 375,
768, 1024, 1440 and 1920 px. Test PDFs/screenshots stay in the printed temporary
fixture directory; no synthetic invoices are inserted in the application database.

Rollback: retain invoice and audit data and restore compatible PHP files together.
Do not drop financial/audit tables or restore an old database over newer invoices.
The local pre-migration prospect dump is retained in the system temporary directory.
A hosted deployment requires its own backup, migration and file publication.
