-- Run once against the FCMS database before deploying the corresponding PHP files.
-- Existing clients remain active. Legacy status/payment/filter fields are not changed.
ALTER TABLE saccos ADD COLUMN client_active TINYINT UNSIGNED NOT NULL DEFAULT 1,
    ADD CONSTRAINT chk_saccos_client_active CHECK (client_active IN (0, 1));
ALTER TABLE amcos ADD COLUMN client_active TINYINT UNSIGNED NOT NULL DEFAULT 1,
    ADD CONSTRAINT chk_amcos_client_active CHECK (client_active IN (0, 1));
ALTER TABLE `union` ADD COLUMN client_active TINYINT UNSIGNED NOT NULL DEFAULT 1,
    ADD CONSTRAINT chk_union_client_active CHECK (client_active IN (0, 1));

CREATE TABLE prospective_clients (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    client_type ENUM('SACCOS', 'AMCOS', 'UNION') NOT NULL,
    client_name VARCHAR(150) NOT NULL,
    region VARCHAR(100) NOT NULL DEFAULT '',
    contact_name VARCHAR(150) NOT NULL DEFAULT '',
    phone VARCHAR(40) NOT NULL DEFAULT '',
    email VARCHAR(190) NOT NULL DEFAULT '',
    invoice_number VARCHAR(60) NOT NULL,
    invoice_date DATE NOT NULL,
    valid_until DATE NOT NULL,
    currency CHAR(3) NOT NULL DEFAULT 'TZS',
    invoice_details TEXT NOT NULL,
    invoice_amount DECIMAL(14,2) UNSIGNED NOT NULL,
    invoice_terms TEXT NOT NULL,
    version INT UNSIGNED NOT NULL DEFAULT 0,
    created_by INT NOT NULL,
    updated_by INT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_prospect_invoice (invoice_number),
    KEY ix_prospect_type_name (client_type, client_name, id),
    CONSTRAINT chk_prospect_validity CHECK (valid_until >= invoice_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE client_lifecycle_audit (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    actor_id INT NOT NULL,
    action VARCHAR(40) NOT NULL,
    client_type VARCHAR(10) NOT NULL,
    record_id INT UNSIGNED NOT NULL,
    before_value VARCHAR(20) NOT NULL DEFAULT '',
    after_value VARCHAR(20) NOT NULL DEFAULT '',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY ix_client_lifecycle_record (client_type, record_id, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
