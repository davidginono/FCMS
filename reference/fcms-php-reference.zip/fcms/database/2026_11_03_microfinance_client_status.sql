-- Apply after unify_client_status.sql. Microfinance had payment status only.
ALTER TABLE microfinance ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    ADD CONSTRAINT chk_microfinance_operational_status CHECK (status IN ('ACTIVE', 'INACTIVE'));
ALTER TABLE client_lifecycle_audit MODIFY COLUMN client_type VARCHAR(20) NOT NULL;
ALTER TABLE client_status_reconciliation MODIFY COLUMN client_type VARCHAR(20) NOT NULL,
    MODIFY COLUMN original_client_active TINYINT UNSIGNED NULL;
INSERT INTO client_status_reconciliation
SELECT 'MICROFINANCE', id, NULL, NULL, micro_status_id, 'ACTIVE', 'new_default', CURRENT_TIMESTAMP
FROM microfinance;
