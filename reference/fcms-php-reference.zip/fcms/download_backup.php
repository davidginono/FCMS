<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
$sessionDirectory = '/home/sites/37b/1/15b6335fc9/fcms/sessions';
ini_set('session.save_path', $sessionDirectory);
session_start();

if (!isset($_SESSION['email'])) {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}
if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != '1') {
    header("location:user_dashboard.php");
    exit();
}

$file = basename($_GET['file'] ?? '');
$backup_dir = dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'fcms_backups' . DIRECTORY_SEPARATOR;
$filePath = $backup_dir . $file;

if ($file === '' || !preg_match('/^backup_[0-9_-]+\.sql$/', $file) || !is_file($filePath)) {
    header("location:backup.php");
    exit();
}

header('Content-Type: application/sql');
header('Content-Disposition: attachment; filename="' . $file . '"');
header('Content-Length: ' . filesize($filePath));
readfile($filePath);
exit();
?>
