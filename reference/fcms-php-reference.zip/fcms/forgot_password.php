<?php
require("connect.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Password Reset</title>

    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta name="description" content="Password Reset">
    <meta name="author" content="Xiaoying Riley at 3rd Wave Media">    
    <link rel="shortcut icon" href="favicon.ico"> 

    <!-- FontAwesome JS -->
    <script defer src="assets/plugins/fontawesome/js/all.min.js"></script>

    <!-- App CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/portal.css?v=20260712-7">
</head>

<body class="app app-reset-password p-0">    
    <div class="row g-0 app-auth-wrapper justify-content-center">
        <div class="col-12 col-md-8 col-lg-6 auth-main-col text-center p-5">
            <div class="d-flex flex-column align-content-end">
                <div class="app-auth-body mx-auto">
                    <!-- Bootstrap Card -->
                    <div class="card shadow-lg">
                        <div class="card-body">
                            <div class="card-header text-center">
                        <h4>Forgot Password</h4>
                    </div>

                            <p class="auth-intro mb-4 text-center">Enter your email address below. We'll email you a link to a page where you can create a new password.</p>

                            <div class="col-lg-12">
                                <!-- Password Reset Form -->
                                <form class="user" action="password_request.php" method="post">                
                                    <div class="email mb-3">
                                        <label class="sr-only" for="reg-email">Your Email</label>
                                        <input id="reg-email" name="email" type="email" class="form-control login-email" placeholder="Enter your email" required="required">
                                    </div>

                                    <div class="text-center">
                                        <button type="submit" class="btn app-btn-primary btn-block theme-btn mx-auto">Send Reset Link</button>
                                    </div>
                                </form>
                                <!--//Password Reset Form-->

                                <div class="auth-option text-center pt-4">
                                    <a class="app-link" href="index.php" style="text-decoration:none;color:blue">Back to Login</a>
                                </div>
                            </div>
                        </div><!--//card-body-->
                    </div><!--//card-->
                </div><!--//app-auth-body-->
            </div><!--//flex-column-->   
        </div><!--//auth-main-col-->
    </div><!--//row-->

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
