FCMS PHP read-only reference snapshot, 2026-11-16
See reference/README.md in the Spring repository before extracting.
Credentials/mail identities are redacted. Runtime/user files and dumped database rows are omitted.
CODES, CODE2 and images contain historical application copies; root PHP files are canonical.
This archive is for source inspection, not deployment or connection to an operational database.
