<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
// Start the session and set custom session directory
$sessionDirectory = '/home/sites/37b/1/15b6335fc9/fcms/sessions';
ini_set('session.save_path', $sessionDirectory);
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    // If not logged in, redirect to the login page
echo "<script>window.location.href='index.php';</script>";
    exit();
}

require('connect.php');
?>

<!DOCTYPE html>
<html lang="en"> 
<head>
    <link rel="stylesheet" href="assets/css/print-preview.css?v=20261103-1">
    <script defer src="assets/js/print-preview.js?v=20261103-1"></script>
    <title>FCMS |   PETTY CASH </title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="description" content="Portal - Bootstrap 5 Admin Dashboard Template For Developers">
    <meta name="author" content="Tean Tech">    
   
    
    <!-- FontAwesome JS-->
    <script defer src="assets/plugins/fontawesome/js/all.min.js"></script>
    
    <!-- App CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/portal.css?v=20260712-7">

    <link rel="stylesheet" href="assets/css/table-actions.css?v=20261105-1">
    <script defer src="assets/js/table-actions.js?v=20261105-1"></script>
</head> 

<body class="app">   	
    <header class="app-header fixed-top">	   	            
        <div class="app-header-inner">  
	        <div class="container-fluid py-2">
		        <div class="app-header-content"> 
		            <div class="row justify-content-between align-items-center">
				    <div class="col-auto">
					    <a id="sidepanel-toggler" class="sidepanel-toggler d-inline-block d-xl-none" href="#">
						    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" role="img"><title>Menu</title><path stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2" d="M4 7h22M4 15h22M4 23h22"></path></svg>
					    </a>
				    </div><!--//col-->
		            <div class="search-mobile-trigger d-sm-none col">
			            <i class="search-mobile-trigger-icon fa-solid fa-magnifying-glass"></i>
			        </div><!--//col-->
		            <div class="app-search-box col">
		              
		            </div><!--//app-search-box-->
		            
		            <div class="app-utilities col-auto">
			            <div class="app-utility-item app-notifications-dropdown dropdown">    
				            <a class="dropdown-toggle no-toggle-arrow" id="notifications-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false" title="Notifications">
					            <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					            
					            
					        </a><!--//dropdown-toggle-->
					        
					        			        
				        </div><!--//app-utility-item-->
			          
			            
						<div class="app-utility-item app-user-dropdown dropdown">
				            <a class="dropdown-toggle" id="user-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"><span class="navbar-profile-icon"><i class="fa-solid fa-user"></i></span></a><ul class="dropdown-menu" aria-labelledby="user-dropdown-toggle">
								<li><a class="dropdown-item" href="account.php">Account</a></li>
								<li><a class="dropdown-item" href="change_password.php">Change Password</a></li>
								<li><a class="dropdown-item" href="change_profile.php">Change Profile Picture</a></li>
								<li><hr class="dropdown-divider"></li>
								<li><a class="dropdown-item" href="logout.php">Log Out</a></li>
							</ul>
			            </div><!--//app-user-dropdown--> 
		            </div><!--//app-utilities-->
		        </div><!--//row-->
	            </div><!--//app-header-content-->
	        </div><!--//container-fluid-->
        </div><!--//app-header-inner-->
        
        
             <div id="app-sidepanel" class="app-sidepanel"> 
	        <div id="sidepanel-drop" class="sidepanel-drop"></div>
	        <div class="sidepanel-inner d-flex flex-column">
		        <a href="#" id="sidepanel-close" class="sidepanel-close d-xl-none">&times;</a>
		        <div class="app-branding">
		            <a class="app-logo" href="admin.php"><img class="logo-icon me-2" src="assets/images/app-logo.png" alt="logo"><span class="logo-text">FCMS</span></a>
	
		        </div><!--//app-branding-->  
		        
			    <nav id="app-nav-main" class="app-nav app-nav-main flex-grow-1">
				    <ul class="app-menu list-unstyled accordion" id="menu-accordion">
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link active" href="admin.php">
						        <span class="nav-icon">
						        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-house-door" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
		  <path fill-rule="evenodd" d="M7.646 1.146a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 .146.354v7a.5.5 0 0 1-.5.5H9.5a.5.5 0 0 1-.5-.5v-4H7v4a.5.5 0 0 1-.5.5H2a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .146-.354l6-6zM2.5 7.707V14H6v-4a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4h3.5V7.707L8 2.207l-5.5 5.5z"/>
		  <path fill-rule="evenodd" d="M13 2.5V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
		</svg>
						         </span>
		                         <span class="nav-link-text">Dashboard</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="admin2.php">
						        <span class="nav-icon">
						        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-speedometer2" viewBox="0 0 16 16">
  <path d="M8 4a.5.5 0 0 1 .5.5V6a.5.5 0 0 1-1 0V4.5A.5.5 0 0 1 8 4M3.732 5.732a.5.5 0 0 1 .707 0l.915.914a.5.5 0 1 1-.708.708l-.914-.915a.5.5 0 0 1 0-.707M2 10a.5.5 0 0 1 .5-.5h1.586a.5.5 0 0 1 0 1H2.5A.5.5 0 0 1 2 10m9.5 0a.5.5 0 0 1 .5-.5h1.5a.5.5 0 0 1 0 1H12a.5.5 0 0 1-.5-.5m.754-4.246a.39.39 0 0 0-.527-.02L7.547 9.31a.91.91 0 1 0 1.302 1.258l3.434-4.297a.39.39 0 0 0-.029-.518z"/>
  <path fill-rule="evenodd" d="M0 10a8 8 0 1 1 15.547 2.661c-.442 1.253-1.845 1.602-2.932 1.25C11.309 13.488 9.475 13 8 13c-1.474 0-3.31.488-4.615.911-1.087.352-2.49.003-2.932-1.25A8 8 0 0 1 0 10m8-7a7 7 0 0 0-6.603 9.329c.203.575.923.876 1.68.63C4.397 12.533 6.358 12 8 12s3.604.532 4.923.96c.757.245 1.477-.056 1.68-.631A7 7 0 0 0 8 3"/>
</svg>
						         </span>
		                         <span class="nav-link-text">Amcos Dashboard</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="admin3.php">
						        <span class="nav-icon">
						        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-speedometer2" viewBox="0 0 16 16">
  <path d="M8 4a.5.5 0 0 1 .5.5V6a.5.5 0 0 1-1 0V4.5A.5.5 0 0 1 8 4M3.732 5.732a.5.5 0 0 1 .707 0l.915.914a.5.5 0 1 1-.708.708l-.914-.915a.5.5 0 0 1 0-.707M2 10a.5.5 0 0 1 .5-.5h1.586a.5.5 0 0 1 0 1H2.5A.5.5 0 0 1 2 10m9.5 0a.5.5 0 0 1 .5-.5h1.5a.5.5 0 0 1 0 1H12a.5.5 0 0 1-.5-.5m.754-4.246a.39.39 0 0 0-.527-.02L7.547 9.31a.91.91 0 1 0 1.302 1.258l3.434-4.297a.39.39 0 0 0-.029-.518z"/>
  <path fill-rule="evenodd" d="M0 10a8 8 0 1 1 15.547 2.661c-.442 1.253-1.845 1.602-2.932 1.25C11.309 13.488 9.475 13 8 13c-1.474 0-3.31.488-4.615.911-1.087.352-2.49.003-2.932-1.25A8 8 0 0 1 0 10m8-7a7 7 0 0 0-6.603 9.329c.203.575.923.876 1.68.63C4.397 12.533 6.358 12 8 12s3.604.532 4.923.96c.757.245 1.477-.056 1.68-.631A7 7 0 0 0 8 3"/>
</svg>
						         </span>
		                         <span class="nav-link-text">Union Dashboard</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
	

						<li class="nav-item has-submenu">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-2" aria-expanded="false" aria-controls="submenu-2">
						        <span class="nav-icon">
								<i class="fas fa-fw fa-building"></i>
						        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
						        
						         </span>
		                         <span class="nav-link-text">Clients</span>
		                         <span class="submenu-arrow">
		                             <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
	</svg>
	                             </span><!--//submenu-arrow-->
					        </a><!--//nav-link-->
					        <div id="submenu-2" class="collapse submenu submenu-2" data-bs-parent="#menu-accordion">
						        <ul class="submenu-list list-unstyled">
								    <?php require __DIR__ . '/admin_client_menu.php'; ?>

						        </ul>
					        </div>
					    </li><!--//nav-item-->

			<div>

			
			</div>
						
					
					
					    <li class="nav-item has-submenu">

					      
					        <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-1" aria-expanded="false" aria-controls="submenu-1">
						        <span class="nav-icon">
						        <i class="fas fa-fw fa-users"></i>
						         </span>
		                         <span class="nav-link-text">Users</span>
		                         <span class="submenu-arrow">
		                             <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
	</svg>
	                             </span>
					        </a>
					        <div id="submenu-1" class="collapse submenu submenu-1" data-bs-parent="#menu-accordion">
						        <ul class="submenu-list list-unstyled">
								    <li class="submenu-item"><a class="submenu-link" href="add_user.php"> Add New Users</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="users.php">All Users</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="active_users.php">Active Users</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="inactive_users.php">Inactive Users</a></li>
					
						        </ul>
					        </div>
					    </li>


					
						

						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="all_task.php">
						        <span class="nav-icon">
								<i class="fas fa-fw fa-tasks"></i>
						         </span>
		                         <span class="nav-link-text">Tasks</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					     <li class="nav-item has-submenu">

					      
					        <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-3" aria-expanded="false" aria-controls="submenu-3">
						        <span class="nav-icon">
						        <i class="fas fa-fw fa-file"></i>
						         </span>
		                         <span class="nav-link-text">Reports</span>
		                         <span class="submenu-arrow">
		                             <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
	</svg>
	                             </span>
					        </a>
					        <div id="submenu-3" class="collapse submenu submenu-3" data-bs-parent="#menu-accordion">
						        <ul class="submenu-list list-unstyled">

								    <li class="submenu-item"><a class="submenu-link" href="report.php"> Saccos Report</a></li>
                                    <li class="submenu-item"><a class="submenu-link" href="union_report.php"> Union Report</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="microfinance_report.php">Microfinance Report</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="other_report.php">Other Client Report</a></li>
							        						            <li class="submenu-item"><a class="submenu-link" href="staff_report.php"> Staff Report</a></li>
							             <li class="submenu-item"><a class="submenu-link" href="income_statement.php">Income Statement</a></li>
					
						        </ul>
					        </div>
					    </li>
					

						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="leaves.php">
						        <span class="nav-icon">
								<i class="fas fa-fw fa-file-pdf"></i>
						         </span>
		                         <span class="nav-link-text">Staff Leaves</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->

						
					    
					    						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="expenses.php">
						        <span class="nav-icon">
						            <i class="fa-solid fa-sack-xmark"></i>
	
						         </span>
		                         <span class="nav-link-text">Expenses</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="income.php">
						        <span class="nav-icon">
				<i class="fa-solid fa-sack-dollar"></i>
						         </span>
		                         <span class="nav-link-text">Other Income</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="petty_cash.php">
						        <span class="nav-icon">
				<i class="fa-solid fa-sack-dollar"></i>
						         </span>
		                         <span class="nav-link-text">Petty Cash</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					     
   <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="cloud_backup.php">
						        <span class="nav-icon">
				<i class="fa-solid fa-sack-dollar"></i>
						         </span>
		                         <span class="nav-link-text">Cloud Backup</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
<li class="nav-item">
    <!-- Font Awesome icon -->
    <a class="nav-link" href="backup.php">
        <span class="nav-icon">
            <i class="fas fa-hdd"></i> <!-- Hard drive icon -->
        </span>
        <span class="nav-link-text">System Backup</span>
    </a>
</li>





						
    
					
						
					 

					   
					    
					    
										    
				    </ul><!--//app-menu-->

					
			    </nav><!--//app-nav-->
			    <div class="app-sidepanel-footer">
				    <div class="sidepanel-company">
					    <img class="sidepanel-company-logo" src="assets/images/app-logo.png" alt="Computer Recources ltd">
					    <span class="sidepanel-company-text">Computer Recources ltd</span>
				    </div>
			    </div><!--//app-sidepanel-footer-->
		       
	        </div><!--//sidepanel-inner-->
	    </div><!--//app-sidepanel-->

    </header><!--//app-header-->
    
    <div class="app-wrapper" >
	    
	    <div class="app-content pt-3 p-md-3 p-lg-4" style="margin-top:10px";>
		    <div class="container-xl">
			    
			    <div class="row g-3 mb-4 align-items-center justify-content-between">
				    <div class="col-auto">
			            <h1 class="app-page-title mb-0">BULK SMS PROFIT</h1>
				    </div>
				    <div class="col-auto">
					     <div class="page-utilities">
						    <div class="row g-2 justify-content-start justify-content-md-end align-items-center">
							    <div class="col-auto">


					                
							    </div><!--//col-->
							  
							
						    </div><!--//row-->
					    </div><!--//table-utilities-->
				    </div><!--//col-auto-->

					

			    </div><!--//row-->

				  <a href="bulk_credit.php" class="btn btn-info btn-icon-split"></span><span class="text"> &nbsp;SMS Stock Purchase</span></a>
				  	  <a href="bulk_debit.php" class="btn btn-success btn-icon-split"></span><span class="text"> <i class="fas fa-fw fa-plus"></i>&nbsp;Client SMS Sale</span></a>
				  	<!--   <a href="filter_expenses2.php" class="btn btn-success btn-icon-split"></span><span class="text"> <i class="fas fa-fw fa-filter"></i>&nbsp;Filter by Category</span></a>-->
						 <!--<a href="all_cat.php" class="btn btn-success btn-icon-split"></span><span class="text"> <i class="fas fa-fw fa-filter"></i>&nbsp;All Category</span></a>-->
				  	<!--   	<a href="filter_staff.php" class="btn btn-success btn-icon-split"></span><span class="text"> <i class="fas fa-fw fa-filter"></i>&nbsp;Filter By Staff</span></a>-->
				  	<!--   	<a href="filter_year.php" class="btn btn-success btn-icon-split"></span><span class="text"> <i class="fas fa-fw fa-filter"></i>&nbsp;Filter By Year</span></a>-->
				  	   	
				  	<!--   		   	<a href="filt er_dates.php" class="btn btn-success btn-icon-split"></span><span class="text"> <i class="fas fa-fw fa-filter"></i>&nbsp;Filter By dates</span></a>-->
				  <br><br>

	
<?php
require("connect.php");

function bulkSmsMoney($value) {
    return number_format((float)($value ?? 0), 2);
}

function bulkSmsInt($value) {
    return number_format((int)($value ?? 0));
}

$currentYear = (int)date('Y');
$yearRangeResult = mysqli_query($con, "SELECT MIN(YEAR(trans_date)) AS min_year, MAX(YEAR(trans_date)) AS max_year FROM bulk_sms");
$yearRange = $yearRangeResult ? mysqli_fetch_assoc($yearRangeResult) : null;
$minYear = !empty($yearRange['min_year']) ? (int)$yearRange['min_year'] : $currentYear;
$maxYear = max($currentYear, !empty($yearRange['max_year']) ? (int)$yearRange['max_year'] : $currentYear);

$selectedYear = isset($_GET['year']) && $_GET['year'] !== '' ? (int)$_GET['year'] : $currentYear;
$selectedCategory = isset($_GET['category']) ? trim($_GET['category']) : '';
$dateFrom = isset($_GET['date_from']) ? trim($_GET['date_from']) : '';
$dateTo = isset($_GET['date_to']) ? trim($_GET['date_to']) : '';

$whereParts = [];
if ($selectedYear > 0) {
    $whereParts[] = "YEAR(bulk_sms.trans_date) = " . $selectedYear;
}
if ($selectedCategory !== '' && ctype_digit($selectedCategory)) {
    $whereParts[] = "bulk_sms.trans_id = " . (int)$selectedCategory;
}
if ($dateFrom !== '') {
    $whereParts[] = "bulk_sms.trans_date >= '" . mysqli_real_escape_string($con, $dateFrom) . "'";
}
if ($dateTo !== '') {
    $whereParts[] = "bulk_sms.trans_date <= '" . mysqli_real_escape_string($con, $dateTo) . "'";
}

$whereSql = $whereParts ? "WHERE " . implode(" AND ", $whereParts) : "";

$query = "SELECT bulk_sms.id, fname, trans_date, trans_name, description, amount_in, amount_out,
                 sms_units_in, sms_units_out, sms_balance_before, sms_balance_after, bulk_sms.created_at
          FROM bulk_sms
          INNER JOIN users ON bulk_sms.user_id = users.id
          INNER JOIN trans_cat ON bulk_sms.trans_id = trans_cat.id
          $whereSql
          ORDER BY trans_date DESC, bulk_sms.id DESC";

$result1 = mysqli_query($con, $query);

$totalQuery = "SELECT
                 COALESCE(SUM(amount_in), 0) AS total_in,
                 COALESCE(SUM(amount_out), 0) AS total_out,
                 COALESCE(SUM(sms_units_in), 0) AS units_in,
                 COALESCE(SUM(sms_units_out), 0) AS units_out
               FROM bulk_sms
               $whereSql";
$totalResult = mysqli_query($con, $totalQuery);
$totals = mysqli_fetch_assoc($totalResult);

$total_in = (float)($totals['total_in'] ?? 0);
$total_out = (float)($totals['total_out'] ?? 0);
$units_in = (int)($totals['units_in'] ?? 0);
$units_out = (int)($totals['units_out'] ?? 0);
$profit = $total_in - $total_out;

$currentUnitsResult = mysqli_query($con, "SELECT COALESCE(SUM(sms_units_in), 0) - COALESCE(SUM(sms_units_out), 0) AS current_units FROM bulk_sms");
$currentUnitsRow = $currentUnitsResult ? mysqli_fetch_assoc($currentUnitsResult) : ['current_units' => 0];
$currentSmsUnits = (int)($currentUnitsRow['current_units'] ?? 0);

$categoryResult = mysqli_query($con, "SELECT id, trans_name FROM trans_cat ORDER BY id ASC");
$printQuery = http_build_query(array_filter([
    'year' => $selectedYear ?: null,
    'category' => $selectedCategory !== '' ? $selectedCategory : null,
    'date_from' => $dateFrom !== '' ? $dateFrom : null,
    'date_to' => $dateTo !== '' ? $dateTo : null,
], function ($value) {
    return $value !== null && $value !== '';
}));
?>

<div class="card-body">
        <div class="row g-3 mb-3">
            <div class="col-12 col-md-3">
                <div class="app-card app-card-stat shadow-sm h-100">
                    <div class="app-card-body p-3">
                        <h4 class="stats-type mb-1">Current SMS Units</h4>
                        <div class="stats-figure"><?php echo bulkSmsInt($currentSmsUnits); ?></div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-3">
                <div class="app-card app-card-stat shadow-sm h-100">
                    <div class="app-card-body p-3">
                        <h4 class="stats-type mb-1">Amount In</h4>
                        <div class="stats-figure"><?php echo bulkSmsMoney($total_in); ?></div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-3">
                <div class="app-card app-card-stat shadow-sm h-100">
                    <div class="app-card-body p-3">
                        <h4 class="stats-type mb-1">Amount Out</h4>
                        <div class="stats-figure"><?php echo bulkSmsMoney($total_out); ?></div>
                    </div>
                </div>
            </div>
            <div class="col-12 col-md-3">
                <div class="app-card app-card-stat shadow-sm h-100">
                    <div class="app-card-body p-3">
                        <h4 class="stats-type mb-1">Bulk SMS Profit</h4>
                        <div class="stats-figure"><?php echo bulkSmsMoney($profit); ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Action Buttons -->
        <a href="print_bulk.php<?php echo $printQuery ? '?' . htmlspecialchars($printQuery) : ''; ?>" target="_blank" class="btn btn-success">
            <i class="fas fa-fw fa-print"></i> Print
        </a>

        <form method="get" action="bulk.php" class="bulk-filter-form mt-3 mb-3">
            <div>
                <label class="form-label" for="bulk-year">Year</label>
                <select class="form-select" id="bulk-year" name="year">
                    <option value="">All years</option>
                    <?php for ($year = $maxYear; $year >= $minYear; $year--) { ?>
                        <option value="<?php echo $year; ?>" <?php echo $selectedYear === $year ? 'selected' : ''; ?>>
                            <?php echo $year; ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div>
                <label class="form-label" for="bulk-category">Category</label>
                <select class="form-select" id="bulk-category" name="category">
                    <option value="">All categories</option>
                    <?php while ($category = mysqli_fetch_assoc($categoryResult)) { ?>
                        <option value="<?php echo (int)$category['id']; ?>" <?php echo $selectedCategory === (string)$category['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($category['trans_name']); ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
            <div>
                <label class="form-label" for="bulk-date-from">From</label>
                <input class="form-control" id="bulk-date-from" name="date_from" type="date" value="<?php echo htmlspecialchars($dateFrom); ?>">
            </div>
            <div>
                <label class="form-label" for="bulk-date-to">To</label>
                <input class="form-control" id="bulk-date-to" name="date_to" type="date" value="<?php echo htmlspecialchars($dateTo); ?>">
            </div>
            <button type="submit" class="btn btn-success">
                <i class="fas fa-fw fa-filter"></i> Apply Filter
            </button>
            <a href="bulk.php" class="btn btn-outline-secondary">Reset</a>
        </form>

        <!-- Data Table -->
        <div class="table-responsive long-list-table">
        <table class="table table-bordered" id="dataTable" data-batch-table width="100%" cellspacing="0" style="text-align:center;">
            <tr>
                <th>No</th>
                <th>Recorded by</th>
                <th>Transaction Date</th>
                <th>Category</th>
                <th>Description</th>
                <th>Amount In</th>
                <th>Amount Out</th>
                <th>SMS Units In</th>
                <th>SMS Units Out</th>
                <th>SMS Unit Balance Before</th>
                <th>SMS Unit Balance After</th>
                <th>Action</th>
            </tr>

            <?php
            $no = 1;
            while ($result1 && $row = mysqli_fetch_assoc($result1)) {
            ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td style="text-align:left;"><?php echo htmlspecialchars($row['fname']); ?></td>
                    <td style="text-align:left;"><?php echo htmlspecialchars($row['trans_date']); ?></td>
                    <td style="text-align:left;"><?php echo htmlspecialchars($row['trans_name']); ?></td>
                    <td style="text-align:left;"><?php echo htmlspecialchars($row['description']); ?></td>
                    <td style="text-align:right;color:#0aa35f;font-weight:700;"><?php echo bulkSmsMoney($row['amount_in']); ?></td>
                    <td style="text-align:right;color:#e54848;font-weight:700;"><?php echo bulkSmsMoney($row['amount_out']); ?></td>
                    <td style="text-align:right;"><?php echo bulkSmsInt($row['sms_units_in']); ?></td>
                    <td style="text-align:right;"><?php echo bulkSmsInt($row['sms_units_out']); ?></td>
                    <td style="text-align:right;"><?php echo bulkSmsInt($row['sms_balance_before']); ?></td>
                    <td style="text-align:right;"><?php echo bulkSmsInt($row['sms_balance_after']); ?></td>
                    <td>
                        <a href="updates_bulk.php?id=<?php echo $row['id']; ?>" class="btn btn-info btn-icon-split">
                            <span class="text">Update</span>
                        </a>
                        <a href="delete_bulk.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-icon-split">
                            <span class="text">Delete</span>
                        </a>
                    </td>
                </tr>
            <?php } ?>

            <!-- Totals Row -->
            <tr style="font-weight:bold; background-color:#f2f2f2;">
                <td colspan="5" style="text-align:right;">TOTAL:</td>
                <td style="text-align:right;"><?php echo bulkSmsMoney($total_in); ?></td>
                <td style="text-align:right;"><?php echo bulkSmsMoney($total_out); ?></td>
                <td style="text-align:right;"><?php echo bulkSmsInt($units_in); ?></td>
                <td style="text-align:right;"><?php echo bulkSmsInt($units_out); ?></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
        </table>
    </div>
</div>


					
			    
			    <!-- <nav id="orders-table-tab" class="orders-table-tab app-nav-tabs nav shadow-sm flex-column flex-sm-row mb-4">
				    <a class="flex-sm-fill text-sm-center nav-link active" id="orders-all-tab" data-bs-toggle="tab" href="#orders-all" role="tab" aria-controls="orders-all" aria-selected="true">All</a>
				    <a class="flex-sm-fill text-sm-center nav-link"  id="orders-paid-tab" data-bs-toggle="tab" href="#orders-paid" role="tab" aria-controls="orders-paid" aria-selected="false">Active</a>
				    <a class="flex-sm-fill text-sm-center nav-link" id="orders-pending-tab" data-bs-toggle="tab" href="#orders-pending" role="tab" aria-controls="orders-pending" aria-selected="false">Pending</a>
				    <a class="flex-sm-fill text-sm-center nav-link" id="orders-cancelled-tab" data-bs-toggle="tab" href="#orders-cancelled" role="tab" aria-controls="orders-cancelled" aria-selected="false">Cancelled</a>
				</nav> -->
			    
		    </div><!--//container-fluid-->
	    </div><!--//app-content-->
	    
	   
	    
    </div><!--//app-wrapper-->    					

 
    <!-- Javascript -->          
    <script src="assets/plugins/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>  
    
    
    <!-- Page Specific JS -->
    <script src="assets/js/app.js?v=20260712-7"></script> 
	<script>
    // Set the inactivity timeout duration in milliseconds (e.g., 15 minutes)
const inactivityTimeout =5 * 60 * 1000; // 15 minutes in milliseconds

let logoutTimer;

// Reset the timer on user activity
function resetLogoutTimer() {
    clearTimeout(logoutTimer);
    logoutTimer = setTimeout(logoutUser, inactivityTimeout);
}

// Logout the user when the timeout is reached
function logoutUser() {
    // Perform logout actions here (e.g., clear session data, redirect to logout page)
    window.location.href='logout.php';
    // You can replace the alert with actual logout code.
}

// Initialize the timer when the page loads or after user activity
window.onload = resetLogoutTimer;
document.onmousemove = resetLogoutTimer; // You can add more events like keypress, etc. for user activity

// Optionally, you can also handle clicks on specific elements to reset the timer
// For example, if you have a button that keeps the user logged in
const keepLoggedInButton = document.getElementById('keep-logged-in-button');
keepLoggedInButton.addEventListener('click', resetLogoutTimer);
</script>

</body>
</html> 


