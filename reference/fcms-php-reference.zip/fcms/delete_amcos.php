<?php
$clientDeleteType = 'AMCOS';
require __DIR__ . '/client_delete.php';
