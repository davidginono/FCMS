<?php

error_reporting(E_ALL);
ini_set('display_errors', 0);
// Start the session and set custom session directory
$sessionDirectory = '/home/sites/37b/1/15b6335fc9/fcms/sessions';
ini_set('session.save_path', $sessionDirectory);
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    // If not logged in, redirect to the login page
echo "<script>window.location.href='index.php';</script>";
    exit();
}
if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != '1') {
    header("location:user_dashboard.php");
    exit();
}
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

require('connect.php');
?>

<?php


require('connect.php');

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if(!$id){
    header("location:users.php");
    exit();
}
$csrf = $_SESSION['csrf_token'];

// JavaScript confirmation prompt
echo "<script>
    var confirmDelete = confirm('Are you sure you want to delete?');
    if (confirmDelete) {
        var form = document.createElement('form');
        form.method = 'POST';
        form.action = 'delete_user.php';
        form.innerHTML = '<input type=\"hidden\" name=\"id\" value=\"$id\"><input type=\"hidden\" name=\"csrf_token\" value=\"$csrf\">';
        document.body.appendChild(form);
        form.submit();
    } else {
        window.location.href = 'users.php'; // Redirect back to saccos.php if canceled
    }
</script>";

?>
