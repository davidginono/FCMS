'use strict';

/* ===== Enable Bootstrap Popover (on element  ====== */
const popoverTriggerList = document.querySelectorAll('[data-bs-toggle="popover"]')
const popoverList = [...popoverTriggerList].map(popoverTriggerEl => new bootstrap.Popover(popoverTriggerEl))

/* ==== Enable Bootstrap Alert ====== */
//var alertList = document.querySelectorAll('.alert')
//alertList.forEach(function (alert) {
//  new bootstrap.Alert(alert)
//});

const alertList = document.querySelectorAll('.alert')
const alerts = [...alertList].map(element => new bootstrap.Alert(element))


/* ===== Responsive Sidepanel ====== */
const sidePanelToggler = document.getElementById('sidepanel-toggler');
const sidePanel = document.getElementById('app-sidepanel');
const sidePanelDrop = document.getElementById('sidepanel-drop');
const sidePanelClose = document.getElementById('sidepanel-close');

window.addEventListener('load', function(){
	responsiveSidePanel();
});

window.addEventListener('resize', function(){
	responsiveSidePanel();
});


function responsiveSidePanel() {
    let w = window.innerWidth;
	if(w >= 1200) {
	    // if larger
	    //console.log('larger');
		sidePanel.classList.remove('sidepanel-hidden');
		sidePanel.classList.add('sidepanel-visible');

	} else {
	    // if smaller
	    //console.log('smaller');
	    sidePanel.classList.remove('sidepanel-visible');
		sidePanel.classList.add('sidepanel-hidden');
	}
};

function setupDesktopSidebarToggle() {
	var branding = document.querySelector('.app-branding');
	var sidePanel = document.getElementById('app-sidepanel');
	if (!branding || !sidePanel) {
		return;
	}

	var toggle = branding.querySelector('.fcms-sidebar-toggle');
	if (!toggle) {
		toggle = document.createElement('button');
		toggle.type = 'button';
		toggle.className = 'fcms-sidebar-toggle';
		toggle.setAttribute('aria-label', 'Toggle sidebar');
		toggle.setAttribute('aria-expanded', 'true');
		toggle.innerHTML = '<i class="fas fa-bars"></i>';
		branding.appendChild(toggle);
	}

	function setCollapsed(isCollapsed) {
		document.body.classList.toggle('fcms-sidebar-collapsed', isCollapsed);
		toggle.setAttribute('aria-expanded', isCollapsed ? 'false' : 'true');
		toggle.innerHTML = isCollapsed ? '<i class="fas fa-angles-right"></i>' : '<i class="fas fa-bars"></i>';
		try {
			localStorage.setItem('fcmsSidebarCollapsed', isCollapsed ? '1' : '0');
		} catch (error) {}
	}

	try {
		setCollapsed(localStorage.getItem('fcmsSidebarCollapsed') === '1');
	} catch (error) {
		setCollapsed(false);
	}

	if (toggle.dataset.fcmsBound !== '1') {
		toggle.dataset.fcmsBound = '1';
		toggle.addEventListener('click', function() {
			setCollapsed(!document.body.classList.contains('fcms-sidebar-collapsed'));
		});
	}
}

setupDesktopSidebarToggle();

sidePanelToggler.addEventListener('click', () => {
	if (sidePanel.classList.contains('sidepanel-visible')) {
		console.log('visible');
		sidePanel.classList.remove('sidepanel-visible');
		sidePanel.classList.add('sidepanel-hidden');

	} else {
		console.log('hidden');
		sidePanel.classList.remove('sidepanel-hidden');
		sidePanel.classList.add('sidepanel-visible');
	}
});



sidePanelClose.addEventListener('click', (e) => {
	e.preventDefault();
	sidePanelToggler.click();
});

sidePanelDrop.addEventListener('click', (e) => {
	sidePanelToggler.click();
});

/* ===== Navbar title ====== */
function addNavbarTitle() {
	var headerRow = document.querySelector('.app-header .row');
	if (!headerRow || headerRow.querySelector('.app-navbar-title-wrap')) {
		return;
	}

	headerRow.classList.remove('justify-content-between');
	headerRow.classList.add('fcms-navbar-row');

	var searchBox = headerRow.querySelector('.app-search-box');
	if (searchBox && !searchBox.querySelector('form, input, button')) {
		searchBox.classList.add('app-search-box-empty');
	}

	var titleWrap = document.createElement('div');
	titleWrap.className = 'app-navbar-title-wrap col';
	titleWrap.innerHTML = '<div class="app-navbar-title">Financial Control Management System</div>';

	var togglerCol = headerRow.querySelector('#sidepanel-toggler');
	if (togglerCol && togglerCol.parentElement && togglerCol.parentElement.parentElement === headerRow) {
		headerRow.insertBefore(titleWrap, togglerCol.parentElement.nextSibling);
	} else {
		headerRow.insertBefore(titleWrap, headerRow.firstChild);
	}
}

addNavbarTitle();

/* ===== Active sidebar item ====== */
function setActiveSidebarItem() {
	var appNav = document.getElementById('app-nav-main');
	if (!appNav) {
		return;
	}

	var currentPage = window.location.pathname.split('/').pop().toLowerCase() || 'admin.php';
	var pageAliases = {
		'account.php': 'admin.php',
		'change_password.php': 'admin.php',
		'change_profile.php': 'admin.php',
		'add_user.php': 'add_user.php',
		'update_user.php': 'users.php',
		'active_users.php': 'active_users.php',
		'inactive_users.php': 'inactive_users.php',
		'all_saccos.php': 'saccos.php',
		'add_saccoss.php': 'saccos.php',
		'update_saccos.php': 'saccos.php',
		'view_saccos.php': 'saccos.php',
		'paidsaccos.php': 'saccos.php',
		'unpaidsaccos.php': 'saccos.php',
		'all_amcos.php': 'amcos.php',
		'add_amcos.php': 'amcos.php',
		'update_amcos.php': 'amcos.php',
		'view_amcos.php': 'amcos.php',
		'all_union.php': 'union.php',
		'add_union.php': 'union.php',
		'update_union.php': 'union.php',
		'view_union.php': 'union.php',
		'paidunion.php': 'union.php',
		'unpaidunion.php': 'union.php',
		'all_microfinance.php': 'microfinance.php',
		'add_microfinance.php': 'microfinance.php',
		'update_microfinance.php': 'microfinance.php',
		'view_microfinance.php': 'microfinance.php',
		'paidmicrofinance.php': 'microfinance.php',
		'unpaidmicrofinance.php': 'microfinance.php',
		'add_other_client.php': 'other_client.php',
		'update_other_client.php': 'other_client.php',
		'view_others.php': 'other_client.php',
		'add_tasks.php': 'all_task.php',
		'update_tasks.php': 'all_task.php',
		'alltasks.php': 'all_task.php',
		'task_report.php': 'all_task.php',
		'add_report.php': 'staff_report.php',
		'admin_add_report.php': 'staff_report.php',
		'edit_report.php': 'staff_report.php',
		'edit_group_report.php': 'staff_report.php',
		'update_report.php': 'staff_report.php',
		'all_report.php': 'report.php',
		'saccos_report.php': 'report.php',
		'saccos_revenues.php': 'report.php',
		'training_report.php': 'report.php',
		'sysinstall_report.php': 'report.php',
		'mobile_report.php': 'report.php',
		'reinstall_report.php': 'report.php',
		'hosting_report.php': 'report.php',
		'android_report.php': 'report.php',
		'bulk_sms.php': 'report.php',
		'hostingfee.php': 'report.php',
		'systeminstallfee.php': 'report.php',
		'reinstall.php': 'report.php',
		'trainingfee.php': 'report.php',
		'mobile.php': 'report.php',
		'all_union_report.php': 'union_report.php',
		'union_revenues.php': 'union_report.php',
		'all_microfinance_report.php': 'microfinance_report.php',
		'all_other_report.php': 'other_report.php',
		'all_statement.php': 'income_statement.php',
		'add_leaves.php': 'leaves.php',
		'update_leave.php': 'leaves.php',
		'add_expenses.php': 'expenses.php',
		'update_expenses.php': 'expenses.php',
		'expenses_report.php': 'expenses.php',
		'category_details.php': 'expenses.php',
		'filtered_exp_result.php': 'expenses.php',
		'filtered_staff.php': 'expenses.php',
		'filtered_year.php': 'expenses.php',
		'filtered_all_cat.php': 'expenses.php',
		'add_income.php': 'income.php',
		'update_income.php': 'income.php',
		'filter_income_year.php': 'income.php',
		'deposit.php': 'petty_cash.php',
		'withdraw.php': 'petty_cash.php',
		'update_petty.php': 'petty_cash.php',
		'update_petty (1).php': 'petty_cash.php',
		'cloud_deposit.php': 'cloud_backup.php',
		'cloud_withdraw.php': 'cloud_backup.php',
		'update_cloud.php': 'cloud_backup.php',
		'paid_cloud_backup.php': 'cloud_backup.php',
		'unpaid_cloud_backup.php': 'cloud_backup.php',
		'bulk_credit.php': 'bulk.php',
		'bulk_debit.php': 'bulk.php',
		'bulk_filter_input.php': 'bulk.php',
		'bulk_report.php': 'bulk.php',
		'updates_bulk.php': 'bulk.php'
	};
	var targetPage = pageAliases[currentPage] || currentPage;

	appNav.querySelectorAll('.nav-link.active, .submenu-link.active').forEach(function(link) {
		link.classList.remove('active');
		link.classList.remove('open');
		link.setAttribute('aria-expanded', 'false');
	});
	appNav.querySelectorAll('.collapse.show').forEach(function(submenu) {
		submenu.classList.remove('show');
	});

	var activeLink = null;
	appNav.querySelectorAll('a[href]').forEach(function(link) {
		var href = link.getAttribute('href');
		if (!href || href === '#') {
			return;
		}
		var hrefPage = href.split('?')[0].split('/').pop().toLowerCase();
		if (hrefPage === targetPage && !activeLink) {
			activeLink = link;
		}
	});

	if (!activeLink) {
		return;
	}

	activeLink.classList.add('active');
	var submenu = activeLink.closest('.collapse');
	if (submenu) {
		submenu.classList.add('show');
		var toggle = appNav.querySelector('[data-bs-target="#' + submenu.id + '"]');
		if (toggle) {
			toggle.classList.add('active');
			toggle.classList.add('open');
			toggle.setAttribute('aria-expanded', 'true');
		}
	}
}

setActiveSidebarItem();

/* ===== Page action toolbar layout ====== */
function isFcmsTableBoundary(node) {
	return node.nodeType === 1 && (
		node.matches('.card-body, .table-responsive, table, .list-batch-controls') ||
		node.querySelector(':scope > .table-responsive, :scope > table')
	);
}

function isFcmsToolbarControl(node) {
	if (node.nodeType !== 1) {
		return false;
	}
	if (node.matches('.row.g-3, .page-utilities, .card-body, .table-responsive, table')) {
		return false;
	}
	if (node.matches('form.table-search-form')) {
		return false;
	}
	if (node.matches('.staff-report-actions, .expense-actions, .cloud-actions, .petty-actions, .task-actions, .income-statement-actions')) {
		return true;
	}
	if (node.matches('form')) {
		var action = (node.getAttribute('action') || '').toLowerCase();
		return node.matches('.row.g-2, .staff-report-filters, .cloud-filter-form, .petty-filter-form, .task-filter-form, .expense-filter-form, .other-client-filter-form, .income-statement-filter') ||
			node.querySelector('.fa-filter, [class*="fa-filter"]') ||
			action.indexOf('print_') !== -1 ||
			action.indexOf('_excel') !== -1;
	}
	if (node.matches('a.btn')) {
		return true;
	}
	return false;
}

function isFcmsListSummary(node) {
	if (node.nodeType !== 1 || node.matches('table, .table-responsive')) {
		return false;
	}
	if (node.matches('.cloud-list-summary, .petty-list-summary, .list-summary, .balance-summary')) {
		return true;
	}
	var text = (node.textContent || '').replace(/\s+/g, ' ').trim();
	return /^(balance|petty cash balance|bulk sms profit|total|grand total)\s*:/i.test(text);
}

function getOrCreateFcmsToolbar(container, beforeNode) {
	var toolbar = container.querySelector(':scope > .fcms-action-toolbar:not(form)');
	if (!toolbar) {
		toolbar = document.createElement('div');
		toolbar.className = 'fcms-action-toolbar';
		container.insertBefore(toolbar, beforeNode);
	}
	return toolbar;
}

function normalizePageToolbars() {
	var containers = document.querySelectorAll('.app-content .container-xl, .app-content .container-fluid');
	containers.forEach(function(container) {
		if (container.querySelector(':scope > .fcms-action-toolbar:not(form)')) {
			return;
		}

		var directNodes = Array.prototype.slice.call(container.childNodes);
		var toolbar = null;
		var movedAny = false;

		directNodes.some(function(node) {
			if (isFcmsTableBoundary(node)) {
				return true;
			}

			if (isFcmsToolbarControl(node)) {
				if (!toolbar) {
					toolbar = document.createElement('div');
					toolbar.className = 'fcms-action-toolbar';
					container.insertBefore(toolbar, node);
				}
				toolbar.appendChild(node);
				movedAny = true;
				return false;
			}

			if (toolbar && node.nodeType === 1 && node.tagName === 'BR') {
				node.remove();
			}
			return false;
		});

		if (toolbar && !movedAny) {
			toolbar.remove();
		}
	});
}

normalizePageToolbars();

function liftNestedListControls() {
	var containers = document.querySelectorAll('.app-content .container-xl, .app-content .container-fluid');
	containers.forEach(function(container) {
		var cards = Array.prototype.slice.call(container.querySelectorAll('.card-body, .table-responsive'));
		cards.forEach(function(card) {
			if (card.closest('.fcms-action-toolbar')) {
				return;
			}

			var table = card.querySelector(':scope > table, :scope > .table-responsive, table');
			if (!table) {
				return;
			}

			var directWrapper = card;
			while (directWrapper.parentElement && directWrapper.parentElement !== container) {
				directWrapper = directWrapper.parentElement;
			}

			var toolbar = null;
			var nodes = Array.prototype.slice.call(card.childNodes);
			nodes.some(function(node) {
				if (node === table || (node.nodeType === 1 && (node.matches('table, .table-responsive') || node.contains(table)))) {
					return true;
				}

				if (isFcmsToolbarControl(node) || isFcmsListSummary(node)) {
					toolbar = getOrCreateFcmsToolbar(container, directWrapper);
					if (node.matches('form.fcms-action-toolbar')) {
						node.classList.remove('fcms-action-toolbar', 'fcms-fit-toolbar', 'is-compact', 'is-ultra-compact', 'is-force-fit');
						node.classList.add('fcms-inline-filter');
					}
					if (isFcmsListSummary(node)) {
						node.classList.add('list-summary');
					}
					toolbar.appendChild(node);
					return false;
				}

				if (toolbar && node.nodeType === 1 && node.tagName === 'BR') {
					node.remove();
				}
				return false;
			});
		});
	});
}

liftNestedListControls();

function classifyFcmsToolbar(toolbar) {
	var text = (toolbar.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
	var actions = Array.prototype.slice.call(toolbar.querySelectorAll('form[action], a[href]')).map(function(element) {
		return ((element.getAttribute('action') || element.getAttribute('href') || '') + '').toLowerCase();
	}).join(' ');

	toolbar.classList.toggle('is-simple-report-toolbar', actions.indexOf('print_saccosreport') !== -1);
	toolbar.classList.toggle('is-expense-toolbar', !!toolbar.querySelector('.expense-actions, .expense-filter-form'));
	toolbar.classList.toggle('is-income-toolbar', !!toolbar.querySelector('a[href="add_income.php"]'));
	toolbar.classList.toggle('has-print-action', /(^|\s)print(\s|$)/i.test(text) || actions.indexOf('print_') !== -1);
	toolbar.classList.toggle('has-excel-action', text.indexOf('download excel') !== -1 || actions.indexOf('excel') !== -1);
}

function getFcmsFitToolbars() {
	var selectors = [
		'.fcms-action-toolbar',
		'.paid-cloud-toolbar',
		'.staff-report-actions',
		'.expense-actions',
		'.cloud-actions',
		'.petty-actions',
		'.task-actions',
		'.income-statement-actions',
		'.staff-report-filters',
		'.cloud-filter-form',
		'.petty-filter-form',
		'.task-filter-form',
		'.expense-filter-form',
		'.other-client-filter-form',
		'.income-statement-filter',
		'.app-content form.row.g-2.align-items-end',
		'.app-content form.row.g-2.align-items-center'
	];
	return Array.prototype.slice.call(document.querySelectorAll(selectors.join(','))).filter(function(toolbar, index, list) {
		if (toolbar.closest('.table-responsive') !== null || list.indexOf(toolbar) !== index) {
			return false;
		}

		// Once controls have been collected into the shared toolbar, only size that
		// parent. Resizing its nested forms a second time causes needless clipping.
		var parentToolbar = toolbar.parentElement && toolbar.parentElement.closest('.fcms-action-toolbar, .paid-cloud-toolbar');
		return !parentToolbar || toolbar.matches('.fcms-action-toolbar, .paid-cloud-toolbar');
	});
}

function getFcmsCompactLabel(text, mode) {
	var label = text.replace(/\s+/g, ' ').trim();
	var rules = [
		{ pattern: /^add\s+new\s+saccos$/i, compact: 'Add SACCOS', ultra: 'Add SACCOS' },
		{ pattern: /^download\s+excel$/i, compact: 'Excel', ultra: 'Excel' },
		{ pattern: /^add\s+staff\s+report$/i, compact: 'Add Report', ultra: 'Add' },
		{ pattern: /^add\s+expenses?$/i, compact: 'Add Expense', ultra: 'Add Expense' },
		{ pattern: /^filter\s+by\s+year$/i, compact: 'Filter', ultra: 'Filter' },
		{ pattern: /^apply\s+filter$/i, compact: 'Apply', ultra: 'Apply' }
	];
	for (var i = 0; i < rules.length; i++) {
		if (rules[i].pattern.test(label)) {
			return mode === 'ultra' ? rules[i].ultra : rules[i].compact;
		}
	}
	return label;
}

function getFcmsLabelNode(control) {
	var splitText = control.querySelector('.text');
	if (splitText) {
		return splitText;
	}
	if (control.children.length === 0) {
		return control;
	}
	var textNodes = Array.prototype.slice.call(control.childNodes).filter(function(node) {
		return node.nodeType === 3 && node.nodeValue.replace(/\s+/g, '').length > 0;
	});
	return textNodes.length === 1 ? textNodes[0] : null;
}

function readFcmsLabel(labelNode) {
	return labelNode.nodeType === 3 ? labelNode.nodeValue : labelNode.textContent;
}

function writeFcmsLabel(labelNode, value) {
	if (labelNode.nodeType === 3) {
		labelNode.nodeValue = value;
	} else {
		labelNode.textContent = value;
	}
}

function setFcmsToolbarLabels(toolbar, mode) {
	var controls = toolbar.querySelectorAll('a.btn, button.btn, .btn-icon-split');
	Array.prototype.slice.call(controls).forEach(function(control) {
		var labelNode = getFcmsLabelNode(control);
		if (!labelNode) {
			return;
		}
		if (!control.dataset.fcmsFullLabel) {
			control.dataset.fcmsFullLabel = readFcmsLabel(labelNode).replace(/\s+/g, ' ').trim();
		}
		var fullLabel = control.dataset.fcmsFullLabel;
		var nextLabel = mode === 'full' ? fullLabel : getFcmsCompactLabel(fullLabel, mode);
		writeFcmsLabel(labelNode, nextLabel);
		if (fullLabel) {
			control.setAttribute('title', fullLabel);
			if (!control.getAttribute('aria-label')) {
				control.setAttribute('aria-label', fullLabel);
			}
		}
	});
}

function getFcmsControlValue(control) {
	if (control.matches('select')) {
		var option = control.options && control.selectedIndex >= 0 ? control.options[control.selectedIndex] : null;
		return option ? option.text.replace(/\s+/g, ' ').trim() : '';
	}
	if (control.matches('input, textarea')) {
		return (control.value || control.getAttribute('placeholder') || '').replace(/\s+/g, ' ').trim();
	}
	return control.textContent.replace(/\s+/g, ' ').trim();
}

function getFcmsControlLabel(control, toolbar) {
	if (control.id) {
		var controlId = window.CSS && window.CSS.escape ? window.CSS.escape(control.id) : control.id.replace(/"/g, '\\"');
		var explicitLabel = toolbar.querySelector('label[for="' + controlId + '"]');
		if (explicitLabel) {
			return explicitLabel.textContent.replace(/\s+/g, ' ').trim();
		}
	}
	var wrapper = control.closest('div, label');
	if (wrapper) {
		var wrapperLabel = wrapper.querySelector(':scope > label');
		if (wrapperLabel) {
			return wrapperLabel.textContent.replace(/\s+/g, ' ').trim();
		}
		if (wrapper.matches('label')) {
			return wrapper.textContent.replace(/\s+/g, ' ').trim();
		}
	}
	var previous = control.previousElementSibling;
	if (previous && previous.matches('label')) {
		return previous.textContent.replace(/\s+/g, ' ').trim();
	}
	return '';
}

function setFcmsToolbarHints(toolbar) {
	var labels = toolbar.querySelectorAll('label');
	Array.prototype.slice.call(labels).forEach(function(label) {
		var labelText = label.textContent.replace(/\s+/g, ' ').trim();
		if (labelText) {
			label.setAttribute('title', labelText);
		}
	});

	var fields = toolbar.querySelectorAll('select, input:not([type="hidden"]), textarea, button.form-select, [data-filter-button], .staff-report-dropdown-toggle');
	Array.prototype.slice.call(fields).forEach(function(field) {
		var label = getFcmsControlLabel(field, toolbar);
		var value = getFcmsControlValue(field);
		var hint = label && value ? label + ': ' + value : (label || value);
		if (hint) {
			field.setAttribute('title', hint);
		}
	});
}

function getFcmsFitItemCount(toolbar) {
	var selector = 'select, input:not([type="hidden"]), textarea, a.btn, button.btn, button.form-select, [data-filter-button], .staff-report-dropdown-toggle';
	var items = Array.prototype.slice.call(toolbar.querySelectorAll(selector)).filter(function(item, index, list) {
		return item.offsetParent !== null && list.indexOf(item) === index;
	});
	return Math.max(items.length, 1);
}

function getFcmsToolbarGapPx(toolbar) {
	var styles = window.getComputedStyle(toolbar);
	var parsedGap = parseFloat(styles.columnGap || styles.gap || '');
	var fallback = 10;
	if (toolbar.classList.contains('is-force-fit')) {
		fallback = 8;
	} else if (toolbar.classList.contains('is-ultra-compact')) {
		fallback = 9;
	} else if (toolbar.classList.contains('is-compact')) {
		fallback = 10;
	}
	return Math.max(fallback, Number.isFinite(parsedGap) ? parsedGap : 0);
}

function applyFcmsFitBudget(toolbar) {
	toolbar.style.removeProperty('--fcms-control-max');
	toolbar.style.removeProperty('--fcms-button-max');
	toolbar.style.removeProperty('--fcms-toolbar-scale');
	toolbar.classList.remove('is-force-fit');
}

function isFcmsToolbarOverflowing(toolbar) {
	if (window.innerWidth < 768) {
		return false;
	}

	var toolbarRect = toolbar.getBoundingClientRect();
	var controls = Array.prototype.slice.call(toolbar.querySelectorAll(
		'select, input:not([type="hidden"]), textarea, a.btn, button.btn, button.form-select, [data-filter-button], .staff-report-dropdown-toggle'
	)).filter(function(control) {
		var style = window.getComputedStyle(control);
		var rect = control.getBoundingClientRect();
		return style.display !== 'none' && style.visibility !== 'hidden' && rect.width > 0 && rect.height > 0;
	}).map(function(control) {
		return control.getBoundingClientRect();
	}).sort(function(a, b) {
		return a.left - b.left;
	});

	if (!controls.length) {
		return false;
	}

	var minimumGap = getFcmsToolbarGapPx(toolbar);

	for (var i = 0; i < controls.length; i++) {
		var current = controls[i];
		if (current.left < toolbarRect.left - 1 || current.right > toolbarRect.right + 1) {
			return true;
		}

		if (i > 0) {
			var previous = controls[i - 1];
			var overlapsVertically = current.top < previous.bottom - 1 && current.bottom > previous.top + 1;
			if (overlapsVertically && current.left - previous.right < minimumGap - 1) {
				return true;
			}
		}
	}

	return false;
}

function fitFcmsToolbar(toolbar) {
	toolbar.classList.add('fcms-fit-toolbar', 'fcms-stable-toolbar');
	toolbar.classList.remove('is-compact', 'is-ultra-compact', 'is-force-fit');
	toolbar.style.removeProperty('--fcms-control-max');
	toolbar.style.removeProperty('--fcms-button-max');
	toolbar.style.removeProperty('--fcms-toolbar-scale');
	classifyFcmsToolbar(toolbar);
	setFcmsToolbarLabels(toolbar, 'full');
	setFcmsToolbarHints(toolbar);
}

function setupFcmsToolbarFit() {
	var toolbars = getFcmsFitToolbars();
	toolbars.forEach(function(toolbar) {
		toolbar.classList.add('fcms-fit-toolbar', 'fcms-stable-toolbar');
		toolbar.classList.remove('is-compact', 'is-ultra-compact', 'is-force-fit');
		toolbar.style.removeProperty('--fcms-control-max');
		toolbar.style.removeProperty('--fcms-button-max');
		toolbar.style.removeProperty('--fcms-toolbar-scale');
		classifyFcmsToolbar(toolbar);
		setFcmsToolbarLabels(toolbar, 'full');
		setFcmsToolbarHints(toolbar);
	});
}

setupFcmsToolbarFit();

function setupCollapsedSidebarFlyouts() {
	var appNav = document.getElementById('app-nav-main');
	var sidePanel = document.getElementById('app-sidepanel');
	if (!appNav || !sidePanel) {
		return;
	}

	var flyout = document.createElement('div');
	flyout.className = 'fcms-sidebar-flyout';
	flyout.setAttribute('role', 'menu');
	flyout.setAttribute('aria-hidden', 'true');
	document.body.appendChild(flyout);

	var activeItem = null;
	var closeTimer = null;

	function isCollapsedSidebar() {
		return document.body.classList.contains('fcms-sidebar-collapsed') && window.innerWidth >= 1200;
	}

	function getNavTitle(navItem) {
		var title = navItem.querySelector(':scope > .nav-link .nav-link-text');
		return title ? title.textContent.replace(/\s+/g, ' ').trim() : '';
	}

	function escapeFlyoutHtml(value) {
		return String(value).replace(/[&<>"']/g, function(character) {
			return {
				'&': '&amp;',
				'<': '&lt;',
				'>': '&gt;',
				'"': '&quot;',
				"'": '&#039;'
			}[character];
		});
	}

	function clearCloseTimer() {
		if (closeTimer) {
			window.clearTimeout(closeTimer);
			closeTimer = null;
		}
	}

	function scheduleClose() {
		clearCloseTimer();
		closeTimer = window.setTimeout(closeFlyout, 120);
	}

	function closeFlyout() {
		clearCloseTimer();
		activeItem = null;
		flyout.classList.remove('is-visible', 'is-tooltip');
		flyout.setAttribute('aria-hidden', 'true');
		flyout.innerHTML = '';
	}

	function positionFlyout(navItem) {
		var panelRect = sidePanel.getBoundingClientRect();
		var itemRect = navItem.getBoundingClientRect();
		var left = Math.max(panelRect.right + 10, 88);
		flyout.style.left = left + 'px';
		flyout.style.top = '0px';

		var flyoutRect = flyout.getBoundingClientRect();
		var top = itemRect.top + (itemRect.height / 2) - (flyoutRect.height / 2);
		top = Math.max(10, Math.min(top, window.innerHeight - flyoutRect.height - 10));
		flyout.style.top = top + 'px';
	}

	function buildFlyout(navItem) {
		var title = getNavTitle(navItem);
		var submenuLinks = Array.prototype.slice.call(navItem.querySelectorAll(':scope .submenu .submenu-link[href]'));
		var hasSubmenu = submenuLinks.length > 0;
		var html = '<div class="fcms-sidebar-flyout-title">' + escapeFlyoutHtml(title) + '</div>';

		if (hasSubmenu) {
			html += '<div class="fcms-sidebar-flyout-list">';
			submenuLinks.forEach(function(link) {
				var href = link.getAttribute('href');
				var text = link.textContent.replace(/\s+/g, ' ').trim();
				html += '<a class="fcms-sidebar-flyout-link" role="menuitem" href="' + escapeFlyoutHtml(href) + '">' + escapeFlyoutHtml(text) + '</a>';
			});
			html += '</div>';
		}

		flyout.innerHTML = html;
		flyout.classList.toggle('is-tooltip', !hasSubmenu);
	}

	function showFlyout(navItem) {
		if (!isCollapsedSidebar()) {
			closeFlyout();
			return;
		}
		var title = getNavTitle(navItem);
		if (!title) {
			return;
		}

		clearCloseTimer();
		activeItem = navItem;
		buildFlyout(navItem);
		flyout.classList.add('is-visible');
		flyout.setAttribute('aria-hidden', 'false');
		positionFlyout(navItem);
	}

	appNav.addEventListener('mouseenter', function(event) {
		var navItem = event.target.closest('.nav-item');
		if (navItem && appNav.contains(navItem)) {
			showFlyout(navItem);
		}
	}, true);

	appNav.addEventListener('mouseleave', function(event) {
		var navItem = event.target.closest('.nav-item');
		if (navItem && navItem === activeItem) {
			scheduleClose();
		}
	}, true);

	appNav.addEventListener('focusin', function(event) {
		var navItem = event.target.closest('.nav-item');
		if (navItem && appNav.contains(navItem)) {
			showFlyout(navItem);
		}
	});

	appNav.addEventListener('click', function(event) {
		var navItem = event.target.closest('.nav-item.has-submenu');
		if (!navItem || !isCollapsedSidebar()) {
			return;
		}
		var navLink = event.target.closest('.nav-link');
		if (!navLink || !navItem.contains(navLink)) {
			return;
		}
		event.preventDefault();
		showFlyout(navItem);
		var firstFlyoutLink = flyout.querySelector('.fcms-sidebar-flyout-link');
		if (firstFlyoutLink) {
			firstFlyoutLink.focus();
		}
	});

	flyout.addEventListener('mouseenter', clearCloseTimer);
	flyout.addEventListener('mouseleave', scheduleClose);
	flyout.addEventListener('focusin', clearCloseTimer);
	flyout.addEventListener('focusout', function() {
		window.setTimeout(function() {
			if (!flyout.contains(document.activeElement) && (!activeItem || !activeItem.contains(document.activeElement))) {
				closeFlyout();
			}
		}, 0);
	});

	document.addEventListener('keydown', function(event) {
		if (event.key === 'Escape') {
			var itemToRestore = activeItem;
			closeFlyout();
			var activeLink = itemToRestore ? itemToRestore.querySelector(':scope > .nav-link') : null;
			if (activeLink) {
				activeLink.focus();
			}
		}
	});

	document.addEventListener('click', function(event) {
		if (!flyout.contains(event.target) && !appNav.contains(event.target)) {
			closeFlyout();
		}
	});

	window.addEventListener('resize', function() {
		if (!isCollapsedSidebar()) {
			closeFlyout();
		} else if (activeItem) {
			positionFlyout(activeItem);
		}
	});
}

setupCollapsedSidebarFlyouts();



/* ====== Mobile search ======= */
const searchMobileTrigger = document.querySelector('.search-mobile-trigger');
const searchBox = document.querySelector('.app-search-box');

searchMobileTrigger.addEventListener('click', () => {

	searchBox.classList.toggle('is-visible');

	let searchMobileTriggerIcon = document.querySelector('.search-mobile-trigger-icon');

	if(searchMobileTriggerIcon.classList.contains('fa-magnifying-glass')) {
		searchMobileTriggerIcon.classList.remove('fa-magnifying-glass');
		searchMobileTriggerIcon.classList.add('fa-xmark');
	} else {
		searchMobileTriggerIcon.classList.remove('fa-xmark');
		searchMobileTriggerIcon.classList.add('fa-magnifying-glass');
	}



});

/* ===== Long table batch viewing ====== */
document.querySelectorAll('table[data-batch-table]').forEach(function(table) {
	var rows = Array.prototype.slice.call(table.querySelectorAll('tr'));
	if (rows.length <= 1) {
		return;
	}

	var bodyRows = rows.slice(1);
	var pageSize = parseInt(table.getAttribute('data-batch-size') || '50', 10);
	var currentPage = 1;
	var controls = document.createElement('div');
	controls.className = 'list-batch-controls';
	controls.innerHTML = '<div class="list-batch-summary"></div><div class="list-batch-actions"><label>Rows <select class="form-select form-select-sm"><option value="25">25</option><option value="50">50</option><option value="100">100</option><option value="0">All</option></select></label><button type="button" class="btn btn-secondary btn-sm" data-page-prev>Previous</button><button type="button" class="btn btn-secondary btn-sm" data-page-next>Next</button></div>';
	table.parentNode.insertBefore(controls, table);

	var summary = controls.querySelector('.list-batch-summary');
	var select = controls.querySelector('select');
	var prev = controls.querySelector('[data-page-prev]');
	var next = controls.querySelector('[data-page-next]');
	select.value = String(pageSize);

	function renderBatch() {
		var total = bodyRows.length;
		var showAll = pageSize === 0;
		var totalPages = showAll ? 1 : Math.max(1, Math.ceil(total / pageSize));
		if (currentPage > totalPages) {
			currentPage = totalPages;
		}
		var start = showAll ? 0 : (currentPage - 1) * pageSize;
		var end = showAll ? total : Math.min(start + pageSize, total);

		bodyRows.forEach(function(row, index) {
			row.style.display = index >= start && index < end ? '' : 'none';
		});
		summary.textContent = total ? 'Showing ' + (start + 1) + '-' + end + ' of ' + total : 'No records';
		prev.disabled = showAll || currentPage <= 1;
		next.disabled = showAll || currentPage >= totalPages;
	}

	select.addEventListener('change', function() {
		pageSize = parseInt(select.value, 10);
		currentPage = 1;
		renderBatch();
	});
	prev.addEventListener('click', function() {
		if (currentPage > 1) {
			currentPage--;
			renderBatch();
		}
	});
	next.addEventListener('click', function() {
		currentPage++;
		renderBatch();
	});

	renderBatch();
});

/* ===== Dashboard table amount coloring ====== */
document.querySelectorAll('table').forEach(function(table) {
	var headerRow = table.querySelector('tr');
	if (!headerRow) {
		return;
	}
	var amountInIndexes = [];
	var amountOutIndexes = [];
	Array.prototype.slice.call(headerRow.children).forEach(function(cell, index) {
		var text = cell.textContent.replace(/\s+/g, ' ').trim().toLowerCase();
		if (text === 'amount in') {
			amountInIndexes.push(index);
		}
		if (text === 'amount out') {
			amountOutIndexes.push(index);
		}
	});
	if (!amountInIndexes.length && !amountOutIndexes.length) {
		return;
	}
	Array.prototype.slice.call(table.querySelectorAll('tr')).slice(1).forEach(function(row) {
		amountInIndexes.forEach(function(index) {
			if (row.children[index]) {
				row.children[index].classList.add('amount-in-cell');
			}
		});
		amountOutIndexes.forEach(function(index) {
			if (row.children[index]) {
				row.children[index].classList.add('amount-out-cell');
			}
		});
	});
});
