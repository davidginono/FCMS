'use strict';

document.addEventListener('change', function (event) {
    if (!event.target.matches('.client-activity-form select[name="client_status"]')) {
        return;
    }
    const form = event.target.form;
    if (form.dataset.submitting === 'true') {
        return;
    }
    form.dataset.submitting = 'true';
    form.setAttribute('aria-busy', 'true');
    form.requestSubmit();
});
