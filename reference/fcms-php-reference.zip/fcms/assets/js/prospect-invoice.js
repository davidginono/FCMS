'use strict';

(() => {
    const container = document.getElementById('invoice-items');
    if (!container) return;
    const add = document.getElementById('add-invoice-item');
    const currency = document.getElementById('currency');
    const output = document.getElementById('invoice-total');

    function updateTotal() {
        // Sum whole cents; even 50 maximum-sized lines fit in a safe integer.
        let cents = 0;
        for (const input of container.querySelectorAll('[data-item-amount]')) {
            const match = /^(0|[1-9][0-9]{0,11})(?:\.([0-9]{1,2}))?$/.exec(input.value);
            if (!match) {
                output.textContent = currency.value + ' —';
                return;
            }
            cents += Number(match[1] + ((match[2] || '') + '00').slice(0, 2));
        }
        if (cents > 99999999999999) {
            output.textContent = 'Total exceeds the supported amount';
            return;
        }
        const whole = Math.floor(cents / 100).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
        output.textContent = currency.value + ' ' + whole + '.' + ('0' + (cents % 100)).slice(-2);
    }

    function updateRows() {
        const rows = container.querySelectorAll('[data-invoice-item]');
        rows.forEach((row, index) => {
            for (const field of ['description', 'amount']) {
                const input = row.querySelector('[data-item-' + field + ']');
                input.id = 'item-' + field + '-' + index;
                input.name = 'items[' + index + '][' + field + ']';
                input.closest('label').htmlFor = input.id;
                row.querySelector('[data-' + field + '-label]').textContent = 'Item ' + (index + 1) + ' ' + field;
            }
            const remove = row.querySelector('[data-remove-item]');
            remove.disabled = rows.length === 1;
            remove.setAttribute('aria-label', 'Remove item ' + (index + 1));
        });
        add.disabled = rows.length >= 50;
        updateTotal();
    }

    add.addEventListener('click', () => {
        if (container.children.length >= 50) return;
        const row = container.querySelector('[data-invoice-item]').cloneNode(true);
        row.querySelector('[data-item-description]').value = '';
        row.querySelector('[data-item-amount]').value = '0.00';
        container.appendChild(row);
        updateRows();
        row.querySelector('[data-item-description]').focus();
    });
    container.addEventListener('click', event => {
        const remove = event.target.closest('[data-remove-item]');
        if (!remove || container.children.length <= 1) return;
        const next = remove.closest('[data-invoice-item]').nextElementSibling || remove.closest('[data-invoice-item]').previousElementSibling;
        remove.closest('[data-invoice-item]').remove();
        updateRows();
        next.querySelector('[data-item-description]').focus();
    });
    container.addEventListener('input', updateTotal);
    currency.addEventListener('change', updateTotal);
    updateRows();
})();
