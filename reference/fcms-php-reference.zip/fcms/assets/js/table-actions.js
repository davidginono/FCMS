'use strict';
(() => {
    const paths = {
        view:'M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z',
        edit:'m15 5 4 4 M4 20l4-1L21 6a2.8 2.8 0 0 0-4-4L4 15l-1 6Z',
        delete:'M3 6h18 M9 6V3h6v3 M5 6l1 15h12l1-15 M10 10v7 M14 10v7',
        print:'M6 9V3h12v6 M6 17H3V9h18v8h-3 M6 14h12v7H6Z M17 11h1',
        download:'M12 3v12 m-5-5 5 5 5-5 M4 16v5h16v-5',
        approve:'m4 12 5 5L20 6',
        more:'M5 11h1v2H5Z M11 11h1v2h-1Z M17 11h1v2h-1Z'
    };
    const clientRoutes = /^(?:delete_(?:saccos|amcos|union|microfinance|others)|delete_dialog[23]?|micro_delete_dialog|others_delete_dialog)\.php$/;
    const direct = new WeakSet();
    function classify(control) {
        const label=(control.getAttribute('aria-label') || control.getAttribute('title') || control.textContent || control.value || '').trim();
        const target=control.getAttribute('href') || control.form?.getAttribute('action') || '';
        if (/delete|remove/i.test(target+' '+label)) return ['delete','Delete'];
        if (control.hasAttribute('download') || /download/i.test(target+' '+label)) return ['download',label || 'Download'];
        if (/print/i.test(target+' '+label)) return ['print','Print'];
        if (/update|edit/i.test(target+' '+label)) return ['edit','Edit'];
        if (/view|details/i.test(target+' '+label)) return ['view','View'];
        if (/approve|activate/i.test(target+' '+label)) return ['approve',label || 'Approve'];
        return ['more',label || 'More actions'];
    }
    function icon(kind) {
        const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
        svg.setAttribute('viewBox','0 0 24 24'); svg.setAttribute('aria-hidden','true');
        svg.setAttribute('fill','none'); svg.setAttribute('stroke','currentColor');
        svg.setAttribute('stroke-width','1.8'); svg.setAttribute('stroke-linecap','round'); svg.setAttribute('stroke-linejoin','round');
        const path=document.createElementNS(svg.namespaceURI,'path');
        path.setAttribute('d',paths[kind] || paths.more); svg.append(path); return svg;
    }
    function enhance() {
        document.querySelectorAll('table').forEach(table => {
            const header=table.querySelector('tr');
            if (!header) return;
            [...header.cells].forEach((cell,index) => {
                if (!/^actions?$/i.test(cell.textContent.trim())) return;
                [...table.rows].slice(1).forEach(row => {
                    const target=row.cells[index];
                    if (!target || target.colSpan > 1 || target.dataset.actionsReady) return;
                    const controls=[...target.querySelectorAll('a[href],button,input[type="submit"]')]
                        .filter(el => !el.closest('.modal,dialog,[role="dialog"]'));
                    if (!controls.length) return;
                    target.dataset.actionsReady='true';
                    const group=document.createElement('div'); group.className='fcms-row-actions';
                    while(target.firstChild) {
                        const child=target.firstChild;
                        if (child.nodeType===Node.TEXT_NODE && /^[\s|,\/]*$/.test(child.textContent)) child.remove();
                        else group.append(child);
                    }
                    target.append(group);
                    controls.forEach(control => {
                        const [kind,label]=classify(control);
                        control.classList.add('fcms-row-action'); control.dataset.rowAction=kind;
                        control.setAttribute('aria-label',label); control.setAttribute('title',label);
                        if (control.tagName==='INPUT') {
                            // Preserve legacy submit names and values; use its existing control.
                            control.classList.add('fcms-row-action-input'); return;
                        }
                        control.replaceChildren(icon(kind));
                    });
                });
            });
        });
    }
    const dialog=document.createElement('dialog'); dialog.className='fcms-confirm-dialog';
    dialog.setAttribute('aria-labelledby','fcms-confirm-title');
    const title=document.createElement('h2'); title.id='fcms-confirm-title';
    const name=document.createElement('p'); const message=document.createElement('p'); message.setAttribute('role','status');
    const form=document.createElement('form'); form.method='post';
    const actions=document.createElement('div'); actions.className='fcms-confirm-actions';
    dialog.append(title,name,message,form); document.body.append(dialog);
    let sequence=0;
    function cancelButton() {
        const button=document.createElement('button'); button.type='button'; button.className='btn app-btn-secondary';
        button.textContent='Cancel'; button.addEventListener('click',()=>dialog.close()); actions.append(button);
        return button;
    }
    function submitButton(label,value,style) {
        const button=document.createElement('button'); button.type='submit'; button.name='action'; button.value=value;
        button.className='btn '+style; button.textContent=label; actions.append(button); return button;
    }
    async function confirm(control) {
        const current=++sequence;
        title.textContent='Confirm deletion'; name.textContent='';
        message.textContent='Checking this action…'; form.replaceChildren(); actions.replaceChildren(); form.append(actions);
        cancelButton(); dialog.showModal();
        const href=control.getAttribute('href');
        if (href) {
            const url=new URL(href,location.href);
            if (url.origin===location.origin && clientRoutes.test(url.pathname.split('/').pop())) {
                try {
                    url.searchParams.set('format','json');
                    const response=await fetch(url,{credentials:'same-origin',headers:{Accept:'application/json'}});
                    if (!response.ok) throw new Error('Unable to load the confirmation. Reload the page and try again.');
                    const data=await response.json();
                    if (current!==sequence || !dialog.open) return;
                    const actionUrl=new URL(data.actionUrl,location.href);
                    if (actionUrl.origin!==location.origin || !clientRoutes.test(actionUrl.pathname.split('/').pop())) throw new Error('Invalid confirmation.');
                    name.textContent=data.name; message.textContent=data.message; form.action=actionUrl.href;
                    for (const key of ['id','csrf','version']) {
                        const input=document.createElement('input'); input.type='hidden'; input.name=key; input.value=data[key]; form.prepend(input);
                    }
                    if (data.canDeactivate) submitButton('Mark inactive','deactivate','app-btn-primary');
                    if (!data.blocked) submitButton('Delete client','delete','btn-danger');
                } catch(error) {
                    if (current===sequence && dialog.open) message.textContent='Unable to load the client confirmation. Reload the page and try again.';
                }
                return;
            }
        }
        message.textContent='Delete this record? This action cannot be undone.';
        const button=document.createElement('button'); button.type='button'; button.className='btn btn-danger'; button.textContent='Delete record';
        button.addEventListener('click',()=>{
            dialog.close();
            if (control.form) {
                direct.add(control.form);
                if (/confirm\s*\(/.test(control.form.getAttribute('onsubmit') || '')) control.form.removeAttribute('onsubmit');
            }
            if (/^\s*return\s+confirm\s*\(/.test(control.getAttribute('onclick') || '')) control.removeAttribute('onclick');
            direct.add(control);
            control.click();
        }); actions.append(button);
    }
    document.addEventListener('click',event=>{
        const control=event.target.closest('a[data-row-action="delete"],button[data-row-action="delete"],input[data-row-action="delete"]');
        if (control && direct.delete(control)) return;
        if (!control || control.disabled || control.getAttribute('data-bs-toggle')==='modal') return;
        event.preventDefault(); event.stopImmediatePropagation();
        confirm(control);
    },true);
    document.addEventListener('submit',event=>{
        if (event.target===form || direct.delete(event.target)) return;
        const control=event.submitter || event.target.querySelector('[data-row-action="delete"]');
        if (!control || control.dataset.rowAction!=='delete') return;
        event.preventDefault(); event.stopImmediatePropagation(); confirm(control);
    },true);
    enhance();
    // DataTable redraws and filtered rows retain the same action presentation.
    new MutationObserver(records=>{
        if (records.some(record=>record.target.closest?.('table') && [...record.addedNodes].some(node=>node.nodeType===1 && (node.matches('tr,tbody') || node.querySelector('tr'))))) enhance();
    }).observe(document.body,{childList:true,subtree:true});
})();
