'use strict';

// Shared by the PHP page print actions. CSV/download actions are deliberately excluded.
(() => {
    if (window.fcmsPrintPreviewInstalled) return;
    window.fcmsPrintPreviewInstalled = true;
    let pending = null;
    let frame = null;
    let pdfUrl = null;
    let notice = null;
    let message = null;
    let retry = null;
    let download = null;

    function printTarget(value) {
        const url = new URL(value, document.baseURI);
        const file = url.pathname.split('/').pop();
        return url.origin === location.origin && /^(?:print[a-z_]*|Petty_print_filter_dates)\.php$/i.test(file) &&
            !/_excel\.php$/i.test(file) ? url : null;
    }

    function showNotice(text, ready = false, error = false) {
        if (!notice) {
            notice = document.createElement('section');
            notice.className = 'fcms-print-notice';
            notice.setAttribute('aria-label', 'Print preview');
            message = document.createElement('p');
            message.setAttribute('role', 'status');
            message.setAttribute('aria-live', 'polite');
            retry = document.createElement('button');
            retry.type = 'button'; retry.textContent = 'Print again';
            retry.addEventListener('click', requestPrint);
            download = document.createElement('a');
            download.textContent = 'Download PDF'; download.download = 'report.pdf';
            const close = document.createElement('button');
            close.type = 'button'; close.textContent = 'Close';
            close.addEventListener('click', () => {
                notice.hidden = true;
                if (pending) pending.abort();
            });
            notice.append(message, retry, download, close);
            document.body.appendChild(notice);
        }
        notice.hidden = false;
        notice.classList.toggle('fcms-print-error', error);
        message.textContent = text;
        retry.hidden = !ready;
        download.hidden = !ready;
        if (ready) download.href = pdfUrl;
    }

    function clearDocument() {
        if (frame) frame.remove();
        if (pdfUrl) URL.revokeObjectURL(pdfUrl);
        frame = null; pdfUrl = null;
    }

    function requestPrint() {
        if (!frame) return;
        try {
            frame.contentWindow.focus();
            frame.contentWindow.print();
            showNotice('If print preview does not appear, select Print again or Download PDF.', true);
        } catch (error) {
            showNotice('This browser could not open print preview. Try Print again or Download PDF.', true, true);
        }
    }

    async function prepare(url, method = 'GET', data = null, trigger = null) {
        if (pending) return;
        pending = new AbortController();
        const controller = pending;
        const wasDisabled = trigger && 'disabled' in trigger ? trigger.disabled : false;
        if (trigger && 'disabled' in trigger) trigger.disabled = true;
        clearDocument();
        showNotice('Preparing print preview…');
        const timeout = setTimeout(() => controller.abort(), 45000);
        try {
            const response = await fetch(url.href, {
                method, body: method === 'POST' ? data : null,
                credentials: 'same-origin', cache: 'no-store', redirect: 'error',
                headers: { Accept: 'application/pdf' }, signal: controller.signal
            });
            if (!response.ok) throw new Error(response.status === 401 ? 'Please sign in again before printing.' :
                response.status === 403 ? 'You do not have permission to print this report.' : 'Unable to prepare this report. Check the selected filters and try again.');
            const blob = await response.blob();
            if (await blob.slice(0,5).text() !== '%PDF-') throw new Error('This report did not return a PDF. Check the selected filters and try again.');
            if (controller.signal.aborted) throw new DOMException('Cancelled', 'AbortError');
            clearDocument();
            pdfUrl = URL.createObjectURL(new Blob([blob], { type: 'application/pdf' }));
            frame = document.createElement('iframe');
            frame.className = 'fcms-print-frame'; frame.title = 'Printable PDF document';
            frame.tabIndex = -1; frame.setAttribute('aria-hidden', 'true');
            await new Promise((resolve, reject) => {
                const timer = setTimeout(() => reject(new Error('The PDF viewer did not load. Try printing again.')), 15000);
                const abort = () => { clearTimeout(timer); reject(new DOMException('Cancelled','AbortError')); };
                controller.signal.addEventListener('abort', abort, { once: true });
                frame.onload = () => { clearTimeout(timer); controller.signal.removeEventListener('abort', abort); resolve(); };
                frame.onerror = () => { clearTimeout(timer); controller.signal.removeEventListener('abort', abort); reject(new Error('Unable to load the PDF viewer.')); };
                frame.src = pdfUrl;
                document.body.appendChild(frame);
            });
            clearTimeout(timeout);
            if (!controller.signal.aborted) requestPrint();
        } catch (error) {
            if (error.name === 'AbortError') {
                if (!notice.hidden) showNotice('Print preview cancelled or timed out. Please try again.', false, true);
            } else showNotice(error.message || 'Unable to prepare print preview. Please try again.', Boolean(pdfUrl), true);
        } finally {
            clearTimeout(timeout);
            if (trigger && 'disabled' in trigger) trigger.disabled = wasDisabled;
            pending = null;
        }
    }

    document.addEventListener('click', event => {
        if (event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
        const link = event.target.closest('a[href]');
        if (!link || link.hasAttribute('download') || link.hasAttribute('data-print-download')) return;
        const url = printTarget(link.href);
        if (!url) return;
        event.preventDefault(); event.stopImmediatePropagation();
        prepare(url, 'GET', null, link);
    }, true);

    document.addEventListener('submit', event => {
        const form = event.target;
        const submitter = event.submitter;
        if (!(form instanceof HTMLFormElement) || (submitter && submitter.hasAttribute('data-print-download'))) return;
        const url = printTarget(submitter && submitter.hasAttribute('formaction') ? submitter.formAction : form.action);
        if (!url) return;
        const method = (submitter && submitter.hasAttribute('formmethod') ? submitter.formMethod : form.method).toUpperCase();
        if (!['GET','POST'].includes(method)) return;
        event.preventDefault(); event.stopImmediatePropagation();
        const data = new URLSearchParams();
        for (const [name,value] of new FormData(form)) if (typeof value === 'string') data.append(name,value);
        if (submitter && submitter.name) data.append(submitter.name,submitter.value);
        if (method === 'GET') for (const [name,value] of data) url.searchParams.append(name,value);
        prepare(url, method, data, submitter);
    }, true);

    window.addEventListener('pagehide', () => { if (pending) pending.abort(); clearDocument(); if (notice) notice.hidden = true; });
})();
