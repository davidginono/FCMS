<?php
require_once __DIR__ . '/client_lifecycle.php';

// The client register forms share one status rule and one atomic save path.
function fcms_client_register_form($con, $type, $requestedId = null)
{
    $actor = fcms_client_actor($con, true);
    $con->set_charset('utf8mb4');
    $table = fcms_client_table($type);
    $names = array('SACCOS' => 'Saccos_Name', 'AMCOS' => 'Amcos_Name', 'UNION' => 'Union_Name', 'MICROFINANCE' => 'Microfinance_Name');
    $id = null;
    if ($requestedId !== null) {
        $id = filter_var($requestedId, FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
        if (!$id) { http_response_code(400); exit('Invalid client record.'); }
    }
    $currentStatus = 'ACTIVE';
    if ($id) {
        $stmt = $con->prepare("SELECT status FROM `$table` WHERE id = ?");
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$row) { http_response_code(404); exit('Client not found.'); }
        $currentStatus = $row['status'];
    }
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
        fcms_client_verify_csrf();
        try {
            $status = fcms_client_validate_status($_POST['client_status'] ?? null);
            $previous = $id ? fcms_client_validate_status($_POST['previous_client_status'] ?? null) : '';
            // Preserve each legacy form's field set; status is never payment status.
            $fields = array($names[$type], 'Entry_Date', 'expire_date', 'Region', 'Annual_fee', 'Amount',
                'Programmer_cost', 'Sys_install_fee', 'Training_fee', 'Android_fee', 'Sys_reinstall_fee',
                'bulk_sms', 'hosting_fee', 'saccos_status_id');
            if ($type === 'SACCOS') $fields = array_merge($fields, array('android_cost', 'tax', 'com', 'cloud_backup', 'backup_cost', 'invoice'));
            if ($type === 'UNION') $fields = array_merge($fields, array('tax', 'com'));
            if ($type === 'MICROFINANCE') {
                $fields = array_values(array_diff($fields, array('bulk_sms', 'hosting_fee', 'saccos_status_id')));
                if (!$id) $fields = array_values(array_diff($fields, array('Programmer_cost')));
                $fields[] = 'micro_status_id';
            }
            if (!$id || $type === 'MICROFINANCE') $fields[] = 'fyear_id';
            if ($id && $type === 'SACCOS') $fields = array_merge($fields, array('datepaid', 'ESS'));
            $values = array();
            foreach ($fields as $field) {
                $value = $_POST[$field] ?? '';
                if (!is_string($value) || mb_strlen($value, 'UTF-8') > ($field === 'ESS' ? 255 : 100)) {
                    throw new InvalidArgumentException('A client field is invalid or too long.');
                }
                if (in_array($field, array('Entry_Date', 'expire_date', 'datepaid'), true)) {
                    // These legacy registers use zero dates for unspecified dates.
                    if ($value === '') $value = $type === 'MICROFINANCE' ? null : '0000-00-00';
                    if ($value !== null && $value !== '0000-00-00') {
                        $date = DateTimeImmutable::createFromFormat('!Y-m-d', $value);
                        if (!$date || $date->format('Y-m-d') !== $value) throw new InvalidArgumentException('Enter valid dates.');
                    }
                }
                if (in_array($field, array('saccos_status_id', 'micro_status_id', 'fyear_id'), true)) {
                    $referenceId = filter_var($value, FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
                    if (!$referenceId) throw new InvalidArgumentException('Select a valid payment status and financial year.');
                    $referenceSql = $field === 'saccos_status_id' ? 'SELECT sid FROM saccos_status WHERE sid = ?' : ($field === 'micro_status_id' ? 'SELECT sid FROM micro_status WHERE sid = ?' : 'SELECT id FROM financial_year WHERE id = ?');
                    $reference = $con->prepare($referenceSql);
                    $reference->bind_param('i', $referenceId);
                    $reference->execute();
                    $exists = $reference->get_result()->num_rows > 0;
                    $reference->close();
                    if (!$exists) throw new InvalidArgumentException('Select a valid payment status and financial year.');
                }
                $values[] = $value;
            }
            if (trim($values[0]) === '') throw new InvalidArgumentException('Client name is required.');
            $fields[] = 'status';
            $values[] = $status;
            $con->begin_transaction();
            if ($id) {
                $stmt = $con->prepare("SELECT * FROM `$table` WHERE id = ? FOR UPDATE");
                $stmt->bind_param('i', $id);
                $stmt->execute();
                $locked = $stmt->get_result()->fetch_assoc();
                $stmt->close();
                if (!$locked || $locked['status'] !== $previous) throw new InvalidArgumentException('Client status changed. Reload the form before saving.');
                foreach ($fields as $index => $field) {
                    if (($_POST[$field] ?? '') === '' && array_key_exists($field, $locked) && $locked[$field] === null) {
                        $values[$index] = null;
                    }
                    if (in_array($field, array('Entry_Date', 'expire_date', 'datepaid'), true) && ($_POST[$field] ?? '') === '' &&
                        ($locked[$field] === null || $locked[$field] === '0000-00-00')) {
                        $values[$index] = $locked[$field];
                    }
                }
                $assignments = array_map(function ($field) { return '`' . $field . '` = ?'; }, $fields);
                $sql = "UPDATE `$table` SET " . implode(', ', $assignments) . ' WHERE id = ?';
                $values[] = (string)$id;
            } else {
                $sql = "INSERT INTO `$table` (`" . implode('`, `', $fields) . '`) VALUES (' . implode(', ', array_fill(0, count($fields), '?')) . ')';
            }
            $stmt = $con->prepare($sql);
            $bindTypes = str_repeat('s', count($values));
            $stmt->bind_param($bindTypes, ...$values);
            $stmt->execute();
            $savedId = $id ?: (int)$con->insert_id;
            $stmt->close();
            fcms_client_audit($con, $actor, $id ? 'client.update' : 'client.create', $type, $savedId, $previous, $status);
            $con->commit();
            $_SESSION['client_register_saved'] = true;
            $routes = array('SACCOS' => 'update_saccos.php', 'AMCOS' => 'update_amcos.php', 'UNION' => 'update_union.php', 'MICROFINANCE' => 'update_microfinance.php');
            header('Location: ' . $routes[$type] . '?id=' . $savedId, true, 303);
            exit;
        } catch (InvalidArgumentException $exception) {
            $con->rollback();
            http_response_code(409);
            exit(fcms_client_escape($exception->getMessage()));
        } catch (Throwable $exception) {
            $con->rollback();
            error_log('FCMS client form save failed; type=' . $type . '; actor=' . $actor);
            http_response_code(500);
            exit('Unable to save this client. No changes were committed.');
        }
    }
    return $currentStatus;
}

function fcms_client_register_status_field($status)
{
    if (!empty($_SESSION['client_register_saved'])) {
        unset($_SESSION['client_register_saved']);
        echo '<div class="col-12 alert alert-success" role="status">Client saved.</div>';
    }
    echo '<input type="hidden" name="csrf" value="' . fcms_client_escape(fcms_client_csrf()) . '">';
    echo '<input type="hidden" name="previous_client_status" value="' . fcms_client_escape($status) . '">';
    echo '<div class="col-md-4"><label class="form-label" for="client_status">Client status</label>';
    echo '<select id="client_status" class="form-select" name="client_status" required>';
    echo '<option value="ACTIVE"' . ($status === 'ACTIVE' ? ' selected' : '') . '>Active</option>';
    echo '<option value="INACTIVE"' . ($status === 'INACTIVE' ? ' selected' : '') . '>Inactive</option></select></div>';
}
