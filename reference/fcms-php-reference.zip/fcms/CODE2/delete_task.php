<?php
session_start();

if(!isset($_SESSION['id']))
{
    header('location:index.php');
}

require('connect.php');

$id=$_GET['id'];


$query= "DELETE FROM `tasks` where id = $id";
$result=mysqli_query($con,$query);

if($result)
{
    header("location:alltasks.php");
}else{
    echo "Failed to delete";
}

?>
