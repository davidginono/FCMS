<?php
require_once("connect.php");

if (isset($_GET['group_ref'])) {
    $group_ref = mysqli_real_escape_string($con, $_GET['group_ref']);
    $query = "DELETE FROM staff_report WHERE group_ref = '$group_ref'";
    
    if (mysqli_query($con, $query)) {
        echo "<script>alert('Group reports deleted successfully.'); window.location.href='staff_report.php';</script>";
    } else {
        echo "<script>alert('Failed to delete group reports.'); window.location.href='staff_report.php';</script>";
    }
}
?>
