<?php

session_start();
require("connect.php");

unset($_SESSION['email'],$_SESSION['password']);

session_destroy();
header("location:index.php");


?>