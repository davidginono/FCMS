<?php
// Start the session and set a custom session directory
$sessionDirectory = '/home/sites/37b/1/15b6335fc9/fcms/sessions'; // Custom session directory path

// Check if the session directory exists; if not, create it
if (!is_dir($sessionDirectory)) {
    mkdir($sessionDirectory, 0777, true); // Create the directory with appropriate permissions
}

// Set the session save path to the custom directory
ini_set('session.save_path', $sessionDirectory);

// Enable session handling with the custom save path
session_start();
require('connect.php');
?>


<!DOCTYPE html>
<html lang="en"> 
<head>
    <title>FCMS | Login </title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="description" content="Portal - Bootstrap 5 Admin Dashboard Template For Developers">
    <meta name="author" content="Xiaoying Riley at 3rd Wave Media">    
   
    

    <script defer src="assets/plugins/fontawesome/js/all.min.js"></script>
    

    <link id="theme-style" rel="stylesheet" href="assets/css/portal.css">
	<link id="theme-style" rel="stylesheet" href="assets/css/portal.css1">
	<link href="assets/css2/sb-admin-2.min.css" rel="stylesheet">

</head> 



<?php


// Database connection
// Replace with your database connection code
// $con = new mysqli('host', (getenv('FCMS_REFERENCE_USERNAME') ?: ''), (getenv('FCMS_REFERENCE_SECRET') ?: ''), 'database');
// Check connection
if (!$con) {
    die("Database connection failed: " . mysqli_connect_error());
}

// Check if form is submitted
if (isset($_POST['login'])) {
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = $_POST['password'];

    // Retrieve hashed password from the database based on email
    $sql = "SELECT id, email, `password`, role_id, status_id FROM users WHERE email = ?";
    $stmt = mysqli_prepare($con, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_assoc($result);

            // Verify password
            if (password_verify($password, $row['password'])) {
                // Check if the user is active
                if ($row['status_id'] == "1") {
                    // Store user data in session
                    $_SESSION['id'] = $row['id'];
                    $_SESSION['email'] = $row['email'];
                    $_SESSION['role_id'] = $row['role_id'];
                    
                    

                    // Redirect to appropriate page based on role
                    if ($row['role_id'] == "1") {
                        echo "<script>window.location.href='admin.php';</script>";
                        exit();
                    } else {
                        echo "<script>window.location.href='user_dashboard.php';</script>";
                        exit();
                    }
                } else {
                    // Display inactive account message
                    echo '<div class="alert alert-danger mt-3" style="width:360px; text-align: center;">';
                    echo "Your account is inactive. Please contact Admin.";
                    echo '</div>';
                }
            } else {
                // Display invalid password message
                echo '<div class="alert alert-danger mt-3" style="width:360px; text-align: center;margin-left:525px">';
                echo "Wrong Password or Email.";
                echo '</div>';
            }
        } else {
            // Display invalid login message
            echo '<div class="alert alert-danger mt-3" style="width:360px; text-align: center;margin-left:525px">';
            echo "Wrong Password or Email.";
            echo '</div>';
        }

        // Close statement
        mysqli_stmt_close($stmt);
    } else {
        // Query preparation failed
        echo '<div class="alert alert-danger mt-3" style="width:360px; text-align: center;margin-left:525px">';
        echo "Something went wrong. Please try again later or contact admin: admin@foresight.co.tz";
        echo '</div>';
    }
}
?>





  <div class="container" style="margin-top: 100px;">

        <!-- Outer Row -->
        <div class="row justify-content-center">
<!-- <center><H1>CLIENTS MANAGEMENT SYSTEMS</H1></center> -->
            <div class="col-xl-5 col-lg-12 col-md-12">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                      
                            <div class="col-lg-12">
                                <div class="p-4">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-">Welcome to FCMS </h1>
                                    </div>
                                    <br>
                                    <form class="user" method="POST">
                                        <div class="form-group">
                                            <input type="email" class="form-control form-control-user" name="email"
                                                id="exampleInputEmail" aria-describedby="emailHelp"
                                                placeholder="Email Address" required>
                                        </div>
                                        <br>
                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user" name="password"
                                                id="exampleInputPassword" placeholder="Password" required>
                                        </div>
<br>
                                        <button  class="btn btn-primary btn-user btn-block" name="login" type="submit">Login</button><br>

                                      <a class="" style="text-decoration:none;" href="forgot_password.php"> <span><i class="fas fa-fw fa-lock"></i></span>Forgot Password?</a>

                                    
<br>
                                
                                   
                                    </form>
                              
                                 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>


</body>
</html> 

