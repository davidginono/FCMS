<?php
// Database connection parameters
$host = (getenv('FCMS_REFERENCE_HOST') ?: '');
$username = (getenv('FCMS_REFERENCE_USERNAME') ?: '');
$password = (getenv('FCMS_REFERENCE_SECRET') ?: '');
$database = "fcms_db-35303539ac53";

// Establish connection
$con = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$con) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>
