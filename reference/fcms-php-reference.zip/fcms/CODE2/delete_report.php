<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Configure session directory and start session
$sessionDirectory = '/home/sites/37b/1/15b6335fc9/fcms/sessions';
ini_set('session.save_path', $sessionDirectory);
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    // Redirect to login if not logged in
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

require('connect.php');

// Check if the 'id' parameter is set and is a valid integer
if(isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];

    // Create a prepared statement
    $stmt = $con->prepare("DELETE FROM staff_report WHERE id = ?");
    
    // Bind parameter
    $stmt->bind_param("i", $id);
    
    // Execute the statement
    $stmt->execute();

    // Check if the deletion was successful
    if($stmt->affected_rows > 0) {
        header("location:staff_report.php");
    } else {
        echo "Failed to delete";
    }

    // Close the statement
    $stmt->close();
} else {
    echo "Invalid ID parameter";
}
?>
