<?php


// Database credentials
$servername = (getenv('FCMS_REFERENCE_HOST') ?: '');
$username = (getenv('FCMS_REFERENCE_USERNAME') ?: '');
$password = "";
$dbname = "lssp_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

$user_id=16;
$sql = "SELECT Image FROM users WHERE id ='$user_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    $row = $result->fetch_assoc();
    $profile_picture = $row["Image"];

    // Predefined width and height for the image
    $width = 200; // Change this to your desired width
    $height = 200; // Change this to your desired height

    // Display the profile picture with the predefined width and height
    echo "<img src='$profile_picture' alt='Profile Picture' width='$width' height='$height'>";
} else {
    echo "Profile picture not found for user with ID $user_id.";
}

// Close the database connection
$conn->close();


