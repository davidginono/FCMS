<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Configure session directory and start session
$sessionDirectory = '/home/sites/37b/1/15b6335fc9/fcms/sessions';
ini_set('session.save_path', $sessionDirectory);
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    // Redirect to login if not logged in
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

require('connect.php');

$id=$_GET['id'];


$query= "DELETE FROM microfinance where id = $id";
$result=mysqli_query($con,$query);

if($result)
{
    header("location:all_microfinance.php");
}else{
    echo "Failed to delete";
}

?>
