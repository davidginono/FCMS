<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
// Start the session and set custom session directory
$sessionDirectory = '/home/sites/37b/1/15b6335fc9/fcms/sessions';
ini_set('session.save_path', $sessionDirectory);
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    // If not logged in, redirect to the login page
echo "<script>window.location.href='index.php';</script>";
    exit();
}

require('connect.php');
?>

<?php

require('connect.php');

$id = $_GET['id'];

// JavaScript confirmation prompt
echo "<script>
    var confirmDelete = confirm('Are you sure you want to delete?');
    if (confirmDelete) {
        window.location.href = 'delete_microfinance.php?id=$id';
    } else {
        window.location.href = 'all_microfinance.php'; // Redirect back to saccos.php if canceled
    }
</script>";

?>