<?php

$sessionDirectory = '/home/sites/37b/1/15b6335fc9/fcms/sessions';
ini_set('session.save_path', $sessionDirectory);
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    // If not logged in, redirect to the login page
echo "<script>window.location.href='index.php';</script>";
    exit();
}
require('connect.php');


$id = $_GET['id'];

// Check if trying to delete own account
if ($_SESSION['id'] == $id) {
    $_SESSION['del'] = "You cannot delete yourself";
    header('location: users.php');
    exit; // Ensure no further execution
} else {
    // Perform delete operation
    $query = "DELETE FROM petty_cash WHERE id = $id";
    $result = mysqli_query($con, $query);

    if ($result) {
        header("location: petty_cash.php");
        exit; // Ensure no further execution
    } else {
        echo "Failed to delete";
    }
}
?>
