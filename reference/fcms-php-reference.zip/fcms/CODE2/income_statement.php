<!DOCTYPE html>
<html lang="en"> 
<head>
    <title>FCMS | SACCOS </title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="description" content="Portal - Bootstrap 5 Admin Dashboard Template For Developers">
    <meta name="author" content="Tean Tech">    
   

    <!-- FontAwesome JS-->
    <script defer src="assets/plugins/fontawesome/js/all.min.js"></script>
    
    <!-- App CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/portal.css">

    


    
</style>
</head> 

<body class="app">   	
    <header class="app-header fixed-top">	   	            
        <div class="app-header-inner">  
	        <div class="container-fluid py-2">
		        <div class="app-header-content"> 
		            <div class="row justify-content-between align-items-center">
			        
				    <div class="col-auto">
					    <a id="sidepanel-toggler" class="sidepanel-toggler d-inline-block d-xl-none" href="#">
						    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" role="img"><title>Menu</title><path stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2" d="M4 7h22M4 15h22M4 23h22"></path></svg>
					    </a>
				    </div><!--//col-->
		            <div class="search-mobile-trigger d-sm-none col">
			            <i class="search-mobile-trigger-icon fa-solid fa-magnifying-glass"></i>
			        </div><!--//col-->
		            <div class="app-search-box col">
		              
		            </div><!--//app-search-box-->
		            
		            <div class="app-utilities col-auto">
			            <div class="app-utility-item app-notifications-dropdown dropdown">    
				            <a class="dropdown-toggle no-toggle-arrow" id="notifications-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false" title="Notifications">
					            <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					            
					            
					        </a><!--//dropdown-toggle-->
					        
					        			        
				        </div><!--//app-utility-item-->
			          
			            
						<div class="app-utility-item app-user-dropdown dropdown">
				            <a class="dropdown-toggle" id="user-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"><?php

session_start();



 

require("connect.php");				
				$email=$_SESSION['email'];
				$query1="SELECT * FROM `users` WHERE `email`='$email'";
				$result3=mysqli_query($con,$query1);
				$usersid_fetch=mysqli_fetch_assoc($result3);
				$user_id=$usersid_fetch['id'];
				
				
$sql = "SELECT `Image`,lname,fname,email FROM users WHERE id ='$user_id'";
$result = $con->query($sql);

if ($result->num_rows > 0) {
// Output data of each row
$row = $result->fetch_assoc();
$profile_picture = $row["Image"];

// Predefined width and height for the image
$width = 200; // Change this to your desired width
$height = 200; // Change this to your desired height

$border_radius = "15px";

echo "<img src='$profile_picture' alt='Profile Picture' width='$width' height='$height' style='border-radius: $border_radius;'>";
} else {
echo "No Picture";
}
				
				
				?></a>
				            <ul class="dropdown-menu" aria-labelledby="user-dropdown-toggle">
								<li><a class="dropdown-item" href="account.php">Account</a></li>
								<li><a class="dropdown-item" href="change_password.php">Change Password</a></li>
								<li><a class="dropdown-item" href="change_profile.php">Change Profile Picture</a></li>
								<li><hr class="dropdown-divider"></li>
								<li><a class="dropdown-item" href="logout.php">Log Out</a></li>
							</ul>
			            </div><!--//app-user-dropdown--> 
		            </div><!--//app-utilities-->
		        </div><!--//row-->
	            </div><!--//app-header-content-->
	        </div><!--//container-fluid-->
        </div><!--//app-header-inner-->
        <div id="app-sidepanel" class="app-sidepanel"> 
	        <div id="sidepanel-drop" class="sidepanel-drop"></div>
	        <div class="sidepanel-inner d-flex flex-column">
		        <a href="#" id="sidepanel-close" class="sidepanel-close d-xl-none">&times;</a>
		        <div class="app-branding">
		            <a class="app-logo" href="admin.php"><img class="logo-icon me-2" src="assets/images/app-logo.png" alt="logo"><span class="logo-text">FCMS</span></a>
	
		        </div><!--//app-branding-->  
		        
			    <nav id="app-nav-main" class="app-nav app-nav-main flex-grow-1">
				    <ul class="app-menu list-unstyled accordion" id="menu-accordion">
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link active" href="admin.php">
						        <span class="nav-icon">
						        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-house-door" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
		  <path fill-rule="evenodd" d="M7.646 1.146a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 .146.354v7a.5.5 0 0 1-.5.5H9.5a.5.5 0 0 1-.5-.5v-4H7v4a.5.5 0 0 1-.5.5H2a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .146-.354l6-6zM2.5 7.707V14H6v-4a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4h3.5V7.707L8 2.207l-5.5 5.5z"/>
		  <path fill-rule="evenodd" d="M13 2.5V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
		</svg>
						         </span>
		                         <span class="nav-link-text">Dashboard</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    

	

						<li class="nav-item has-submenu">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-2" aria-expanded="false" aria-controls="submenu-2">
						        <span class="nav-icon">
								<i class="fas fa-fw fa-building"></i>
						        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
						        
						         </span>
		                         <span class="nav-link-text">Clients</span>
		                         <span class="submenu-arrow">
		                             <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
	</svg>
	                             </span><!--//submenu-arrow-->
					        </a><!--//nav-link-->
					        <div id="submenu-2" class="collapse submenu submenu-2" data-bs-parent="#menu-accordion">
						        <ul class="submenu-list list-unstyled">
								    <li class="submenu-item"><a class="submenu-link" href="all_saccos.php">SACCOS</a></li>
								    								    <li class="submenu-item"><a class="submenu-link" href="all_amcos.php">AMCOS</a></li>
								    								     <li class="submenu-item"><a class="submenu-link" href="all_union.php">UNION</a></li>
									<li class="submenu-item"><a class="submenu-link" href="all_microfinance.php">MICROFINANCE</a></li>
									<li class="submenu-item"><a class="submenu-link" href="other_client.php">OTHERS</a></li>

						        </ul>
					        </div>
					    </li><!--//nav-item-->

			<div>

			
			</div>
						
					
					
					    <li class="nav-item has-submenu">

					      
					        <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-1" aria-expanded="false" aria-controls="submenu-1">
						        <span class="nav-icon">
						        <i class="fas fa-fw fa-users"></i>
						         </span>
		                         <span class="nav-link-text">Users</span>
		                         <span class="submenu-arrow">
		                             <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
	</svg>
	                             </span>
					        </a>
					        <div id="submenu-1" class="collapse submenu submenu-1" data-bs-parent="#menu-accordion">
						        <ul class="submenu-list list-unstyled">
								    <li class="submenu-item"><a class="submenu-link" href="add_user.php"> Add New Users</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="users.php">All Users</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="active_users.php">Active Users</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="inactive_users.php">Inactive Users</a></li>
					
						        </ul>
					        </div>
					    </li>


					
						

						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="all_task.php">
						        <span class="nav-icon">
								<i class="fas fa-fw fa-tasks"></i>
						         </span>
		                         <span class="nav-link-text">Tasks</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					     <li class="nav-item has-submenu">

					      
					        <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-3" aria-expanded="false" aria-controls="submenu-3">
						        <span class="nav-icon">
						        <i class="fas fa-fw fa-file"></i>
						         </span>
		                         <span class="nav-link-text">Reports</span>
		                         <span class="submenu-arrow">
		                             <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
	</svg>
	                             </span>
					        </a>
					        <div id="submenu-3" class="collapse submenu submenu-3" data-bs-parent="#menu-accordion">
						        <ul class="submenu-list list-unstyled">

								    <li class="submenu-item"><a class="submenu-link" href="all_report.php"> Saccos Report</a></li>
                                    <li class="submenu-item"><a class="submenu-link" href="all_union_report.php"> Union Report</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="all_microfinance_report.php">Microfinance Report</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="Other Client Report">Other Client Report</a></li>
							        						            <li class="submenu-item"><a class="submenu-link" href="staff_report.php"> Staff Report</a></li>
							             <li class="submenu-item"><a class="submenu-link" href="all_statement.php">Income Statement</a></li>
					
						        </ul>
					        </div>
					    </li>
					

						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="leaves.php">
						        <span class="nav-icon">
								<i class="fas fa-fw fa-file-pdf"></i>
						         </span>
		                         <span class="nav-link-text">Staff Leaves</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->

						
					    
					    						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="expenses.php">
						        <span class="nav-icon">
						            <i class="fa-solid fa-sack-xmark"></i>
	
						         </span>
		                         <span class="nav-link-text">Expenses</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="income.php">
						        <span class="nav-icon">
				<i class="fa-solid fa-sack-dollar"></i>
						         </span>
		                         <span class="nav-link-text">Other Income</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					     
				    </ul><!--//app-menu-->

					
			    </nav><!--//app-nav-->
			    <div class="app-sidepanel-footer">
				    <nav class="app-nav app-nav-footer">
					    <ul class="app-menu footer-menu list-unstyled">
						
						 
					
					    </ul><!--//footer-menu-->
				    </nav>
			    </div><!--//app-sidepanel-footer-->
		       
	        </div><!--//sidepanel-inner-->
	    </div><!--//app-sidepanel-->
    </header><!--//app-header-->

   
    
    <div class="app-wrapper" >
	    
	    <div class="app-content pt-3 p-md-3 p-lg-4" style="margin-top:10px";>
		    <div class="container-xl">
			    
			    <div class="row g-3 mb-4 align-items-center justify-content-between">
				    <div class="col-auto">
			            <h1 class="app-page-title mb-0">Income Statement</h1>
				    </div>
				    <div class="col-auto">
					     <div class="page-utilities">
						    <div class="row g-2 justify-content-start justify-content-md-end align-items-center">
							    <div class="col-auto">
								    <!-- <form class="table-search-form row gx-1 align-items-center" method="POST" action="search_saccos.php">
					                    <div class="col-auto">
					                        <input type="text" id="search-orders" name="search" class="form-control search-orders" placeholder="Search" required>
					                    </div>
					                    <div class="col-auto">
					                        <button type="submit" class="btn app-btn-secondary">Search</button>
					                    </div>
					                </form> -->
									
					                
							    </div><!--//col-->
							  
							
						    </div><!--//row-->
					    </div><!--//table-utilities-->
				    </div><!--//col-auto-->

					

			    </div><!--//row-->


				

<!--	<form action="print_saccosreport.php" method="post">-->
    <!-- Hidden input field to pass the selected year -->
<!--    <input type="hidden" name="fyear" value="<?php echo htmlspecialchars($_POST["fyear"]); ?>">-->
    <!-- Button to trigger printing -->
<!--    <button type="submit" class="btn btn-info btn-icon-split">-->
<!--        <span class="text">-->
<!--            <i class="fas fa-fw fa-print"></i> &nbsp;Print-->
<!--        </span>-->
<!--    </button>-->
<!--</form>-->
<br>
<?php
// Get the fyear from POST request and ensure it's properly sanitized
$fyear = isset($_POST["fyear"]) ? mysqli_real_escape_string($con, $_POST["fyear"]) : "";

// Check if fyear is not empty before running the query
if (!empty($fyear)) {
    // Prepare the query
    $query = "SELECT expenses.id, date_created, description, amount, fyear, category, fname 
              FROM expenses 
              INNER JOIN users ON expenses.user_id = users.id 
              WHERE fyear = '$fyear'";

    // Execute the query
    $result2 = mysqli_query($con, $query);

    // Check if the query was successful
    if ($result2) {
        $totalAmount = 0; // Initialize total amount

        // Loop through the results and calculate the total amount
        while ($row = mysqli_fetch_assoc($result2)) {
            $totalAmount += $row['amount']; // Accumulate the amount
        }

        // Output or further process the total amount as needed
     
    } else {
        // Handle query failure (log the error or display a user-friendly message)
        echo "Error executing query: " . mysqli_error($con);
    }
} else {
    echo "Please provide a valid financial year.";
}
?>

	
				<?php


$fyear = isset($_POST["fyear"]) ? $_POST["fyear"] : ""; // Get the selected year from the POST data

if ($fyear != "") {
    // Use a prepared statement to prevent SQL injection
    $stmt = $con->prepare("SELECT * FROM income WHERE YEAR(date) = ?");
    $stmt->bind_param("i", $fyear); // Bind the year as an integer

    // Execute the statement
    $stmt->execute();
    $result1 = $stmt->get_result();



    $stmt->close(); // Close the statement
} else {
    echo "Please select a year.";
}


// Initialize total amount
$total_amount = 0;

// First loop to calculate the total amount
while ($row = mysqli_fetch_assoc($result1)) {
    $total_amount += $row['amount'];
}

// Reset result pointer
mysqli_data_seek($result1, 0);
?>

<?php
require("connect.php");

$selected_year = isset($_POST["fyear"]) ? $_POST["fyear"] : "";

// Validate and sanitize input to prevent SQL injection
if (!is_numeric($selected_year) || $selected_year < 1900 || $selected_year > 2100) {
    die("Invalid year selected.");
}

// Prepare the query with a parameterized statement to avoid SQL injection
$query = $con->prepare("SELECT saccos.id, saccos_name, Entry_Date, Region,backup_cost, Amount, saccos_status.Name, expire_date, Annual_fee, pfile, 
    Sys_install_fee, Training_fee, Android_fee, Sys_reinstall_fee,hosting_fee,com, tax, Programmer_cost, fyear 
    FROM saccos 
    INNER JOIN saccos_status ON saccos.saccos_status_id = saccos_status.sid 
    INNER JOIN financial_year ON saccos.fyear_id = financial_year.id 
    WHERE fyear = ? AND filter=1
    ORDER BY saccos_name ASC");

// Bind the selected year as a parameter
$query->bind_param("i", $selected_year);

// Execute the query
$query->execute();

// Fetch results
$result1 = $query->get_result();

echo "<center>";
echo "<h3>YEAR: " . htmlspecialchars($selected_year) . "</h3>";
echo "</center>";


// Initialize grand totals
$grand_total_profit = 0;

while ($row = $result1->fetch_assoc()) {
    // Extract relevant fields
    $com = (float)$row['com'];
    $bulk = (float)$row['bulk_sms'];
    $hosting = (float)$row['hosting_fee'];
    $sys_install_fee = (float)$row['Sys_install_fee'];
    $training_fee = (float)$row['Training_fee'];
    $android_fee = (float)$row['Android_fee'];
    $sys_reinstall_fee = (float)$row['Sys_reinstall_fee'];
    $amount = (float)$row['Amount'];
    $backupcost = (float)$row['backup_cost'];
    $programmer_cost = (float)$row['Programmer_cost'];

    // Calculate total fee and profit
    $total_fee = $amount + $sys_install_fee + $training_fee + $backupcost + $android_fee + $sys_reinstall_fee + $hosting + $bulk;
    $profit = $total_fee - $programmer_cost - $com;

    // Accumulate grand total profit
    $grand_total_profit += $profit;
    

    

}
 


?>


<?php
require("connect.php");

$selected_year = isset($_POST["fyear"]) ? $_POST["fyear"] : "";

// Validate and sanitize input to prevent SQL injection
if (!is_numeric($selected_year) || $selected_year < 1900 || $selected_year > 2100) {
    die("Invalid year selected.");
}

// Prepare the query with a parameterized statement to avoid SQL injection
$query = $con->prepare("SELECT union.id, union_name, Entry_Date, Region, Amount, saccos_status.Name, expire_date, Annual_fee, pfile, 
    Sys_install_fee, Training_fee, Android_fee, Sys_reinstall_fee, com, tax,hosting_fee, Programmer_cost, fyear 
    FROM `union` 
    INNER JOIN saccos_status ON union.saccos_status_id = saccos_status.sid 
    INNER JOIN financial_year ON union.fyear_id = financial_year.id 
    WHERE fyear = ? ");

// Bind the selected year as a parameter
$query->bind_param("i", $selected_year);

// Execute the query
$query->execute();

// Fetch results
$result3 = $query->get_result();




// Initialize grand totals
$union_grand_total_profit = 0;

while ($row = $result3->fetch_assoc()) {
    // Extract relevant fields
    $com = (float)$row['com'];
    $bulk = (float)$row['bulk_sms'];
    $hosting = (float)$row['hosting_fee'];
    $sys_install_fee = (float)$row['Sys_install_fee'];
    $training_fee = (float)$row['Training_fee'];
    $android_fee = (float)$row['Android_fee'];
    $sys_reinstall_fee = (float)$row['Sys_reinstall_fee'];
    $amount = (float)$row['Amount'];
    $programmer_cost = (float)$row['Programmer_cost'];

    // Calculate total fee and profit
    $total_fee = $amount + $sys_install_fee + $training_fee + $android_fee + $sys_reinstall_fee + $hosting + $bulk;
    $profit = $total_fee - $programmer_cost - $com;

    // Accumulate grand total profit
    $union_grand_total_profit += $profit;
}




 $total_revenue=$grand_total_profit + $union_grand_total_profit+ $total_amount;
 $netprofit=$total_revenue - $totalAmount;



?>



<!-- Display the results in a table -->

<br>
<div class="card-body">
    <div class="table-responsive">
        <table class="table table-bordered sticky-header-table" id="dataTable" width="100%" cellspacing="0" style="text-align:center;">
            <thead>
                <tr class="sticky-header">
                    
                    <th>
    <?php
    // Get fyear_id from financial_year table
    $fyear = $selected_year; // e.g. 2025
    $stmt = $con->prepare("SELECT id FROM financial_year WHERE fyear = ?");
    $stmt->bind_param("i", $fyear);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $fyear_id = $row['id'];
    ?>

    <a href="saccos_revenues.php?fyearid=<?php echo urlencode($fyear_id); ?>">
        Saccos Revenues
    </a>
</th>
                        <th>
    <?php
    // Get fyear_id from financial_year table
    $fyear = $selected_year; // e.g. 2025
    $stmt = $con->prepare("SELECT id FROM financial_year WHERE fyear = ?");
    $stmt->bind_param("i", $fyear);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $fyear_id = $row['id'];
    ?>

    <a href="union_revenues.php?fyearid=<?php echo urlencode($fyear_id); ?>">
        Union Revenues
    </a>
</th>

                   <th>
    <?php
    // Get fyear_id from financial_year table
    $fyear = $selected_year; // e.g. 2025
    $stmt = $con->prepare("SELECT id FROM financial_year WHERE fyear = ?");
    $stmt->bind_param("i", $fyear);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $fyear_id = $row['id'];
    ?>

    <a href="other_revenues.php?fyearid=<?php echo urlencode($fyear_id); ?>">
        Other Revenues
    </a>
</th>
                             <th>Total Revenue</th>
                    <th>Expenses</th>
                    <th>Net Profit</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <!-- Display the grand total profit -->
                    <td><?php echo number_format($grand_total_profit, 2); ?></td>
                          <td><?php echo number_format($union_grand_total_profit, 2); ?></td>
                    <td><?php echo number_format($total_amount, 2); // Placeholder for other income ?></td>
                    <td><?php echo number_format($total_revenue, 2); // Placeholder for other income ?></td>
                    <td><?php echo number_format($totalAmount, 2); // Placeholder for other income ?></td>
                    <td><?php echo number_format( $netprofit, 2); // Net Profit = Total Profit in this case ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php
// Close the database connection
$con->close();
?>



				

					
			    
			    <!-- <nav id="orders-table-tab" class="orders-table-tab app-nav-tabs nav shadow-sm flex-column flex-sm-row mb-4">
				    <a class="flex-sm-fill text-sm-center nav-link active" id="orders-all-tab" data-bs-toggle="tab" href="#orders-all" role="tab" aria-controls="orders-all" aria-selected="true">All</a>
				    <a class="flex-sm-fill text-sm-center nav-link"  id="orders-paid-tab" data-bs-toggle="tab" href="#orders-paid" role="tab" aria-controls="orders-paid" aria-selected="false">Active</a>
				    <a class="flex-sm-fill text-sm-center nav-link" id="orders-pending-tab" data-bs-toggle="tab" href="#orders-pending" role="tab" aria-controls="orders-pending" aria-selected="false">Pending</a>
				    <a class="flex-sm-fill text-sm-center nav-link" id="orders-cancelled-tab" data-bs-toggle="tab" href="#orders-cancelled" role="tab" aria-controls="orders-cancelled" aria-selected="false">Cancelled</a>
				</nav> -->
				
				
				
						        </div><!--//table-responsive-->
						    </div><!--//app-card-body-->		
						</div><!--//app-card-->
			        </div><!--//tab-pane-->
				</div><!--//tab-content-->
				
				
			    
		    </div><!--//container-fluid-->
	    </div><!--//app-content-->
	    
	   
	    
    </div><!--//app-wrapper-->    					

 
    <!-- Javascript -->          
    <script src="assets/plugins/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>  
    
    
    <!-- Page Specific JS -->
    <script src="assets/js/app.js"></script> 
	<script>
    // Set the inactivity timeout duration in milliseconds (e.g., 15 minutes)
const inactivityTimeout =5 * 60 * 1000; // 15 minutes in milliseconds

let logoutTimer;

// Reset the timer on user activity
function resetLogoutTimer() {
    clearTimeout(logoutTimer);
    logoutTimer = setTimeout(logoutUser, inactivityTimeout);
}

// Logout the user when the timeout is reached
function logoutUser() {
    // Perform logout actions here (e.g., clear session data, redirect to logout page)
    window.location.href='logout.php';
    // You can replace the alert with actual logout code.
}

// Initialize the timer when the page loads or after user activity
window.onload = resetLogoutTimer;
document.onmousemove = resetLogoutTimer; // You can add more events like keypress, etc. for user activity

// Optionally, you can also handle clicks on specific elements to reset the timer
// For example, if you have a button that keeps the user logged in
const keepLoggedInButton = document.getElementById('keep-logged-in-button');
keepLoggedInButton.addEventListener('click', resetLogoutTimer);
</script>



</body>
</html> 

