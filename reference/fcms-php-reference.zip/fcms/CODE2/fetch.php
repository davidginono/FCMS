<?php

session_start();
require('connect.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FCMS</title>
</head>

<body>
    <?php
    $dfile=$_GET['file'];
    ?>
    <iframe src="<?php echo $dfile;?>" type="application/pdf"width="100%" height="900px" frameborder="0"></iframe>
</body>
</html>