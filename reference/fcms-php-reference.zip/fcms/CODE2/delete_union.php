<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Configure session directory and start session
$sessionDirectory = '/home/sites/37b/1/15b6335fc9/fcms/sessions';
ini_set('session.save_path', $sessionDirectory);
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    // Redirect to login if not logged in
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

require('connect.php');

// Validate and sanitize ID
$id = (int) filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT); // Cast to integer and sanitize

// Check for valid ID (optional, adjust based on your table structure)
if ($id <= 0) {
    echo "Invalid ID";
    exit;
}

// Use prepared statements for secure deletion
$stmt = mysqli_prepare($con, "DELETE FROM `union` WHERE `id` = ?");
mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt)) {
    header("location:all_union.php");
} else {
    echo "Failed to delete";
    echo "<br>Error: " . mysqli_error($con); // Include for debugging, remove in production
}

mysqli_stmt_close($stmt);

?>
