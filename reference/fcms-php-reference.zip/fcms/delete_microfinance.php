<?php
$clientDeleteType = 'MICROFINANCE';
require __DIR__ . '/client_delete.php';
