<?php
$sessionDirectory = '/home/sites/37b/1/15b6335fc9/fcms/sessions';
ini_set('session.save_path', $sessionDirectory);
session_start();
if (!isset($_SESSION['email'])) {
    echo "<script>window.location.href='index.php';</script>";
    exit();
}
require("connect.php");
$selected_year = isset($_POST["fyear"]) ? $_POST["fyear"] : (isset($_GET["fyear"]) ? $_GET["fyear"] : "");
if ($selected_year === "") {
    $latest_year_result = mysqli_query($con, "SELECT fyear FROM financial_year ORDER BY fyear DESC LIMIT 1");
    if ($latest_year_result && $latest_year_row = mysqli_fetch_assoc($latest_year_result)) {
        $selected_year = $latest_year_row['fyear'];
    }
}
?>
<!DOCTYPE html>
<html lang="en"> 
<head>
    <link rel="stylesheet" href="assets/css/print-preview.css?v=20261103-1">
    <script defer src="assets/js/print-preview.js?v=20261103-1"></script>
    <title>FCMS | SACCOS </title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="description" content="Portal - Bootstrap 5 Admin Dashboard Template For Developers">
    <meta name="author" content="Tean Tech">    
   
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <!-- FontAwesome JS-->
    <script defer src="assets/plugins/fontawesome/js/all.min.js"></script>
    
    <!-- App CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/portal.css?v=20260712-7">

    
<style>
 .sticky-header-table {
    overflow-y: auto;
    height: 300px;
}

.sticky-header-table th {
    position: sticky;
    top: 0;
    z-index: 1;
    background-color: #f2f2f2;
}
</style>

    
</style>
</head> 

<body class="app">   	
    <header class="app-header fixed-top">	   	            
        <div class="app-header-inner">  
	        <div class="container-fluid py-2">
		        <div class="app-header-content"> 
		            <div class="row justify-content-between align-items-center">
			        
				    <div class="col-auto">
					    <a id="sidepanel-toggler" class="sidepanel-toggler d-inline-block d-xl-none" href="#">
						    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" role="img"><title>Menu</title><path stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2" d="M4 7h22M4 15h22M4 23h22"></path></svg>
					    </a>
				    </div><!--//col-->
		            <div class="search-mobile-trigger d-sm-none col">
			            <i class="search-mobile-trigger-icon fa-solid fa-magnifying-glass"></i>
			        </div><!--//col-->
		            <div class="app-search-box col">
		              
		            </div><!--//app-search-box-->
		            
		            <div class="app-utilities col-auto">
			            <div class="app-utility-item app-notifications-dropdown dropdown">    
				            <a class="dropdown-toggle no-toggle-arrow" id="notifications-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false" title="Notifications">
					            <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					            
					            
					        </a><!--//dropdown-toggle-->
					        
					        			        
				        </div><!--//app-utility-item-->
			          
			            
						<div class="app-utility-item app-user-dropdown dropdown">
				            <a class="dropdown-toggle" id="user-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"><span class="navbar-profile-icon"><i class="fa-solid fa-user"></i></span></a><ul class="dropdown-menu" aria-labelledby="user-dropdown-toggle">
								<li><a class="dropdown-item" href="account.php">Account</a></li>
								<li><a class="dropdown-item" href="change_password.php">Change Password</a></li>
								<li><a class="dropdown-item" href="change_profile.php">Change Profile Picture</a></li>
								<li><hr class="dropdown-divider"></li>
								<li><a class="dropdown-item" href="logout.php">Log Out</a></li>
							</ul>
			            </div><!--//app-user-dropdown--> 
		            </div><!--//app-utilities-->
		        </div><!--//row-->
	            </div><!--//app-header-content-->
	        </div><!--//container-fluid-->
        </div><!--//app-header-inner-->
        <div id="app-sidepanel" class="app-sidepanel"> 
	        <div id="sidepanel-drop" class="sidepanel-drop"></div>
	        <div class="sidepanel-inner d-flex flex-column">
		        <a href="#" id="sidepanel-close" class="sidepanel-close d-xl-none">&times;</a>
		        <div class="app-branding">
		            <a class="app-logo" href="admin.php"><img class="logo-icon me-2" src="assets/images/app-logo.png" alt="logo"><span class="logo-text">FCMS</span></a>
	
		        </div><!--//app-branding-->  
		        
			    <nav id="app-nav-main" class="app-nav app-nav-main flex-grow-1">
				    <ul class="app-menu list-unstyled accordion" id="menu-accordion">
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link active" href="admin.php">
						        <span class="nav-icon">
						        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-house-door" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
		  <path fill-rule="evenodd" d="M7.646 1.146a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 .146.354v7a.5.5 0 0 1-.5.5H9.5a.5.5 0 0 1-.5-.5v-4H7v4a.5.5 0 0 1-.5.5H2a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .146-.354l6-6zM2.5 7.707V14H6v-4a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4h3.5V7.707L8 2.207l-5.5 5.5z"/>
		  <path fill-rule="evenodd" d="M13 2.5V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
		</svg>
						         </span>
		                         <span class="nav-link-text">Dashboard</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="admin2.php">
						        <span class="nav-icon">
						        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-speedometer2" viewBox="0 0 16 16">
  <path d="M8 4a.5.5 0 0 1 .5.5V6a.5.5 0 0 1-1 0V4.5A.5.5 0 0 1 8 4M3.732 5.732a.5.5 0 0 1 .707 0l.915.914a.5.5 0 1 1-.708.708l-.914-.915a.5.5 0 0 1 0-.707M2 10a.5.5 0 0 1 .5-.5h1.586a.5.5 0 0 1 0 1H2.5A.5.5 0 0 1 2 10m9.5 0a.5.5 0 0 1 .5-.5h1.5a.5.5 0 0 1 0 1H12a.5.5 0 0 1-.5-.5m.754-4.246a.39.39 0 0 0-.527-.02L7.547 9.31a.91.91 0 1 0 1.302 1.258l3.434-4.297a.39.39 0 0 0-.029-.518z"/>
  <path fill-rule="evenodd" d="M0 10a8 8 0 1 1 15.547 2.661c-.442 1.253-1.845 1.602-2.932 1.25C11.309 13.488 9.475 13 8 13c-1.474 0-3.31.488-4.615.911-1.087.352-2.49.003-2.932-1.25A8 8 0 0 1 0 10m8-7a7 7 0 0 0-6.603 9.329c.203.575.923.876 1.68.63C4.397 12.533 6.358 12 8 12s3.604.532 4.923.96c.757.245 1.477-.056 1.68-.631A7 7 0 0 0 8 3"/>
</svg>
						         </span>
		                         <span class="nav-link-text">Amcos Dashboard</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="admin3.php">
						        <span class="nav-icon">
						        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-speedometer2" viewBox="0 0 16 16">
  <path d="M8 4a.5.5 0 0 1 .5.5V6a.5.5 0 0 1-1 0V4.5A.5.5 0 0 1 8 4M3.732 5.732a.5.5 0 0 1 .707 0l.915.914a.5.5 0 1 1-.708.708l-.914-.915a.5.5 0 0 1 0-.707M2 10a.5.5 0 0 1 .5-.5h1.586a.5.5 0 0 1 0 1H2.5A.5.5 0 0 1 2 10m9.5 0a.5.5 0 0 1 .5-.5h1.5a.5.5 0 0 1 0 1H12a.5.5 0 0 1-.5-.5m.754-4.246a.39.39 0 0 0-.527-.02L7.547 9.31a.91.91 0 1 0 1.302 1.258l3.434-4.297a.39.39 0 0 0-.029-.518z"/>
  <path fill-rule="evenodd" d="M0 10a8 8 0 1 1 15.547 2.661c-.442 1.253-1.845 1.602-2.932 1.25C11.309 13.488 9.475 13 8 13c-1.474 0-3.31.488-4.615.911-1.087.352-2.49.003-2.932-1.25A8 8 0 0 1 0 10m8-7a7 7 0 0 0-6.603 9.329c.203.575.923.876 1.68.63C4.397 12.533 6.358 12 8 12s3.604.532 4.923.96c.757.245 1.477-.056 1.68-.631A7 7 0 0 0 8 3"/>
</svg>
						         </span>
		                         <span class="nav-link-text">Union Dashboard</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
	

						<li class="nav-item has-submenu">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-2" aria-expanded="false" aria-controls="submenu-2">
						        <span class="nav-icon">
								<i class="fas fa-fw fa-building"></i>
						        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
						        
						         </span>
		                         <span class="nav-link-text">Clients</span>
		                         <span class="submenu-arrow">
		                             <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
	</svg>
	                             </span><!--//submenu-arrow-->
					        </a><!--//nav-link-->
					        <div id="submenu-2" class="collapse submenu submenu-2" data-bs-parent="#menu-accordion">
						        <ul class="submenu-list list-unstyled">
								    <?php require __DIR__ . '/admin_client_menu.php'; ?>

						        </ul>
					        </div>
					    </li><!--//nav-item-->

			<div>

			
			</div>
						
					
					
					    <li class="nav-item has-submenu">

					      
					        <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-1" aria-expanded="false" aria-controls="submenu-1">
						        <span class="nav-icon">
						        <i class="fas fa-fw fa-users"></i>
						         </span>
		                         <span class="nav-link-text">Users</span>
		                         <span class="submenu-arrow">
		                             <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
	</svg>
	                             </span>
					        </a>
					        <div id="submenu-1" class="collapse submenu submenu-1" data-bs-parent="#menu-accordion">
						        <ul class="submenu-list list-unstyled">
								    <li class="submenu-item"><a class="submenu-link" href="add_user.php"> Add New Users</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="users.php">All Users</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="active_users.php">Active Users</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="inactive_users.php">Inactive Users</a></li>
					
						        </ul>
					        </div>
					    </li>


					
						

						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="all_task.php">
						        <span class="nav-icon">
								<i class="fas fa-fw fa-tasks"></i>
						         </span>
		                         <span class="nav-link-text">Tasks</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					     <li class="nav-item has-submenu">

					      
					        <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-3" aria-expanded="false" aria-controls="submenu-3">
						        <span class="nav-icon">
						        <i class="fas fa-fw fa-file"></i>
						         </span>
		                         <span class="nav-link-text">Reports</span>
		                         <span class="submenu-arrow">
		                             <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
	</svg>
	                             </span>
					        </a>
					        <div id="submenu-3" class="collapse submenu submenu-3" data-bs-parent="#menu-accordion">
						        <ul class="submenu-list list-unstyled">

								    <li class="submenu-item"><a class="submenu-link" href="report.php"> Saccos Report</a></li>
                                    <li class="submenu-item"><a class="submenu-link" href="union_report.php"> Union Report</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="microfinance_report.php">Microfinance Report</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="other_report.php">Other Client Report</a></li>
							        						            <li class="submenu-item"><a class="submenu-link" href="staff_report.php"> Staff Report</a></li>
							             <li class="submenu-item"><a class="submenu-link" href="income_statement.php">Income Statement</a></li>
					
						        </ul>
					        </div>
					    </li>
					

						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="leaves.php">
						        <span class="nav-icon">
								<i class="fas fa-fw fa-file-pdf"></i>
						         </span>
		                         <span class="nav-link-text">Staff Leaves</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->

						
					    
					    						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="expenses.php">
						        <span class="nav-icon">
						            <i class="fa-solid fa-sack-xmark"></i>
	
						         </span>
		                         <span class="nav-link-text">Expenses</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="income.php">
						        <span class="nav-icon">
				<i class="fa-solid fa-sack-dollar"></i>
						         </span>
		                         <span class="nav-link-text">Other Income</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="petty_cash.php">
						        <span class="nav-icon">
				<i class="fa-solid fa-sack-dollar"></i>
						         </span>
		                         <span class="nav-link-text">Petty Cash</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					     
   <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="cloud_backup.php">
						        <span class="nav-icon">
				<i class="fa-solid fa-sack-dollar"></i>
						         </span>
		                         <span class="nav-link-text">Cloud Backup</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
<li class="nav-item">
    <!-- Font Awesome icon -->
    <a class="nav-link" href="backup.php">
        <span class="nav-icon">
            <i class="fas fa-hdd"></i> <!-- Hard drive icon -->
        </span>
        <span class="nav-link-text">System Backup</span>
    </a>
</li>





						
    
					
						
					 

					   
					    
					    
										    
				    </ul><!--//app-menu-->

					
			    </nav><!--//app-nav-->
			    <div class="app-sidepanel-footer">
				    <div class="sidepanel-company">
					    <img class="sidepanel-company-logo" src="assets/images/app-logo.png" alt="Computer Recources ltd">
					    <span class="sidepanel-company-text">Computer Recources ltd</span>
				    </div>
			    </div><!--//app-sidepanel-footer-->
		       
	        </div><!--//sidepanel-inner-->
	    </div><!--//app-sidepanel-->
    </header><!--//app-header-->

   
    
    <div class="app-wrapper" >
	    
	    <div class="app-content pt-3 p-md-3 p-lg-4" style="margin-top:10px";>
		    <div class="container-xl">
			    
			    <div class="row g-3 mb-4 align-items-center justify-content-between">
				    <div class="col-auto">
			            <h1 class="app-page-title mb-0">TOTAL HOSTING FEE</h1>
				    </div>
				    <div class="col-auto">
					     <div class="page-utilities">
						    <div class="row g-2 justify-content-start justify-content-md-end align-items-center">
							    <div class="col-auto">
								    <!-- <form class="table-search-form row gx-1 align-items-center" method="POST" action="search_saccos.php">
					                    <div class="col-auto">
					                        <input type="text" id="search-orders" name="search" class="form-control search-orders" placeholder="Search" required>
					                    </div>
					                    <div class="col-auto">
					                        <button type="submit" class="btn app-btn-secondary">Search</button>
					                    </div>
					                </form> -->
									
					                
							    </div><!--//col-->
							  
							
						    </div><!--//row-->
					    </div><!--//table-utilities-->
				    </div><!--//col-auto-->

					

			    </div><!--//row-->

<form method="get" action="hostingfee.php" class="row g-2 align-items-end mb-3">
    <div class="col-sm-6 col-md-4 col-lg-3">
        <label class="form-label mb-1" for="reportYear">Fiscal Year</label>
        <select name="fyear" id="reportYear" class="form-select" required>
            <?php
            $year_result = mysqli_query($con, "SELECT fyear FROM financial_year ORDER BY fyear DESC");
            while ($year_row = mysqli_fetch_assoc($year_result)) {
                $selected = ($selected_year == $year_row['fyear']) ? 'selected' : '';
                echo '<option value="' . htmlspecialchars($year_row['fyear']) . '" ' . $selected . '>' . htmlspecialchars($year_row['fyear']) . '</option>';
            }
            ?>
        </select>
    </div>
    <div class="col-auto">
        <button type="submit" class="btn btn-success"><i class="fas fa-fw fa-filter"></i>&nbsp;Filter</button>
    </div>
    <div class="col-auto">
        <a href="hostingfee.php" class="btn btn-secondary">Reset</a>
    </div>
</form>

<form action="print_saccosreport.php" method="post" style="display: inline-block;">
<input type="hidden" name="fyear" value="<?php echo htmlspecialchars($selected_year); ?>">
<input type="hidden" name="report_type" value="hosting_fee">
  <button type="submit" class="btn btn-info btn-icon-split">
    <span class="icon"><i class="fas fa-fw fa-print"></i></span>
    <span class="text">Print</span>
  </button>
</form>

	<form action="print_saccosreport_excel.php" method="post" style="display: inline-block;">
  <input type="hidden" name="fyear" value="<?php echo htmlspecialchars($selected_year); ?>">
  <input type="hidden" name="report_type" value="hosting_fee">
  <button type="submit" class="btn btn-info btn-icon-split">
    <span class="icon"><i class="fas fa-fw fa-file-excel"></i></span>
    <span class="text">Download Excel</span>
  </button>
</form>
<br>

<?php
// Check if fyear_id is set in the request data

// Validate $selected_year here to prevent SQL injection
// Example validation: 
// if (!is_numeric($selected_year) || $selected_year < 1900 || $selected_year > 2100) {
//     die("Invalid year selected.");
// }

$query = "SELECT saccos.id, saccos_name, Entry_Date, Region, Amount,hosting_fee,saccos_status.Name,bulk_sms,backup_cost,cloud_backup,expire_date, Annual_fee, `pfile`, Sys_install_fee, Training_fee, Android_fee, android_cost, Sys_reinstall_fee,com,tax, Programmer_cost, fyear 
          FROM saccos 
          INNER JOIN saccos_status ON saccos.saccos_status_id=saccos_status.sid 
          INNER JOIN financial_year ON saccos.fyear_id=financial_year.id 
          WHERE fyear=$selected_year AND filter=1
          ORDER BY saccos_name ASC";

$result1 = mysqli_query($con, $query);

echo "<center>";
// Print the selected year as heading
echo "<h2>TOTAL HOSTING FEE FOR: " . htmlspecialchars($selected_year) . "</h2>";
echo "</center>";
// Example validation: 
// if ($result1 === false) {
//     die("Database error: " . mysqli_error($con));
// }

// Use the $result1 variable as needed in your code
?>
<br>

<div class="card-body">
    <div class="table-responsive">
        <table class="table table-bordered sticky-header-table" id="dataTable" width="100%" cellspacing="0" style="text-align:center;">
    <thead>
        <tr class="sticky-header">
            <th>No</th>
            <th>Saccos Name</th>
            <th>Hosting Fee</th>
                                    
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        $grand_total_com = 0;
        $grand_total_tax = 0;
        $grand_total_bulk = 0;
        $grand_total_hosting = 0;
        $grand_total_backup_fee = 0;
        $grand_total_backup_cost = 0;
        $grand_total_annual_fee = 0;
        $grand_total_amount = 0;
        $grand_total_programmer_cost = 0;
        $grand_total_sys_install_fee = 0;
        $grand_total_training_fee = 0;
        $grand_total_android_fee = 0;
        $grand_total_android_cost = 0;
        $grand_total_sys_reinstall_fee = 0;
        $grand_total_total = 0;
        $grand_total_profit = 0;

        while ($row = mysqli_fetch_assoc($result1)) {
            $tax = (float)$row['tax'];
            $com = (float)$row['com'];
            $bulk = (float)$row['bulk_sms'];
            $hosting = (float)$row['hosting_fee'];
            $backup = (float)$row['cloud_backup'];
            $backup_cost = (float)$row['backup_cost'];
            $annual_fee = (float)$row['Annual_fee'];
            $sys_install_fee = (float)$row['Sys_install_fee'];
            $training_fee = (float)$row['Training_fee'];
            $android_fee = (float)$row['Android_fee'];
            $android_cost = (float)$row['android_cost'];
            $sys_reinstall_fee = (float)$row['Sys_reinstall_fee'];
            $amount = (float)$row['Amount'];
            $programmer_cost = (float)$row['Programmer_cost'];

            $total_fee = $amount + $sys_install_fee + $training_fee + $android_fee + $sys_reinstall_fee + $hosting + $bulk +$backup;
            $profit = $total_fee - $programmer_cost - $com - $backup_cost - $android_cost;

            $grand_total_annual_fee += $annual_fee;
            $grand_total_amount += $amount;
            $grand_total_tax += $tax;
            $grand_total_com += $com;
            $grand_total_bulk += $bulk;
            $grand_total_hosting += $hosting;
            $grand_total_backup_fee += $backup;
            $grand_total_backup_cost += $backup_cost;
            $grand_total_programmer_cost += $programmer_cost;
            $grand_total_sys_install_fee += $sys_install_fee;
            $grand_total_training_fee += $training_fee;
            $grand_total_android_fee += $android_fee;
            $grand_total_android_cost += $android_cost;
            $grand_total_sys_reinstall_fee += $sys_reinstall_fee;
            $grand_total_total += $total_fee;
            $grand_total_profit += $profit;
        ?>
            <tr>
                <td><?php echo $no++ ?></td>
                 <td style="text-align:left;"><?php echo $row['saccos_name'] ?></td>
                <td style="text-align:center"><?php echo number_format($hosting) ?></td>
                     
            </tr>
        <?php } ?>
    </tbody>
    <tfoot>
        <tr>
            <th colspan="2" style="background-color:gray;">Grand Total</th>
            
                        <td style="background-color:gray;font-weight:bold;"><?php echo number_format($grand_total_hosting) ?></td>
                        
        </tr>
    </tfoot>
</table>

    </div>
</div>


				

					
			    
			    <!-- <nav id="orders-table-tab" class="orders-table-tab app-nav-tabs nav shadow-sm flex-column flex-sm-row mb-4">
				    <a class="flex-sm-fill text-sm-center nav-link active" id="orders-all-tab" data-bs-toggle="tab" href="#orders-all" role="tab" aria-controls="orders-all" aria-selected="true">All</a>
				    <a class="flex-sm-fill text-sm-center nav-link"  id="orders-paid-tab" data-bs-toggle="tab" href="#orders-paid" role="tab" aria-controls="orders-paid" aria-selected="false">Active</a>
				    <a class="flex-sm-fill text-sm-center nav-link" id="orders-pending-tab" data-bs-toggle="tab" href="#orders-pending" role="tab" aria-controls="orders-pending" aria-selected="false">Pending</a>
				    <a class="flex-sm-fill text-sm-center nav-link" id="orders-cancelled-tab" data-bs-toggle="tab" href="#orders-cancelled" role="tab" aria-controls="orders-cancelled" aria-selected="false">Cancelled</a>
				</nav> -->
				
				
				
						        </div><!--//table-responsive-->
						    </div><!--//app-card-body-->		
						</div><!--//app-card-->
			        </div><!--//tab-pane-->
				</div><!--//tab-content-->
				
				
			    
		    </div><!--//container-fluid-->
	    </div><!--//app-content-->
	    
	   
	    
    </div><!--//app-wrapper-->    					

 
    <!-- Javascript -->          
    <script src="assets/plugins/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>  
    
    
    <!-- Page Specific JS -->
    <script src="assets/js/app.js?v=20260712-7"></script> 
	<script>
    // Set the inactivity timeout duration in milliseconds (e.g., 15 minutes)
const inactivityTimeout =5 * 60 * 1000; // 15 minutes in milliseconds

let logoutTimer;

// Reset the timer on user activity
function resetLogoutTimer() {
    clearTimeout(logoutTimer);
    logoutTimer = setTimeout(logoutUser, inactivityTimeout);
}

// Logout the user when the timeout is reached
function logoutUser() {
    // Perform logout actions here (e.g., clear session data, redirect to logout page)
    window.location.href='logout.php';
    // You can replace the alert with actual logout code.
}

// Initialize the timer when the page loads or after user activity
window.onload = resetLogoutTimer;
document.onmousemove = resetLogoutTimer; // You can add more events like keypress, etc. for user activity

// Optionally, you can also handle clicks on specific elements to reset the timer
// For example, if you have a button that keeps the user logged in
const keepLoggedInButton = document.getElementById('keep-logged-in-button');
keepLoggedInButton.addEventListener('click', resetLogoutTimer);
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html> 
