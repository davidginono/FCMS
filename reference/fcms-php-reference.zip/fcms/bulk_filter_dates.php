<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
// Start the session and set custom session directory
$sessionDirectory = '/home/sites/37b/1/15b6335fc9/fcms/sessions';
ini_set('session.save_path', $sessionDirectory);
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    // If not logged in, redirect to the login page
echo "<script>window.location.href='index.php';</script>";
    exit();
}

require('connect.php');
?>

<!DOCTYPE html>
<html lang="en"> 
<head>
    <title>FCMS |   PETTY CASH </title>
    
    
				  <br><br>

	
			    																  	   

	
			<?php
require("connect.php");

$fromdate = htmlspecialchars($_POST['startDate']);
$todate = htmlspecialchars($_POST['endDate']);

// Format dates to YYYY-MM-DD format
$fromdate = date('Y-m-d', strtotime($fromdate));
$todate = date('Y-m-d', strtotime($todate));

// Query to get filtered petty cash data based on date range
$query = "SELECT bulk_sms.id, fname,trans_date, trans_name, description, amount_in, amount_out, bulk_sms.created_at 
          FROM bulk_sms
          INNER JOIN users ON bulk_sms.user_id = users.id 
          INNER JOIN trans_cat ON bulk_sms.trans_id = trans_cat.id 
          WHERE trans_date BETWEEN '$fromdate' AND '$todate'
          ORDER BY trans_date DESC";
$result1 = mysqli_query($con, $query);
?>

<div class="card-body">
    <div class="table-responsive">
        
				
				
				
						        </div><!--//table-responsive-->
						    </div><!--//app-card-body-->		
						</div><!--//app-card-->
			        </div><!--//tab-pane-->
				</div><!--//tab-content-->
				
				
			    
		    </div><!--//container-fluid-->
	    </div><!--//app-content-->
	    
	   
	    
    </div><!--//app-wrapper-->    					

 
    <!-- Javascript -->          
    <script src="assets/plugins/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>  
    
    
    <!-- Page Specific JS -->
    <script src="assets/js/app.js?v=20260712-7"></script> 
	<script>
    // Set the inactivity timeout duration in milliseconds (e.g., 15 minutes)
const inactivityTimeout =5 * 60 * 1000; // 15 minutes in milliseconds

let logoutTimer;

// Reset the timer on user activity
function resetLogoutTimer() {
    clearTimeout(logoutTimer);
    logoutTimer = setTimeout(logoutUser, inactivityTimeout);
}

// Logout the user when the timeout is reached
function logoutUser() {
    // Perform logout actions here (e.g., clear session data, redirect to logout page)
    window.location.href='logout.php';
    // You can replace the alert with actual logout code.
}

// Initialize the timer when the page loads or after user activity
window.onload = resetLogoutTimer;
document.onmousemove = resetLogoutTimer; // You can add more events like keypress, etc. for user activity

// Optionally, you can also handle clicks on specific elements to reset the timer
// For example, if you have a button that keeps the user logged in
const keepLoggedInButton = document.getElementById('keep-logged-in-button');
keepLoggedInButton.addEventListener('click', resetLogoutTimer);
</script>

</body>
</html> 


