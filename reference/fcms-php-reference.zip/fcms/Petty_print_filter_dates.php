<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once('fpdf_report_helpers.php');
require("connect.php");

$fromdate = htmlspecialchars($_POST['startDate']);
$todate = htmlspecialchars($_POST['endDate']);

$fromdate = date('Y-m-d', strtotime($fromdate));
$todate = date('Y-m-d', strtotime($todate));

$query = "SELECT petty_cash.id, fname, petty_name, trans_date, trans_name, description, amount_in, amount_out, petty_cash.created_at,
                 (SELECT COALESCE(SUM(previous.amount_in), 0) - COALESCE(SUM(previous.amount_out), 0)
                  FROM petty_cash previous
                  WHERE previous.trans_date < petty_cash.trans_date
                     OR (previous.trans_date = petty_cash.trans_date AND previous.id <= petty_cash.id)) AS running_balance
          FROM petty_cash 
          INNER JOIN users ON petty_cash.user_id = users.id 
          INNER JOIN petty_categories ON petty_cash.exp_cat_id = petty_categories.id 
          INNER JOIN trans_category ON petty_cash.trans_id = trans_category.id 
          WHERE petty_cash.trans_date BETWEEN '$fromdate' AND '$todate'
          ORDER BY petty_cash.trans_date DESC, petty_cash.id DESC";
$result1 = mysqli_query($con, $query);

$pdf = new ReportPDF('L', 'mm', 'A4');
$pdf->footerMode = 'printed';
$pdf->SetMargins(10, 10, 10);
$pdf->SetAutoPageBreak(true, 15);
$pdf->AddPage();

$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, 'Petty Cash Report (' . $fromdate . ' to ' . $todate . ')', 0, 1, 'C');
$pdf->Ln(5);

$pdf->SetFont('Arial', '', 10);
date_default_timezone_set('Africa/Dar_es_Salaam');
$pdf->Cell(0, 10, 'Date Printed: ' . date('Y-m-d H:i:s'), 0, 1, 'L');
$pdf->Ln(5);

$header = array('No', 'Recorded by', 'Trans Date', 'Trans Type', 'Category', 'Description', 'Amount In', 'Amount Out', 'Balance');
$widths = array(10, 24, 25, 25, 24, 94, 22, 24, 25);

$pdf->SetFont('Arial', 'B', 9);
$pdf->PrintTableHeader($header, $widths);

$pdf->SetFont('Arial', '', 8);
$pdf->SetWidths($widths);
$pdf->SetAligns(array('C', 'L', 'L', 'L', 'L', 'L', 'R', 'R', 'R'));
$no = 1;
$balance = null;

while ($row = mysqli_fetch_assoc($result1)) {
    if ($balance === null) {
        $balance = $row['running_balance'] ?? 0;
    }
    $pdf->Row(array(
        $no++,
        $row['fname'],
        $row['trans_date'],
        $row['trans_name'],
        $row['petty_name'],
        $row['description'],
        number_format($row['amount_in'] ?? 0, 2),
        number_format($row['amount_out'] ?? 0, 2),
        number_format($row['running_balance'] ?? 0, 2)
    ));
}

$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Total Petty Cash Balance: ' . number_format($balance ?? 0, 2), 0, 1, 'R');

$pdf->Output('petty_cash_report.pdf', 'I');
?>
