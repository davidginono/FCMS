<?php
if (!defined('FPDF_FONTPATH')) define('FPDF_FONTPATH', __DIR__ . '/fpdf/font/');
require_once __DIR__ . '/fpdf/fpdf.php';

if (!function_exists('fcms_format_report_date')) {
    function fcms_format_report_date($date)
    {
        $date = trim((string)$date);
        if ($date === '' || $date === '0000-00-00') {
            return '';
        }

        $timestamp = strtotime($date);
        if ($timestamp === false) {
            return $date;
        }

        return date('Y-m-d', $timestamp);
    }
}

if (!function_exists('fcms_format_report_date_range')) {
    function fcms_format_report_date_range($startDate, $endDate, $emptyLabel = 'All Dates')
    {
        $from = fcms_format_report_date($startDate);
        $to = fcms_format_report_date($endDate);

        if ($from !== '' && $to !== '') {
            return $from . ' to ' . $to;
        }
        if ($from !== '') {
            return 'From ' . $from;
        }
        if ($to !== '') {
            return 'Up to ' . $to;
        }

        return $emptyLabel;
    }
}

if (!function_exists('fcms_build_report_date_range_label')) {
    function fcms_build_report_date_range_label($startDate, $endDate, $emptyLabel = 'All Dates')
    {
        return 'Date Range: ' . fcms_format_report_date_range($startDate, $endDate, $emptyLabel);
    }
}

if (!function_exists('fcms_format_year_date_range')) {
    function fcms_format_year_date_range($year)
    {
        $year = trim((string)$year);
        if (preg_match('/^\d{4}$/', $year)) {
            return fcms_format_report_date_range($year . '-01-01', $year . '-12-31');
        }

        return fcms_format_report_date_range('', '');
    }
}

if (!function_exists('fcms_build_year_date_range_label')) {
    function fcms_build_year_date_range_label($year)
    {
        return 'Date Range: ' . fcms_format_year_date_range($year);
    }
}

trait ReportTableHeaders
{
    function PrintColumnsHeader($columns, $fill = true)
    {
        $left = $this->GetX();
        $available = $this->w - $this->rMargin - $left;
        $scale = min(1, $available / array_sum(array_column($columns, 'width')));
        foreach ($columns as &$column) $column['width'] *= $scale;
        unset($column);
        $family = $this->FontFamily; $style = $this->FontStyle; $size = $this->FontSizePt;
        $headerSize = $size;
        // Keep complete words intact even in dense financial tables.
        do {
            $fits = true;
            $this->SetFont($family, $style, $headerSize);
            foreach ($columns as $column) {
                foreach (preg_split('/\s+/', trim($column['label'])) as $word) {
                    if ($this->GetStringWidth($word) > $column['width'] - 2 * $this->cMargin) $fits = false;
                }
            }
            if (!$fits && $headerSize > 5) $headerSize = max(5, $headerSize - .25);
            else break;
        } while (true);
        $height = 10;
        foreach ($columns as &$column) {
            $lines = array(); $line = '';
            foreach (preg_split('/\s+/', trim($column['label'])) as $word) {
                $candidate = $line === '' ? $word : $line . ' ' . $word;
                if ($line !== '' && $this->GetStringWidth($candidate) > $column['width'] - 2 * $this->cMargin) {
                    $lines[] = $line; $line = $word;
                } else $line = $candidate;
            }
            $lines[] = $line;
            $column['header_text'] = implode("\n", $lines);
            $height = max($height, count($lines) * 3.5 + 2);
        }
        unset($column);
        if ($this->GetY() + $height > $this->PageBreakTrigger) $this->AddPage($this->CurOrientation);
        $top = $this->GetY();
        foreach ($columns as $column) {
            $x = $this->GetX();
            $this->Rect($x, $top, $column['width'], $height, $fill ? 'DF' : 'D');
            $this->SetXY($x, $top + 1);
            $this->MultiCell($column['width'], 3.5, $column['header_text'], 0, 'C');
            $this->SetXY($x + $column['width'], $top);
        }
        $this->SetXY($left, $top + $height);
        $this->SetFont($family, $style, $size);
        return $columns;
    }

    function PrintTableHeader($labels, &$widths, $fill = false)
    {
        $columns = array();
        foreach ($labels as $index => $label) $columns[] = array('label' => $label, 'width' => $widths[$index]);
        $columns = $this->PrintColumnsHeader($columns, $fill);
        $widths = array_column($columns, 'width');
        if (method_exists($this, 'SetWidths')) $this->SetWidths($widths);
    }
}

// Plain exports retain their own (or no) footer while sharing header layout.
class TableReportPDF extends FPDF
{
    use ReportTableHeaders;
}

class ReportPDF extends FPDF
{
    use ReportTableHeaders;
    var $widths;
    var $aligns;
    var $footerMode = 'page';

    function Footer()
    {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        if ($this->footerMode === 'printed') {
            date_default_timezone_set('Africa/Dar_es_Salaam');
            $this->Cell(0, 10, 'Printed on: ' . date('F j, Y \a\t h:i A'), 0, 0, 'L');
            $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'R');
        } else {
            $this->Cell(0, 10, 'Page ' . $this->PageNo(), 0, 0, 'C');
        }
    }

    function SetWidths($w)
    {
        $this->widths = $w;
    }

    function SetAligns($a)
    {
        $this->aligns = $a;
    }

    function Row($data, $lineHeight = 7)
    {
        $nb = 0;
        for ($i = 0; $i < count($data); $i++) {
            $nb = max($nb, $this->NbLines($this->widths[$i], $data[$i]));
        }
        $h = $lineHeight * $nb;
        $this->CheckPageBreak($h);
        for ($i = 0; $i < count($data); $i++) {
            $w = $this->widths[$i];
            $a = isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
            $x = $this->GetX();
            $y = $this->GetY();
            $this->Rect($x, $y, $w, $h);
            $this->MultiCell($w, $lineHeight, $data[$i], 0, $a);
            $this->SetXY($x + $w, $y);
        }
        $this->Ln($h);
    }

    function CheckPageBreak($h)
    {
        if ($this->GetY() + $h > $this->PageBreakTrigger) {
            $this->AddPage($this->CurOrientation);
        }
    }

    function NbLines($w, $txt)
    {
        $cw = &$this->CurrentFont['cw'];
        if ($w == 0) {
            $w = $this->w - $this->rMargin - $this->x;
        }
        $wmax = ($w - 2 * $this->cMargin) * 1000 / $this->FontSize;
        $s = str_replace("\r", '', (string)$txt);
        $nb = strlen($s);
        if ($nb > 0 && $s[$nb - 1] == "\n") {
            $nb--;
        }
        $sep = -1;
        $i = 0;
        $j = 0;
        $l = 0;
        $nl = 1;
        while ($i < $nb) {
            $c = $s[$i];
            if ($c == "\n") {
                $i++;
                $sep = -1;
                $j = $i;
                $l = 0;
                $nl++;
                continue;
            }
            if ($c == ' ') {
                $sep = $i;
            }
            $l += isset($cw[$c]) ? $cw[$c] : 0;
            if ($l > $wmax) {
                if ($sep == -1) {
                    if ($i == $j) {
                        $i++;
                    }
                } else {
                    $i = $sep + 1;
                }
                $sep = -1;
                $j = $i;
                $l = 0;
                $nl++;
            } else {
                $i++;
            }
        }
        return $nl;
    }
}
?>
