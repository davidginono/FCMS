<?php
// Included only by the allowlisted client-delete entry points.
require_once __DIR__ . '/client_lifecycle.php';
$configs = array(
    'SACCOS' => array('saccos', 'Saccos_Name', 'saccos.php', 'delete_saccos.php'),
    'AMCOS' => array('amcos', 'Amcos_name', 'amcos.php', 'delete_amcos.php'),
    'UNION' => array('union', 'Union_Name', 'union.php', 'delete_union.php'),
    'MICROFINANCE' => array('microfinance', 'Microfinance_Name', 'microfinance.php', 'delete_microfinance.php'),
    'OTHER' => array('others_clients', 'Client_Name', 'other_client.php', 'delete_others.php')
);
if (!isset($clientDeleteType, $configs[$clientDeleteType])) { http_response_code(404); exit; }
fcms_client_session();
require __DIR__ . '/connect.php';
$actor = fcms_client_actor($con, true);
$con->set_charset('utf8mb4');
header('Cache-Control: private, no-store');
list($table, $nameField, $listRoute, $deleteRoute) = $configs[$clientDeleteType];
$id = filter_var($_POST['id'] ?? $_GET['id'] ?? '', FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
if (!$id) { http_response_code(400); exit('Select a valid client.'); }
if (!in_array($_SERVER['REQUEST_METHOD'], array('GET', 'POST'), true)) {
    header('Allow: GET, POST'); http_response_code(405); exit;
}

function fcms_client_delete_blocked($con, $table, $id, $row)
{
    // A client register also holds financial history. Never erase those amounts.
    $financial = array('annual_fee','amount','tax','com','programmer_cost','sys_install_fee',
        'training_fee','android_fee','android_cost','sys_reinstall_fee','bulk_sms',
        'hosting_fee','ess','cloud_backup','backup_cost');
    foreach ($row as $field => $value) {
        if (in_array(strtolower($field), $financial, true) && $value !== null &&
            !preg_match('/^-?0*(?:\.0*)?$/D', trim((string)$value))) return true;
    }
    if (!empty($row['pfile']) || (!empty($row['datepaid']) && $row['datepaid'] !== '0000-00-00')) return true;
    // Inspect all declared references, including deployed schema additions.
    $stmt = $con->prepare('SELECT DISTINCT TABLE_NAME, COLUMN_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE REFERENCED_TABLE_SCHEMA=DATABASE() AND REFERENCED_TABLE_NAME=? AND REFERENCED_COLUMN_NAME=\'id\'');
    $stmt->bind_param('s', $table); $stmt->execute();
    $references = $stmt->get_result()->fetch_all(MYSQLI_ASSOC); $stmt->close();
    foreach ($references as $reference) {
        $related = $reference['TABLE_NAME']; $column = $reference['COLUMN_NAME'];
        if (!preg_match('/^[A-Za-z0-9_]+$/D', $related) || !preg_match('/^[A-Za-z0-9_]+$/D', $column)) {
            throw new RuntimeException('Unsupported reference identifier.');
        }
        $stmt = $con->prepare("SELECT 1 FROM `$related` WHERE `$column`=? LIMIT 1");
        $stmt->bind_param('i', $id); $stmt->execute();
        $found = $stmt->get_result()->num_rows > 0; $stmt->close();
        if ($found) return true;
    }
    return false;
}

$transaction = false;
try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        fcms_client_verify_csrf();
        $con->begin_transaction(); $transaction = true;
    }
    $stmt = $con->prepare("SELECT * FROM `$table` WHERE id=?" . ($transaction ? ' FOR UPDATE' : ''));
    $stmt->bind_param('i', $id); $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$row) { if ($transaction) $con->rollback(); http_response_code(404); exit('Client not found.'); }
    $version = hash('sha256', json_encode($row, JSON_THROW_ON_ERROR));
    $year = max(0, (int)($row['fyear_id'] ?? 0));
    $returnRoute = $listRoute . ($year ? '?fyear_id=' . $year : '');
    $blocked = fcms_client_delete_blocked($con, $table, $id, $row);
    $canDeactivate = $clientDeleteType !== 'OTHER' && isset($row['status']) && $row['status'] !== 'INACTIVE';
    $message = $blocked ? 'This client has linked records or financial history and cannot be deleted. These records must be preserved.' :
        'Delete this unused client? This action cannot be undone.';
    if ($transaction) {
        $postedVersion = $_POST['version'] ?? '';
        if (!is_string($postedVersion) || !hash_equals($version, $postedVersion)) {
            throw new InvalidArgumentException('The client changed. Reopen the confirmation and try again.');
        }
        $action = $_POST['action'] ?? '';
        if ($action === 'deactivate' && $canDeactivate) {
            $stmt = $con->prepare("UPDATE `$table` SET status='INACTIVE' WHERE id=?");
            $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close();
            fcms_client_audit($con, $actor, 'client.status.update', $clientDeleteType, $id, $row['status'], 'INACTIVE');
            $notice = 'Client marked inactive. Linked records and financial history were preserved.';
        } elseif ($action === 'delete' && !$blocked) {
            $stmt = $con->prepare("DELETE FROM `$table` WHERE id=?");
            $stmt->bind_param('i', $id); $stmt->execute(); $stmt->close();
            fcms_client_audit($con, $actor, 'client.delete', $clientDeleteType, $id, $row['status'] ?? '', 'DELETED');
            $notice = 'Unused client deleted.';
        } else {
            throw new InvalidArgumentException($message);
        }
        $con->commit(); $transaction = false;
        $_SESSION['client_delete_notice'] = $notice;
        header('Location: ' . $returnRoute, true, 303); exit;
    }
    $data = array('name' => $row[$nameField] ?? $row['Amcos_Name'] ?? 'Client', 'id' => $id,
        'csrf' => fcms_client_csrf(), 'version' => $version, 'actionUrl' => $deleteRoute,
        'returnUrl' => $returnRoute, 'blocked' => $blocked, 'canDeactivate' => $canDeactivate, 'message' => $message);
    if (($_GET['format'] ?? '') === 'json') {
        header('Content-Type: application/json; charset=utf-8'); echo json_encode($data, JSON_THROW_ON_ERROR); exit;
    }
} catch (InvalidArgumentException $error) {
    if ($transaction) $con->rollback();
    http_response_code(409); exit(fcms_client_escape($error->getMessage()));
} catch (Throwable $error) {
    if ($transaction) $con->rollback();
    if ($error instanceof mysqli_sql_exception && (int)$error->getCode() === 1451) {
        http_response_code(409); exit('This client has linked records. Mark the client inactive instead.');
    }
    error_log('FCMS client delete failed; type=' . $clientDeleteType . '; id=' . (int)$id . '; error=' . get_class($error));
    http_response_code(503); exit('Unable to process the client action. Please contact the administrator.');
}
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>FCMS | Confirm client action</title>
<link rel="stylesheet" href="assets/css/portal.css?v=20260712-7">
<link rel="stylesheet" href="assets/css/table-actions.css?v=20261105-1">
<script defer src="assets/plugins/fontawesome/js/all.min.js"></script>
</head><body class="app">
<?php require __DIR__ . '/admin_navigation.php'; ?>
<main class="app-wrapper"><section class="app-card p-4 m-4 fcms-confirm-card" role="dialog" aria-labelledby="delete-heading">
<h1 id="delete-heading" class="h4">Confirm client action</h1>
<p><?php echo fcms_client_escape($data['name']); ?></p>
<p><?php echo fcms_client_escape($message); ?></p>
<form method="post" action="<?php echo $deleteRoute; ?>">
<?php foreach (array('id' => $id, 'csrf' => $data['csrf'], 'version' => $version) as $key => $value): ?>
<input type="hidden" name="<?php echo $key; ?>" value="<?php echo fcms_client_escape($value); ?>">
<?php endforeach; ?>
<div class="fcms-confirm-actions">
<a class="btn app-btn-secondary" href="<?php echo fcms_client_escape($returnRoute); ?>">Cancel</a>
<?php if ($canDeactivate): ?><button class="btn app-btn-primary" type="submit" name="action" value="deactivate">Mark inactive</button><?php endif; ?>
<?php if (!$blocked): ?><button class="btn btn-danger" type="submit" name="action" value="delete">Delete client</button><?php endif; ?>
</div></form></section></main>
<script src="assets/plugins/popper.min.js"></script><script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script><script src="assets/js/app.js?v=20260712-7"></script>
</body></html>
