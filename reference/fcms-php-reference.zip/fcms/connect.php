<?php
// Database connection parameters
$host = (getenv('FCMS_REFERENCE_HOST') ?: '');
$username = (getenv('FCMS_REFERENCE_USERNAME') ?: '');
$password = "";
$database = "fcms_db-35303539ac53";

// Establish connection
$con = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$con) {
    die("Database connection failed: " . mysqli_connect_error());
}

$currentFinancialYear = date('Y');
$financialYearExists = mysqli_prepare($con, "SELECT id FROM financial_year WHERE fyear = ? LIMIT 1");
if ($financialYearExists) {
    mysqli_stmt_bind_param($financialYearExists, "s", $currentFinancialYear);
    mysqli_stmt_execute($financialYearExists);
    mysqli_stmt_store_result($financialYearExists);
    $currentFinancialYearExists = mysqli_stmt_num_rows($financialYearExists) > 0;
    mysqli_stmt_close($financialYearExists);

    if (!$currentFinancialYearExists) {
        $ensureFinancialYear = mysqli_prepare($con, "INSERT INTO financial_year (fyear) VALUES (?)");
        if ($ensureFinancialYear) {
            mysqli_stmt_bind_param($ensureFinancialYear, "s", $currentFinancialYear);
            try {
                mysqli_stmt_execute($ensureFinancialYear);
            } catch (mysqli_sql_exception $exception) {
                error_log("Unable to ensure the current financial year: " . $exception->getMessage());
            }
            mysqli_stmt_close($ensureFinancialYear);
        }
    }
}
?>
