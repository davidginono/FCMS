<?php
// Shared layout for prospect, invoice and client registration forms.
function fcms_client_workspace_styles()
{
    ?>
    <style>
    body.app.prospect-workspace { min-width: 0; }
    .prospect-main { width: 100%; max-width: 1440px; margin: 0 auto; padding-inline: clamp(.75rem, 2.5vw, 2rem); }
    .prospect-toolbar, .prospect-fields, .invoice-item, .invoice-total {
        display: flex; flex-flow: row wrap; gap: .75rem;
    }
    .prospect-fields { gap: 1rem; align-items: end; }
    .prospect-fields > .col-md-4 { width: auto; flex: 0 0 calc((100% - 2rem) / 3); min-width: 0; }
    .prospect-fields > .col-12 { flex: 0 0 100%; min-width: 0; }
    :is(.prospect-workspace, .client-register-form) fieldset { min-width: 0; }
    :is(.prospect-workspace, .client-register-form) legend { float: none; }
    :is(.prospect-workspace, .client-register-form) :is(.form-control, .form-select) { min-width: 0; width: 100%; }
    :is(.prospect-workspace, .client-register-form) :is(input.form-control, .form-select), .prospect-toolbar .btn { height: 2.75rem; }
    .prospect-workspace textarea { height: auto; }
    .prospect-toolbar { align-items: end; }
    .prospect-toolbar label { flex: 1 1 12rem; min-width: 0; margin: 0; }
    .prospect-toolbar .btn { display: inline-flex; align-items: center; justify-content: center; flex: 0 0 auto; }
    .prospect-workspace .table-responsive { max-width: 100%; overflow-x: auto; }
    .prospect-workspace th, .prospect-workspace td { min-width: 7rem; overflow-wrap: anywhere; }
    .prospect-workspace :focus-visible { outline: 3px solid #2858d9; outline-offset: 3px; }
    .invoice-item { align-items: end; padding: 1rem; border: 1px solid #dee4ee; border-radius: .75rem; margin-top: .75rem; }
    .invoice-item label { display: flex; flex-direction: column; gap: .35rem; min-width: 0; margin: 0; font-weight: 600; color: #526078; }
    .invoice-item-description { flex: 1 1 18rem; }
    .invoice-item-amount { flex: 0 1 10rem; }
    .invoice-item textarea.form-control { height: 2.75rem; min-height: 2.75rem; resize: vertical; }
    .invoice-item .btn { flex: 0 0 auto; height: 2.75rem; }
    .invoice-total { justify-content: flex-end; align-items: center; padding: 1rem; background: #eff4ff; border-radius: .75rem; font-weight: 700; }
    .invoice-total output { overflow-wrap: anywhere; }
    @media (max-width: 991px) {
        .prospect-fields > .col-md-4 { flex-basis: calc((100% - 1rem) / 2); }
    }
    @media (max-width: 575px) {
        .prospect-fields > .col-md-4, .invoice-item-description { flex-basis: 100%; }
        .invoice-item-amount { flex: 1 1 7rem; }
    }
    </style>
    <?php
}
