<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Configure session directory and start session
$sessionDirectory = '/home/sites/37b/1/15b6335fc9/fcms/sessions';
ini_set('session.save_path', $sessionDirectory);
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    // Redirect to login if not logged in
    echo "<script>window.location.href='index.php';</script>";
    exit();
}
if (!isset($_SESSION['role_id']) || $_SESSION['role_id'] != '1') {
    header("location:user_dashboard.php");
    exit();
}

require('connect.php');

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
    header('location: users.php');
    exit();
}

$id=filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if(!$id)
{
    header('location: users.php');
    exit();
}

if($_SESSION['id'] == $id)
{
    $_SESSION['del'] = "You cannot delete yourself" ;
    header('location: users.php');

}else
{
$query= "DELETE FROM users where id = ?";
$stmt=mysqli_prepare($con,$query);
mysqli_stmt_bind_param($stmt,"i",$id);
$result=mysqli_stmt_execute($stmt);

if($result)
{
    header("location:users.php");
}else{
    echo "Failed to delete";
}
}
?>
