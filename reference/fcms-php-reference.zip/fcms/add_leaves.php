<?php
require_once __DIR__ . '/auth_workspace.php';
fcms_client_session();
require __DIR__ . '/connect.php';
$workspaceActor = fcms_require_workspace($con, null);



$user_id = $workspaceActor;

if ($user_id <= 0) {
    session_unset();
    session_destroy();
    echo "<script>window.location.href='index.php';</script>";
    exit();
}

$query="SELECT * FROM `users` WHERE `id`='$user_id'";
$result=mysqli_query($con,$query);
$row=mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en"> 
<head>
    <title>FCPS | Leaves</title>
    

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="description" content="Portal - Bootstrap 5 Admin Dashboard Template For Developers">
    <meta name="author" content="Xiaoying Riley at 3rd Wave Media">    
  
    

    <script defer src="assets/plugins/fontawesome/js/all.min.js"></script>
     <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    

    <link id="theme-style" rel="stylesheet" href="assets/css/portal.css?v=20260712-7">

</head> 

<body class="app">   	
    <?php require __DIR__ . ((int)$_SESSION['role_id'] === 1 ? '/admin_navigation.php' : '/user_navigation.php'); ?>
    
    <div class="app-wrapper" >
	    
	    <div class="app-content pt-3 p-md-3 p-lg-4" style="margin-top:10px";>
		    <div class="container-xl">
			    
			    <div class="row g-3 mb-4 align-items-center justify-content-between">
				    <div class="col-auto">
			            <!-- <h1 class="app-page-title mb-0">Add User </Details></h1> -->
				    </div>
				    <div class="col-auto">
					     <div class="page-utilities">
						    <div class="row g-2 justify-content-start justify-content-md-end align-items-center">
							    <div class="col-auto">
								    <form class="table-search-form row gx-1 align-items-center">
					                  
					                    
					                </form>
									
					                
							    </div>
							  
							  
						    </div>
					    </div>
				    </div>
			    </div>
			    
			   

<?php
// Include database connection (replace with your connection details)
include('connect.php');

if (isset($_POST['add'])) {
    $subject = $_POST['subject'];
    $reason = $_POST['reason'];


    // Validate input
    if (empty($subject) || empty($reason)) {
        echo '<center><div class="alert alert-danger" role="alert">Please fill all fields.</div></center>';
    } else {
        // Fetch user email and first name based on user_id
        $user_stmt = mysqli_prepare($con, "SELECT fname, leave_email FROM users WHERE id = ?");
        mysqli_stmt_bind_param($user_stmt, "i", $user_id);
        mysqli_stmt_execute($user_stmt);
        mysqli_stmt_bind_result($user_stmt, $fname, $user_email);
        mysqli_stmt_fetch($user_stmt);
        mysqli_stmt_close($user_stmt);

        // Use prepared statements to prevent SQL injection
        $stmt = mysqli_prepare($con, "INSERT INTO `staff_leaves` (`user_id`, `subject`, `reason`) VALUES (?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "iss", $user_id, $subject, $reason);

        if (mysqli_stmt_execute($stmt)) {
            // Send email after successful insertion
            $to = "simeonmitiambo@gmail.com"; // Replace with HR email address
            $email_subject = "Leave Application: " . $subject . "\nStaff Name: " . $fname; // Use first name in the subject
            $message = "Subject: " . $email_subject . "\n\nReason: " . $reason. "\n\nAfter reply, don't forget to log in to the system to update leave status https://fcms.foresight.co.tz/leaves.php"; // Use the fetched user email

            // Set the "From" header to the user's email
            $headers = "From: " . $user_email;

            if (mail($to, $email_subject, $message, $headers)) {
                echo '<center><div class="alert alert-success" role="alert">Leave application submitted successfully and email sent to Director.</div></center>';
            } else {
                echo '<center><div class="alert alert-danger" role="alert">Error sending email.</div></center>';
            }
        } else {
            echo '<center><div class="alert alert-danger" role="alert">Error adding leave: ' . mysqli_error($con) . '</div></center>';
        }

        mysqli_stmt_close($stmt);
    }
}
?>







<div class="container mt-0">
    
     <button class="btn btn-secondary" onclick="goBack()">Back</button>

<script>
function goBack() {
    window.history.back();
}
</script>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<br><br>
      <div class="row">
         <div class="col-md-12">
         <div class="card">
              <div class="card-header bg-blue text-white">
                  <div class="card-header-title text-center" style="color:black;"> Apply Leaves</div>
              </div>
              
              
              <form name="createForm " id="createForm" action="" method="post">
              <div class="card-body">







              

                                           
                                                <br>
                                                <div class="form-group">
                                                <label>Subject</label>
                                                    <input class="form-control" name="subject" type="text" placeholder="Subject">
                                                </div>


                                                
                                       <br>

<div class="form-group">
    <label>Reasons / Descriptions</label>
    <textarea class="form-control" name="reason" rows="4" placeholder="Enter details here..."></textarea>
</div>

                                            
                                                <br>
                    

                                        
                                                <button type="submit" name="add" class="btn btn-mdm btn-success">Apply</button>
</form>
         </div>
          </div>
      </div>
  </div>
				
			
	    </div>
	    
	   
	    
    </div>					

 
       
    <script src="assets/plugins/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>  
    

    <script src="assets/js/app.js?v=20261116-1"></script> 
	<script>
    // Set the inactivity timeout duration in milliseconds (e.g., 15 minutes)
const inactivityTimeout =5 * 60 * 1000; // 15 minutes in milliseconds

let logoutTimer;

// Reset the timer on user activity
function resetLogoutTimer() {
    clearTimeout(logoutTimer);
    logoutTimer = setTimeout(logoutUser, inactivityTimeout);
}

// Logout the user when the timeout is reached
function logoutUser() {
    // Perform logout actions here (e.g., clear session data, redirect to logout page)
    window.location.href='logout.php';
    // You can replace the alert with actual logout code.
}

// Initialize the timer when the page loads or after user activity
window.onload = resetLogoutTimer;
document.onmousemove = resetLogoutTimer; // You can add more events like keypress, etc. for user activity

// Optionally, you can also handle clicks on specific elements to reset the timer
// For example, if you have a button that keeps the user logged in
const keepLoggedInButton = document.getElementById('keep-logged-in-button');
if (keepLoggedInButton) keepLoggedInButton.addEventListener('click', resetLogoutTimer);
</script>

</body>
</html> 

