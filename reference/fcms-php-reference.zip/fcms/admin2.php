<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);
// Start the session and set custom session directory
$sessionDirectory = '/home/sites/37b/1/15b6335fc9/fcms/sessions';
ini_set('session.save_path', $sessionDirectory);
session_start();

// Check if the user is logged in
if (!isset($_SESSION['email'])) {
    // If not logged in, redirect to the login page
echo "<script>window.location.href='index.php';</script>";
    exit();
}

require('connect.php');

function fetchScalarValue($con, $sql, $default = 0.0) {
    $result = $con->query($sql);
    if (!$result) {
        return $default;
    }

    $row = $result->fetch_row();
    return isset($row[0]) ? (float)$row[0] : $default;
}

function formatDashboardAmount($amount, $decimals = 0) {
    return number_format((float)$amount, $decimals);
}

$dashboardYearId = 0;
$dashboardYear = (int)date('Y');
$dashboardYearResult = mysqli_query($con, "SELECT id, fyear FROM financial_year ORDER BY fyear DESC LIMIT 1");
if ($dashboardYearResult && $dashboardYearRow = mysqli_fetch_assoc($dashboardYearResult)) {
    $dashboardYearId = (int)$dashboardYearRow['id'];
    $dashboardYear = (int)$dashboardYearRow['fyear'];
}

$dashboardAmcosAnnualAmount = fetchScalarValue(
    $con,
    "SELECT COALESCE(SUM(CAST(Annual_fee AS DECIMAL(15,2))), 0) FROM amcos WHERE fyear_id = $dashboardYearId"
);

$dashboardAmcosPaidAmount = fetchScalarValue(
    $con,
    "SELECT COALESCE(SUM(CAST(Amount AS DECIMAL(15,2))), 0) FROM amcos WHERE fyear_id = $dashboardYearId"
);

$dashboardAmcosUnpaidAmount = fetchScalarValue(
    $con,
    "SELECT COALESCE(SUM(CAST(Annual_fee AS DECIMAL(15,2)) - CAST(Amount AS DECIMAL(15,2))), 0) FROM amcos WHERE fyear_id = $dashboardYearId"
);

$dashboardAmcosTrainingFee = fetchScalarValue(
    $con,
    "SELECT COALESCE(SUM(CAST(Training_fee AS DECIMAL(15,2))), 0) FROM amcos WHERE fyear_id = $dashboardYearId"
);

$dashboardAmcosSystemInstallFee = fetchScalarValue(
    $con,
    "SELECT COALESCE(SUM(CAST(Sys_install_fee AS DECIMAL(15,2))), 0) FROM amcos WHERE fyear_id = $dashboardYearId"
);

$dashboardAmcosAndroidFee = fetchScalarValue(
    $con,
    "SELECT COALESCE(SUM(CAST(Android_fee AS DECIMAL(15,2))), 0) FROM amcos WHERE fyear_id = $dashboardYearId"
);

$dashboardAmcosSystemReinstallFee = fetchScalarValue(
    $con,
    "SELECT COALESCE(SUM(CAST(Sys_reinstall_fee AS DECIMAL(15,2))), 0) FROM amcos WHERE fyear_id = $dashboardYearId"
);

$dashboardAmcosHostingFee = fetchScalarValue(
    $con,
    "SELECT COALESCE(SUM(CAST(hosting_fee AS DECIMAL(15,2))), 0) FROM amcos WHERE fyear_id = $dashboardYearId"
);

$dashboardAmcosBulkSmsFee = fetchScalarValue(
    $con,
    "SELECT COALESCE(SUM(CAST(bulk_sms AS DECIMAL(15,2))), 0) FROM amcos WHERE fyear_id = $dashboardYearId"
);

$dashboardAmcosOfficeExpenses = fetchScalarValue(
    $con,
    "SELECT COALESCE(SUM(amount), 0) FROM expenses WHERE fyear = $dashboardYear"
);

$dashboardAmcosOtherIncome = fetchScalarValue(
    $con,
    "SELECT COALESCE(SUM(amount), 0) FROM income"
);
?>

<!DOCTYPE html>
<html lang="en"> 
<head>
    <title>FCMS | Admin</title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <meta name="description" content="Portal - Bootstrap 5 Admin Dashboard Template For Developers">
    <meta name="author" content="Xiaoying Riley at 3rd Wave Media">    

    
    <!-- FontAwesome JS-->
    <script defer src="assets/plugins/fontawesome/js/all.min.js"></script>
    
    <!-- App CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/portal.css?v=20260712-7">
    <style>
        .dashboard-cards-grid .app-card-stat {
            position: relative;
            overflow: hidden;
            border: 1px solid rgba(80, 110, 200, 0.08);
            cursor: pointer;
            transition: transform 0.28s ease, box-shadow 0.28s ease, border-color 0.28s ease;
        }

        .dashboard-cards-grid .app-card-stat::before {
            content: "";
            position: absolute;
            inset: 0;
            background: radial-gradient(circle at top right, rgba(84, 114, 226, 0.12), transparent 55%),
                        radial-gradient(circle at bottom left, rgba(42, 199, 169, 0.10), transparent 50%);
            opacity: 0;
            transition: opacity 0.28s ease;
            pointer-events: none;
        }

        .dashboard-cards-grid .app-card-stat:hover {
            transform: translateY(-8px);
            box-shadow: 0 18px 36px rgba(57, 76, 148, 0.16) !important;
            border-color: rgba(84, 114, 226, 0.24);
        }

        .dashboard-cards-grid .app-card-stat:hover::before {
            opacity: 1;
        }

        .dashboard-cards-grid .app-card-stat .app-card-body {
            position: relative;
            z-index: 1;
         pointer-events: none;

        }

        .dashboard-cards-grid .app-card-stat .app-card-link-mask {
            cursor: pointer;
        z-index: 2;

        }

        .dashboard-cards-grid .app-card-stat .stats-type,
        .dashboard-cards-grid .app-card-stat .stats-figure {
            transition: transform 0.28s ease, color 0.28s ease;
        }

        .dashboard-cards-grid .app-card-stat:hover .stats-type {
            transform: translateY(-2px);
            color: #20356f !important;
        }

        .dashboard-cards-grid .app-card-stat:hover .stats-figure {
            transform: scale(1.04);
            color: #16264d;
        }
    </style>

</head> 

<body class="app">   	
    <header class="app-header fixed-top">	   	            
        <div class="app-header-inner">  
	        <div class="container-fluid py-2">
		        <div class="app-header-content"> 
		            <div class="row justify-content-between align-items-center">
		                
		                				    <div class="col-auto">
					    <a id="sidepanel-toggler" class="sidepanel-toggler d-inline-block d-xl-none" href="#">
						    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 30 30" role="img"><title>Menu</title><path stroke="currentColor" stroke-linecap="round" stroke-miterlimit="10" stroke-width="2" d="M4 7h22M4 15h22M4 23h22"></path></svg>
					    </a>
				    </div>
			        

		            
		            <div class="app-utilities col-auto">
			            <div class="app-utility-item app-notifications-dropdown dropdown">    
				            <a class="dropdown-toggle no-toggle-arrow" id="notifications-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false" title="Notifications">
					            <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					            
					            
					        </a><!--//dropdown-toggle-->
					        
					        			        
				        </div><!--//app-utility-item-->
			          
						<div class="app-utility-item app-user-dropdown dropdown">
				            <a class="dropdown-toggle" id="user-dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-expanded="false"><span class="navbar-profile-icon"><i class="fa-solid fa-user"></i></span></a><ul class="dropdown-menu" aria-labelledby="user-dropdown-toggle">
								<li><a class="dropdown-item" href="account.php">Account</a></li>
								<li><a class="dropdown-item" href="change_password.php">Change Password</a></li>
								<li><a class="dropdown-item" href="change_profile.php">Change Profile Picture</a></li>
								<li><hr class="dropdown-divider"></li>
								<li><a class="dropdown-item" href="logout.php">Log Out</a></li>
							</ul>
			            </div><!--//app-user-dropdown--> 
		            </div><!--//app-utilities-->
		        </div><!--//row-->
	            </div><!--//app-header-content-->
	        </div><!--//container-fluid-->
        </div><!--//app-header-inner-->
        <div id="app-sidepanel" class="app-sidepanel"> 
	        <div id="sidepanel-drop" class="sidepanel-drop"></div>
	        <div class="sidepanel-inner d-flex flex-column">
		        <a href="#" id="sidepanel-close" class="sidepanel-close d-xl-none">&times;</a>
		        <div class="app-branding">
		            <a class="app-logo" href="admin.php"><img class="logo-icon me-2" src="assets/images/app-logo.png" alt="logo"><span class="logo-text">FCMS</span></a>
	
		        </div><!--//app-branding-->  
		        
			    <nav id="app-nav-main" class="app-nav app-nav-main flex-grow-1">
				    <ul class="app-menu list-unstyled accordion" id="menu-accordion">
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link active" href="admin.php">
						        <span class="nav-icon">
						        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-house-door" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
		  <path fill-rule="evenodd" d="M7.646 1.146a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 .146.354v7a.5.5 0 0 1-.5.5H9.5a.5.5 0 0 1-.5-.5v-4H7v4a.5.5 0 0 1-.5.5H2a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .146-.354l6-6zM2.5 7.707V14H6v-4a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4h3.5V7.707L8 2.207l-5.5 5.5z"/>
		  <path fill-rule="evenodd" d="M13 2.5V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z"/>
		</svg>
						         </span>
		                         <span class="nav-link-text">Dashboard</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="admin2.php">
						        <span class="nav-icon">
						        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-speedometer2" viewBox="0 0 16 16">
  <path d="M8 4a.5.5 0 0 1 .5.5V6a.5.5 0 0 1-1 0V4.5A.5.5 0 0 1 8 4M3.732 5.732a.5.5 0 0 1 .707 0l.915.914a.5.5 0 1 1-.708.708l-.914-.915a.5.5 0 0 1 0-.707M2 10a.5.5 0 0 1 .5-.5h1.586a.5.5 0 0 1 0 1H2.5A.5.5 0 0 1 2 10m9.5 0a.5.5 0 0 1 .5-.5h1.5a.5.5 0 0 1 0 1H12a.5.5 0 0 1-.5-.5m.754-4.246a.39.39 0 0 0-.527-.02L7.547 9.31a.91.91 0 1 0 1.302 1.258l3.434-4.297a.39.39 0 0 0-.029-.518z"/>
  <path fill-rule="evenodd" d="M0 10a8 8 0 1 1 15.547 2.661c-.442 1.253-1.845 1.602-2.932 1.25C11.309 13.488 9.475 13 8 13c-1.474 0-3.31.488-4.615.911-1.087.352-2.49.003-2.932-1.25A8 8 0 0 1 0 10m8-7a7 7 0 0 0-6.603 9.329c.203.575.923.876 1.68.63C4.397 12.533 6.358 12 8 12s3.604.532 4.923.96c.757.245 1.477-.056 1.68-.631A7 7 0 0 0 8 3"/>
</svg>
						         </span>
		                         <span class="nav-link-text">Amcos Dashboard</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="admin3.php">
						        <span class="nav-icon">
						        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-speedometer2" viewBox="0 0 16 16">
  <path d="M8 4a.5.5 0 0 1 .5.5V6a.5.5 0 0 1-1 0V4.5A.5.5 0 0 1 8 4M3.732 5.732a.5.5 0 0 1 .707 0l.915.914a.5.5 0 1 1-.708.708l-.914-.915a.5.5 0 0 1 0-.707M2 10a.5.5 0 0 1 .5-.5h1.586a.5.5 0 0 1 0 1H2.5A.5.5 0 0 1 2 10m9.5 0a.5.5 0 0 1 .5-.5h1.5a.5.5 0 0 1 0 1H12a.5.5 0 0 1-.5-.5m.754-4.246a.39.39 0 0 0-.527-.02L7.547 9.31a.91.91 0 1 0 1.302 1.258l3.434-4.297a.39.39 0 0 0-.029-.518z"/>
  <path fill-rule="evenodd" d="M0 10a8 8 0 1 1 15.547 2.661c-.442 1.253-1.845 1.602-2.932 1.25C11.309 13.488 9.475 13 8 13c-1.474 0-3.31.488-4.615.911-1.087.352-2.49.003-2.932-1.25A8 8 0 0 1 0 10m8-7a7 7 0 0 0-6.603 9.329c.203.575.923.876 1.68.63C4.397 12.533 6.358 12 8 12s3.604.532 4.923.96c.757.245 1.477-.056 1.68-.631A7 7 0 0 0 8 3"/>
</svg>
						         </span>
		                         <span class="nav-link-text">Union Dashboard</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
	

						<li class="nav-item has-submenu">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-2" aria-expanded="false" aria-controls="submenu-2">
						        <span class="nav-icon">
								<i class="fas fa-fw fa-building"></i>
						        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
						        
						         </span>
		                         <span class="nav-link-text">Clients</span>
		                         <span class="submenu-arrow">
		                             <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
	</svg>
	                             </span><!--//submenu-arrow-->
					        </a><!--//nav-link-->
					        <div id="submenu-2" class="collapse submenu submenu-2" data-bs-parent="#menu-accordion">
						        <ul class="submenu-list list-unstyled">
								    <?php require __DIR__ . '/admin_client_menu.php'; ?>

						        </ul>
					        </div>
					    </li><!--//nav-item-->

			<div>

			
			</div>
						
					
					
					    <li class="nav-item has-submenu">

					      
					        <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-1" aria-expanded="false" aria-controls="submenu-1">
						        <span class="nav-icon">
						        <i class="fas fa-fw fa-users"></i>
						         </span>
		                         <span class="nav-link-text">Users</span>
		                         <span class="submenu-arrow">
		                             <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
	</svg>
	                             </span>
					        </a>
					        <div id="submenu-1" class="collapse submenu submenu-1" data-bs-parent="#menu-accordion">
						        <ul class="submenu-list list-unstyled">
								    <li class="submenu-item"><a class="submenu-link" href="add_user.php"> Add New Users</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="users.php">All Users</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="active_users.php">Active Users</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="inactive_users.php">Inactive Users</a></li>
					
						        </ul>
					        </div>
					    </li>


					
						

						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="all_task.php">
						        <span class="nav-icon">
								<i class="fas fa-fw fa-tasks"></i>
						         </span>
		                         <span class="nav-link-text">Tasks</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					     <li class="nav-item has-submenu">

					      
					        <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-3" aria-expanded="false" aria-controls="submenu-3">
						        <span class="nav-icon">
						        <i class="fas fa-fw fa-file"></i>
						         </span>
		                         <span class="nav-link-text">Reports</span>
		                         <span class="submenu-arrow">
		                             <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
	  <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
	</svg>
	                             </span>
					        </a>
					        <div id="submenu-3" class="collapse submenu submenu-3" data-bs-parent="#menu-accordion">
						        <ul class="submenu-list list-unstyled">

								    <li class="submenu-item"><a class="submenu-link" href="report.php"> Saccos Report</a></li>
                                    <li class="submenu-item"><a class="submenu-link" href="union_report.php"> Union Report</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="microfinance_report.php">Microfinance Report</a></li>
							        <li class="submenu-item"><a class="submenu-link" href="other_report.php">Other Client Report</a></li>
							        						            <li class="submenu-item"><a class="submenu-link" href="staff_report.php"> Staff Report</a></li>
							             <li class="submenu-item"><a class="submenu-link" href="income_statement.php">Income Statement</a></li>
					
						        </ul>
					        </div>
					    </li>
					

						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="leaves.php">
						        <span class="nav-icon">
								<i class="fas fa-fw fa-file-pdf"></i>
						         </span>
		                         <span class="nav-link-text">Staff Leaves</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->

						
					    
					    						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="expenses.php">
						        <span class="nav-icon">
						            <i class="fa-solid fa-sack-xmark"></i>
	
						         </span>
		                         <span class="nav-link-text">Expenses</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    						<li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="income.php">
						        <span class="nav-icon">
				<i class="fa-solid fa-sack-dollar"></i>
						         </span>
		                         <span class="nav-link-text">Other Income</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					    <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="petty_cash.php">
						        <span class="nav-icon">
				<i class="fa-solid fa-sack-dollar"></i>
						         </span>
		                         <span class="nav-link-text">Petty Cash</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
					     
   <li class="nav-item">
					        <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					        <a class="nav-link" href="cloud_backup.php">
						        <span class="nav-icon">
				<i class="fa-solid fa-sack-dollar"></i>
						         </span>
		                         <span class="nav-link-text">Cloud Backup</span>
					        </a><!--//nav-link-->
					    </li><!--//nav-item-->
					    
<li class="nav-item">
    <!-- Font Awesome icon -->
    <a class="nav-link" href="backup.php">
        <span class="nav-icon">
            <i class="fas fa-hdd"></i> <!-- Hard drive icon -->
        </span>
        <span class="nav-link-text">System Backup</span>
    </a>
</li>





						
    
					
						
					 

					   
					    
					    
										    
				    </ul><!--//app-menu-->

					
			    </nav><!--//app-nav-->
			    <div class="app-sidepanel-footer">
				    <div class="sidepanel-company">
					    <img class="sidepanel-company-logo" src="assets/images/app-logo.png" alt="Computer Recources ltd">
					    <span class="sidepanel-company-text">Computer Recources ltd</span>
				    </div>
			    </div><!--//app-sidepanel-footer-->
		       
	        </div><!--//sidepanel-inner-->
	    </div><!--//app-sidepanel-->
    </header><!--//app-header-->
    
    <div class="app-wrapper">
	    
	    <div class="app-content pt-3 p-md-3 p-lg-4">
		    <div class="container-xl">
			    
			    <!-- <h1 class="app-page-title">Overview</h1> -->
			    
			 
				<?php
    $users="SELECT * FROM amcos WHERE fyear_id=$dashboardYearId";
    $userresult=mysqli_query($con,$users);
    $userrow=mysqli_num_rows($userresult);

    $activeuser="SELECT * FROM amcos WHERE saccos_status_id='1'AND fyear_id=$dashboardYearId";
    $auserresult=mysqli_query($con,$activeuser);
    $activerow=mysqli_num_rows($auserresult);

	$activeuser="SELECT * FROM amcos WHERE saccos_status_id='2' AND fyear_id=$dashboardYearId";
    $auserresult=mysqli_query($con,$activeuser);
    $inactiverow=mysqli_num_rows($auserresult);





    ?>
	


				    
			    <div class="row g-4 mb-4 dashboard-cards-grid">
				    <div class="col-6 col-lg-4">
					    <div class="app-card app-card-stat shadow-sm h-100">
						    <div class="app-card-body p-3 p-lg-4">
							    <h4 class="stats-type mb-1">ALL AMCOS</h4>
							    <div class="stats-figure"><?php echo $userrow?></div>
							    
						    </div><!--//app-card-body-->
						    <a class="app-card-link-mask" href="amcos.php"></a>
					    </div><!--//app-card-->
				    </div><!--//col-->
				    
				    <div class="col-6 col-lg-4">
					    <div class="app-card app-card-stat shadow-sm h-100">
						    <div class="app-card-body p-3 p-lg-4">
							    <h4 class="stats-type mb-1" style="color:green;">PAID AMCOS</h4>
							    <div class="stats-figure"><?php echo $activerow?></div>
							    
						    </div><!--//app-card-body-->
						    <a class="app-card-link-mask" href="amcos.php"></a>
					    </div><!--//app-card-->
				    </div><!--//col-->
				    <div class="col-6 col-lg-4">
					    <div class="app-card app-card-stat shadow-sm h-100">
						    <div class="app-card-body p-3 p-lg-4">
							    <h4 class="stats-type mb-1" style="color:red;">UNPAID AMCOS</h4>
							    <div class="stats-figure"><?php echo $inactiverow?></div>
							    
						    </div><!--//app-card-body-->
						    <a class="app-card-link-mask" href="amcos.php"></a>
					    </div><!--//app-card-->
				    </div><!--//col-->




					<div class="col-6 col-lg-4">
					    <div class="app-card app-card-stat shadow-sm h-100">
						    <div class="app-card-body p-3 p-lg-4">
							    <h4 class="stats-type mb-1">TOTAL ANNUAL AMOUNT</h4>
							    <div class="stats-figure"><?php echo formatDashboardAmount($dashboardAmcosAnnualAmount); ?>
								</div>
							    
						    </div><!--//app-card-body-->
						    <a class="app-card-link-mask" href="amcos.php"></a>
					    </div><!--//app-card-->
				    </div><!--//col-->

					<div class="col-6 col-lg-4">
					    <div class="app-card app-card-stat shadow-sm h-100">
						    <div class="app-card-body p-3 p-lg-4">
							    <h4 class="stats-type mb-1" style="color:green;">TOTAL ANNUAL AMOUNT PAID</h4>
							    <div class="stats-figure"><?php echo formatDashboardAmount($dashboardAmcosPaidAmount); ?></div>
							    
						    </div><!--//app-card-body-->
						    <a class="app-card-link-mask" href="amcos.php"></a>
					    </div><!--//app-card-->
				    </div><!--//col-->

					<div class="col-6 col-lg-4">
					    <div class="app-card app-card-stat shadow-sm h-100">
						    <div class="app-card-body p-3 p-lg-4">
							    <h4 class="stats-type mb-1" style="color:red;">TOTAL AMOUNT UNPAID</h4>
							    <div class="stats-figure"><?php echo formatDashboardAmount($dashboardAmcosUnpaidAmount); ?></div>
							    
						    </div><!--//app-card-body-->
						    <a class="app-card-link-mask" href="amcos.php"></a>
					    </div><!--//app-card-->
				    </div><!--//col-->

				
				    <div class="col-6 col-lg-4">
					    <div class="app-card app-card-stat shadow-sm h-100">
						    <div class="app-card-body p-3 p-lg-4">
							    <h4 class="stats-type mb-1">TOTAL TRAINING FEE</h4>
							    <div class="stats-figure"><?php echo formatDashboardAmount($dashboardAmcosTrainingFee); ?></div>
							    
						    </div><!--//app-card-body-->
						    <a class="app-card-link-mask" href="amcos.php"></a>
					    </div><!--//app-card-->
				    </div><!--//col-->
				    
				    <div class="col-6 col-lg-4">
					    <div class="app-card app-card-stat shadow-sm h-100">
						    <div class="app-card-body p-3 p-lg-4">
							    <h4 class="stats-type mb-1" style="color:green;">TOTAL SYSTEM INSTALLATION FEE</h4>
							    <div class="stats-figure"><?php echo formatDashboardAmount($dashboardAmcosSystemInstallFee); ?></div>
							    
						    </div><!--//app-card-body-->
						    <a class="app-card-link-mask" href="amcos.php"></a>
					    </div><!--//app-card-->
				    </div><!--//col-->
				    <div class="col-6 col-lg-4">
					    <div class="app-card app-card-stat shadow-sm h-100">
						    <div class="app-card-body p-3 p-lg-4">
							    <h4 class="stats-type mb-1" style="color:blue;">TOTAL ANDROID FEE</h4>
							    <div class="stats-figure"><?php echo formatDashboardAmount($dashboardAmcosAndroidFee); ?></div>
							    
						    </div><!--//app-card-body-->
						    <a class="app-card-link-mask" href="amcos.php"></a>
					    </div><!--//app-card-->
				    </div><!--//col-->
				    
				    
				    
				    

					<div class="col-6 col-lg-4">
					    <div class="app-card app-card-stat shadow-sm h-100">
						    <div class="app-card-body p-3 p-lg-4">
							    <h4 class="stats-type mb-1">TOTAL SYSTEM RE-INSTALLATION FEE</h4>
							    <div class="stats-figure"><?php echo formatDashboardAmount($dashboardAmcosSystemReinstallFee); ?></div>
							    
						    </div><!--//app-card-body-->
						    <a class="app-card-link-mask" href="amcos.php"></a>
					    </div><!--//app-card-->
				    </div><!--//col-->
				    
				    				    <div class="col-6 col-lg-4">
					    <div class="app-card app-card-stat shadow-sm h-100">
						    <div class="app-card-body p-3 p-lg-4">
							    <h4 class="stats-type mb-1">TOTAL HOSTING FEE</h4>
							    <div class="stats-figure"><?php echo formatDashboardAmount($dashboardAmcosHostingFee); ?></div>
							    
						    </div><!--//app-card-body-->
						    <a class="app-card-link-mask" href="amcos.php"></a>
					    </div><!--//app-card-->
				    </div><!--//col-->
				    
				    				    <div class="col-6 col-lg-4">
					    <div class="app-card app-card-stat shadow-sm h-100">
						    <div class="app-card-body p-3 p-lg-4">
							    <h4 class="stats-type mb-1">BULK SMS</h4>
							    <div class="stats-figure"><?php echo formatDashboardAmount($dashboardAmcosBulkSmsFee); ?></div>
							    
						    </div><!--//app-card-body-->
						    <a class="app-card-link-mask" href="amcos.php"></a>
					    </div><!--//app-card-->
				    </div><!--//col-->
				    
				    					<div class="col-6 col-lg-4">
					    <div class="app-card app-card-stat shadow-sm h-100">
						    <div class="app-card-body p-3 p-lg-4">
							    <h4 class="stats-type mb-1">OFFICE EXPENSES</h4>
							    <div class="stats-figure"><?php echo formatDashboardAmount($dashboardAmcosOfficeExpenses); ?></div>
							    
						    </div><!--//app-card-body-->
						    <a class="app-card-link-mask" href="income.php"></a>
					    </div><!--//app-card-->
				    </div><!--//col-->
				    
				    				    					<div class="col-6 col-lg-4">
					    <div class="app-card app-card-stat shadow-sm h-100">
						    <div class="app-card-body p-3 p-lg-4">
							    <h4 class="stats-type mb-1">OTHER INCOME</h4>
							    <div class="stats-figure"><?php echo formatDashboardAmount($dashboardAmcosOtherIncome); ?></div>
							    
						    </div><!--//app-card-body-->
						    <a class="app-card-link-mask" href="expenses.php"></a>
					    </div><!--//app-card-->
				    </div><!--//col-->

					
				
			    </div><!--//row-->
			   
			    
			    
		    </div><!--//container-fluid-->
	    </div><!--//app-content-->
	    
	    <footer class="app-footer" style="margin-top: 390px;">
		    <div class="container text-center py-3">
		     
 
		       
		    </div>
	    </footer>
	    
    </div><!--//app-wrapper-->    					

 
    <!-- Javascript -->          
    <script src="assets/plugins/popper.min.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>  

    <!-- Charts JS -->
    <script src="assets/plugins/chart.js/chart.min.js"></script> 
    <script src="assets/js/index-charts.js"></script> 
    
    <!-- Page Specific JS -->
    <script src="assets/js/app.js?v=20260712-7"></script> 

	<script>
    // Set the inactivity timeout duration in milliseconds (e.g., 15 minutes)
const inactivityTimeout = 10 * 60 * 1000; // 15 minutes in milliseconds

let logoutTimer;

// Reset the timer on user activity
function resetLogoutTimer() {
    clearTimeout(logoutTimer);
    logoutTimer = setTimeout(logoutUser, inactivityTimeout);
}

// Logout the user when the timeout is reached
function logoutUser() {
    // Perform logout actions here (e.g., clear session data, redirect to logout page)
    window.location.href='logout.php';
    // You can replace the alert with actual logout code.
}

// Initialize the timer when the page loads or after user activity
window.onload = resetLogoutTimer;
document.onmousemove = resetLogoutTimer; // You can add more events like keypress, etc. for user activity

// Optionally, you can also handle clicks on specific elements to reset the timer
// For example, if you have a button that keeps the user logged in
const keepLoggedInButton = document.getElementById('keep-logged-in-button');
keepLoggedInButton.addEventListener('click', resetLogoutTimer);
</script>

</body>
</html> 
